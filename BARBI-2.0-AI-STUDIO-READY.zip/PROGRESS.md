# B.A.R.B.I 2.0 — Development Progress Log

**Last updated:** 2026-11-23
**Project:** `C:\Users\USER\OneDrive - Tshwane University of Technology\Documents\Default Project`
**Live app:** http://localhost:3000

## 0. Latest Updates (this session)

| Item | Status |
|---|---|
| Escape sound removed entirely (both TS and legacy runtime listeners); remaining UI SFX switched to dry low mechanical/instrument-panel tones (`press`, `release`, `beep`, `focus`, `longPress`, `error`) | Done — `src/audio/barbiSfx.ts`, `public/barbi-runtime.js` |
| Downloaded `websfx-master.zip` SFX library incorporated (`src/audio/websfx/`): modern synthesized click/hover/select/open/close/back/success/error sounds replace all generated WAVs | Done — `src/audio/barbiSfx.ts`, `src/main.tsx` |
| Old `barbi-ui-*.wav` files removed; `window.barbiSfx` keeps persisted enable/volume API and boot tone delegates to websfx | Done |
| Gaming SFX replaced with modern subtle UI sounds (cinematic low boot rise, soft filtered clicks, back glide, airy open/close, smooth confirm); retro square-wave/arpeggio sounds removed | Done — `public/audio/barbi-ui-*.wav`, `public/barbi-runtime.js` |
| Escape now plays a soft "back" navigation SFX; startup panel darkened further | Done — `public/barbi-runtime.js`, `src/barbi/barbiStyles.css` |
| Gaming-style UI SFX engine added: boot, hover, click, panel open/close, confirm and alert sounds; enabled/volume persisted in localStorage (`window.barbiSfx`) | Done — `public/audio/barbi-*.wav`, `public/barbi-runtime.js` |
| Live voice controls rail removed; single clear centered acoustic deck with mic-on-user-speech and animated core-on-B.A.R.B.I.-speech | Done — `src/components/LiveVoicePanel.tsx` |
| Startup: first power window is dark with sci-fi pattern; Google/guest sign-in window keeps the deep INNER CORE (19.0) rotating sphere behind it | Done — `src/barbi/barbiMarkup.html`, `src/barbi/barbiStyles.css`, `public/barbi-runtime.js` |
| Escape closes every panel including Social/Public Agent, BARBI Agent, Computer Vision, Spotify, Speed Test and Engineering panels | Done — `public/barbi-runtime.js` |
| Top-left quick controls extracted into dedicated Nexus Sphere icons (orbit reset, 4 depth tiers, focus, time travel, categories, core matrix, sphere config, file agent); top-left row hidden | Done — `public/barbi-runtime.js`, `src/barbi/barbiStyles.css` |
| Gesture HUD now has an object-identify button launching Computer Vision (clean boxes + confidence, no clutter); MediaPipe runs locally from CDN, no manual download | Done — `src/components/GestureNavHud.tsx` |
| MATLAB / SOLIDWORKS / Altium Web mode replaced broken refused-connection iframe with provider-framing handoff card + Desktop default | Done — `src/components/EngineeringAppPanel.tsx` |
| Live voice deck: mic shown while user speaks; while B.A.R.B.I. speaks the orb is replaced by an animated inner-core sphere with wire mesh, orbiting fragmented equations/code and glow | Done — `src/components/LiveVoicePanel.tsx` |
| Voice persona default is Puck; selection persists in localStorage across app restarts | Done — `src/components/LiveVoicePanel.tsx` |
| Chess AI ELO: 3300 = GOD MODE (Chess.com scale), visible AI ELO slider in the header, player name always "B.A.R.B.I" (Stockfish wording removed) | Done — `public/barbi-runtime.js`, `src/barbi/barbiMarkup.html` |
| Boot sound replaced with a clean high-tech power sweep + shimmer (low volume) | Done — `public/audio/barbi-boot.wav` |
| Sign-in / guest gateway and onboarding panel fully glassed with sci-fi frames, centered text and light backdrop | Done — `public/barbi-runtime.js`, `src/barbi/barbiStyles.css` |
| Extended sci-fi border library (4 HUD frames, radar rings, chamfers, hexagons) applied to panels lacking them | Done — `src/barbi/barbiStyles.css`, `public/barbi-runtime.js` |
| Chess fullscreen properly fills the viewport (96vw × 92vh centered); fixed Tailwind v4 individual `translate` conflict by neutralizing `--tw-translate-*` variables, board enlarged to `min(66vh,58vw)` | Done — `src/barbi/barbiStyles.css` |
| Search + Enter now opens the real panel for every searchable item; God's Eye opens the full M11 viewport (NOIR, omnibar, DETECT/MIL-HUD/COCKPIT, SHARE/RESET, Ask-the-Planet, timeline) instead of a generic inspector | Done — `public/barbi-runtime.js` (`handleSphereSearchEnter`, `sys-gods-eye`) |
| Gmail sign-in workspace fully glassed: transparent interior + sci-fi shell, glass headers/sidebars/inputs | Done — `src/components/GmailWorkspacePanel.tsx` |
| Boot sound refined to polished digital text/data-stream blips (rapid clicks + typing bleeps, low volume); fast sphere rotation behind transparent boot glass before power-on | Done — `public/audio/barbi-boot.wav`, `public/barbi-runtime.js` |
| "Gesture D3" renamed to "Gesture Control" across UI, voice tools and runtime | Done |
| Internet Speed Test sphere node wired (category, logos, aliases, click + search-Enter launch) — module measures real bytes via `/api/speedtest/{ping,download,upload}` with live gauges | Done — `public/barbi-runtime.js`, `src/components/InternetSpeedPanel.tsx`, `src/server/routes/api.ts` |
| Altium Designer sphere node now uses its official Simple Icons logo and opens the in-app Desktop/Web engineering panel | Done — `public/icons/altium-logo.svg`, `public/barbi-runtime.js`, `src/components/EngineeringAppPanel.tsx` |
| Boot sound replaced with digital text/data-stream texture (rapid clicks, typing blips, granular bleeps) at low volume; sphere now rotates fast behind the transparent boot glass before power-on | Done — `public/audio/barbi-boot.wav`, `public/barbi-runtime.js`, `src/barbi/barbiMarkup.html` |
| Chrome relaunched with camera/microphone permission auto-approved (`--use-fake-ui-for-media-stream`) | Done |
| MATLAB / Simulink / SOLIDWORKS nodes now open real in-app glass panels with Desktop and Web modes, exact official logos, official web experiences embedded when framing is allowed, and BARBI Agent handoff for local installs | Done — `src/components/EngineeringAppPanel.tsx`, `public/icons/` |
| Computer Vision decoder corrected to channel-major YOLOv8n output (the cause of the hallucinated box flood); ONNX session/input/output API fixed, camera-permission guidance, image mode, locking + trails added | Done — `src/vision/objectDetector.ts`, `src/components/ObjectVisionPanel.tsx` |
| Startup sound replaced with a soft futuristic HUD boot WAV (quiet volume, synthesized fallback); tiny "Created by ZULUTRONIX (PTY) LTD" line added to boot panel | Done — `public/audio/barbi-boot.wav`, `public/barbi-runtime.js` |
| Top-left controls and B.A.R.B.I brand HUD restored to the top-left corner for all browsers (countdown remains centered) | Done — `src/barbi/barbiMarkup.html` |
| Battery horizon now derives time-to-low from the device Battery Manager `dischargingTime`; charging ETA from `chargingTime` | Done — `public/barbi-runtime.js` |
| HQ Games-style powered boot sequence added (power button, synthesized boot tone, staged loading log/progress, then app reveal) | Done — `src/barbi/barbiMarkup.html`, `public/barbi-runtime.js` |
| Sign-in / login gateway rebuilt as fully transparent sci-fi glass panel with centered B.A.R.B.I name and full acronym underneath; onboarding modal also inherits the universal frame | Done |
| Universal sci-fi glass frame applied to every popup/dialog (`[role="dialog"]`, `.barbi-scifi-shell`, onboarding, HUD frame templates) — transparent interiors, theme-colored chamfers and corner brackets | Done — `src/barbi/barbiStyles.css` |
| B.A.R.B.I brand centralized at top of HUD with acronym underneath; countdown relocated below it | Done — `src/barbi/barbiMarkup.html` |
| Battery time remaining now uses the device Battery Manager `chargingTime`/`dischargingTime` (with derived time-to-low) plus change listeners, instead of hardcoded estimates | Done — `public/barbi-runtime.js` |
| Spotify node opens an in-app glass player (embedded Spotify, link paste, presets) with an "Open Web Version" option | Done — `src/components/SpotifyPanel.tsx`, `src/App.tsx`, `public/barbi-runtime.js` |
| Sudoku Arena upgraded with Easy/Medium/Hard levels, live timer, mistake/hint penalties, score, persisted top-8 scoreboard, number pad and keyboard controls | Done — `public/barbi-runtime.js` (`openSudokuModal`) |
| MATLAB / Simulink / SolidWorks nodes open a functional Engineering HUD with BARBI Agent task handoff | Done — `public/barbi-runtime.js` |
| Global Escape handler closes every B.A.R.B.I panel/modal; Chess fullscreen centering fixed (Tailwind v4 `translate` conflict) and board enlarged | Done — `public/barbi-runtime.js`, `src/barbi/barbiStyles.css` |
| Computer Vision uses a sniper crosshair/target icon, camera permission guidance, image-upload mode, object locking, trails and "Ask BARBI Agent" handoff; YOLOv8n ONNX model installed (12.8 MB), session/input/output decode bugs fixed | Done — `src/vision/objectDetector.ts`, `src/components/ObjectVisionPanel.tsx`, `public/model/yolov8n.onnx` |
| App icon set regenerated from user-supplied image (PWA, favicon, Apple touch, Tauri sizes) | Done |
| FinTech crash fixed — root cause was d3 `.transition()` calls while d3-transition was absent from the production vendor chunk; replaced both pie-chart transition tweens with direct D3 attribute updates. Verified live: `/api` hub → FinTech tab renders 3 pie slices + 6 rails with zero console errors | Done — `src/components/VentureAllocationPieChart.tsx` |
| Sci-fi HUD frame applied to all glassmorphic agent panels from user screenshot: fully transparent background (no dark fill), theme-colored chamfered corner brackets, hatch accents and edge highlights, glass blur retained | Done — `src/barbi/barbiStyles.css` (`.barbi-agent-panel`, header/divider transparent) |
| "God's Eye (M11)" node renamed to "God's Eye" with the Eye of Horus logo `𓂀` (node icon + label logo) | Done — `public/barbi-runtime.js` |
| ALL sphere/node/app logo badges converted from circles to hexagons via `.barbi-hex-logo` clip-path (25 badges verified in browser) | Done — `src/barbi/barbiStyles.css`, `public/barbi-runtime.js` |
| New sphere nodes added: WiFi Manager, Bluetooth, Spotify, Sudoku Arena + Object Vision — category, logos, aliases, launch handlers | Done — `public/barbi-runtime.js` |
| Playable Sudoku Arena (9×9 glassmorphic modal, validate + new puzzle) in the same UI family as Chess | Done — `public/barbi-runtime.js` (`openSudokuModal`) |
| Connectivity HUD (WiFi/Bluetooth) with one-click BARBI Agent OS-command handoff | Done — `public/barbi-runtime.js` |
| Computer Vision panel (YOLOv8n ONNX detector + IoU multi-object tracking) mounted in App with voice/UI-action wiring | Done — `src/vision/objectDetector.ts`, `src/components/ObjectVisionPanel.tsx`, `src/App.tsx`, voice layer |
| User-supplied app icon (`C:\Users\USER\Downloads\Images\image_62045223.jpg`) applied to PWA, favicon, Apple touch icon, and all Tauri icon sizes | Done |
| Cursor control feature (MediaPipe fingertip pointer, pinch click on any DOM element, open-palm scroll, optional native OS cursor in Tauri) | Done — `src/gesture/cursorControl.ts`, wired into `GestureNavHud.tsx`, lint passing |
| OpenCode SDK/client/plugin + MCP SDK installed (`@opencode/sdk`, `@opencode/client`, `@opencode/plugin`, `@modelcontextprotocol/sdk`) | Done |
| OpenCode bidirectional integration (embedded agent + B.A.R.B.I MCP server + UI panel) | Done — verified `/api/opencode/status`, `/sessions`, `/mcp/tools` |
| **BARBI Agent** — full OpenCode coding environment UI (workspace tree, sessions, MCP tools, quick actions, maximize) | Done — `src/components/OpenCodeAgentPanel.tsx` |
| **Social Agent** — normalized WhatsApp/Telegram/Instagram/TikTok inbox, send, automation rules, approval gates, webhooks | Done — `src/server/social/socialAgentService.ts`, `src/server/routes/social.ts`, `src/components/SocialAgentPanel.tsx`, 8 MCP tools |
| Gmail node replaced the generic Email node in the Nexus sphere (`app-gmail`), with Gmail → academic-path edge and search aliases | Done — `public/barbi-runtime.js` |
| BARBI Agent + Social Agent promoted from command-crown/dock pods to full app-tier Nexus sphere nodes (`app-barbi-agent`, `app-social-agent`); app ring now uses 10 evenly-spaced slots | Done — `public/barbi-runtime.js`, `src/barbi/barbiMarkup.html` |
| Floating bottom-left / bottom-right BARBI Agent and Social Agent launcher buttons removed entirely; both panels now launch only from their Nexus sphere nodes or voice/text commands | Done — `OpenCodeAgentPanel.tsx`, `SocialAgentPanel.tsx`, dead `.barbi-agent-launcher` CSS removed |
| GitHub Assimilator verified live: `/api/v4/github/search` returned 200, `/api/v4/github/assimilate` returned 201 for `bilawalsidhu/gods-eye-view`, and smoke-test assimilation was cleaned via DELETE | Done — `/api/v4/github/*` |
| BARBI Agent live UI smoke test succeeded: prompt returned final text `UI TEST OK` via OpenCode free provider; UI shows busy working indicator while OpenCode executes | Done — `OpenCodeAgentPanel.tsx`, OpenCode backend wait flow |
| Voice/text launch for BARBI Agent, Social Agent and Gmail from the Nexus chat router | Done — `public/barbi-runtime.js` |
| Glass-morphic surface styling for both agent panels (shared CSS classes), upgraded to deeper chamfered edge-glass | Done — `src/barbi/barbiStyles.css` (`.barbi-agent-panel` now blur(48px) saturate(185%) with chamfer clip-path + edge highlights) |
| CSS minifier stripped standard `backdrop-filter` when the `-webkit-` twin was also present (Chromium build rejects the prefix) — removed prefixed declarations so standard blur survives | Done — `src/barbi/barbiStyles.css` (20 lines removed) |
| BARBI Agent MCP tool console: direct REST invocation of workspace tree/read/write, allowlisted lint/build/test commands, provider status, telemetry, notebooks, God's Eye and Social tools | Done — `src/components/OpenCodeAgentPanel.tsx`, `src/server/routes/opencode.ts` |
| God's Eye / GOTS UI upgrade from downloaded `bilawalsidhu/gods-eye-view` source: NOIR sensor mode, keyless coordinate/target omnibar, DETECT / MIL-HUD / COCKPIT overlays, SHARE + RESET, Ask-the-Planet queries, timeline scrubber | Done — `src/v4/godsEyeLogic.ts`, `src/components/GodsEyeViewport.tsx` |
| Study & Explainer rebuilt as a NotebookLM-style three-pane workspace (Sources · grounded Chat · Studio artifacts) with deep research, summarize, notes, export, audio/video/mind-map artifacts and HD explainer stage | Done — `src/components/NotebookStudioPanel.tsx`, mounted via `src/barbi/BarbiWorkspace.tsx`, `src/barbi/barbiMarkup.html` |
| YouTube embed playback fix (standard embed → nocookie fallback → external watch link, retired `listType=search` fixed) | Done — `public/barbi-runtime.js`, `src/barbi/barbiMarkup.html` |
| Sphere icon/label burnt-umber + dim-until-selected second pass (CSS `!important` overrides fixed) | Done — `src/barbi/barbiStyles.css`, `public/barbi-runtime.js` |
| BARBI Agent panel made fully responsive (fixed right/bottom constrained → `inset-x-4 bottom-4 h-[min(88dvh,780px)]`; maximized keeps `inset-3`) | Done — `src/components/OpenCodeAgentPanel.tsx` |
| BARBI Agent + Social Agent panels restyled to burnt umber + glassmorphic (background burnt-umber gradient, `backdrop-filter: blur(12px) saturate(140%)`, burnt-umber border, HUD chamfered clip-path, no radius) taken from Weather/GPS HUD style | Done — `src/barbi/barbiStyles.css` (`.barbi-agent-panel`) |
| HTTP 502 backend outage resolved — stale `server.ts` processes stopped, production server restarted; `/api/health`, `/api/opencode/status`, `/api/social/summary` back to 200 | Done — `C:\Users\USER\AppData\Local\Temp\opencode\startprod.bat` |

---

## 1. Project Setup & Stability

| Item | Status |
|---|---|
| Extracted source from `b-a-r-b-i-nov-21-2026-8-56-01-pm.zip` | Done |
| Dependencies installed (`npm install --legacy-peer-deps`) | Done |
| TypeScript lint (`npm run lint` / `tsc --noEmit`) | Passing, exit 0 |
| Production build (`npm run build`) | Passing |
| Production server on port 3000 | Running, health check = `200` |
| Helper scripts (build/lint/checkjs/health/killport) | In `C:\Users\USER\AppData\Local\Temp\opencode\` |

## 2. Accounts, History & Onboarding

| Item | Status |
|---|---|
| Google/Gmail login (Firebase auth, existing config) | Done |
| Per-user conversation history & workspace state | Done |
| `BarbiBridge` exposes signIn/signOut/getAuthUser/provider status/bootstrap | Done |
| Onboarding modal (role, AI focus, gesture preference, provider status) | Done |
| Floating auth button + login modal in `public\barbi-runtime.js` | Done |
| Onboarding wired to AI provider setup | Done |

## 3. PWA / Install

| Item | Status |
|---|---|
| PWA install button via `beforeinstallprompt` | Done (works desktop + phone) |
| Manifest / service worker via VitePWA | Done |
| Native Windows `.exe` (Tauri) | **BUILT SUCCESSFULLY** — `barbi.exe` (3 MB). Copied to Desktop and Downloads as `B.A.R.B.I 2.0.exe` |
| Native Windows `.msi` installer bundle | Not generated (`cargo tauri build` not run; only `cargo build --release`). Can be added later |
| Android `.apk` | Blocked — Java + Android SDK not installed |
| iOS | Blocked — requires macOS + Xcode |

### Windows native build notes
- Rust installed at `C:\Users\USER\.cargo\bin`.
- VS 2022 Build Tools installed with MSVC (`cl.exe` found under `C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Tools\MSVC\...`).
- Earlier attempts failed with `os error 4551` (WDAC blocking compiled build scripts). User has since lifted the policy for the build.
- Build command: `cmd /c C:\Users\USER\AppData\Local\Temp\opencode\build.bat` (sources `vcvars64.bat`, runs `cargo build --release` in `src-tauri`, logs to `buildout.txt`).
- Build result: `Finished release profile in 7m 02s`, `EXIT_CODE: 0`.
- Binary at `src-tauri\target\release\barbi.exe`, copied to `Desktop\B.A.R.B.I 2.0.exe` and `Downloads\B.A.R.B.I 2.0.exe`.

## 9. Deliverables / File Locations

| Deliverable | Location |
|---|---|
| **All-files ZIP (24 MB)** | `C:\Users\USER\Documents\BARBI-2.0-ALL-FILES.zip` (moved from Downloads on user request) |
| Windows executable | `C:\Users\USER\Desktop\B.A.R.B.I 2.0.exe` and `C:\Users\USER\Downloads\B.A.R.B.I 2.0.exe` |
| Progress log | `C:\Users\USER\OneDrive - Tshwane University of Technology\Documents\Default Project\PROGRESS.md` (also inside ZIP) |
| Live web app | http://localhost:3000 |
| Production build | `...\Default Project\dist\` |

**ZIP contents note:** includes all source, config, `public\`, `src\`, `src-tauri\` (source only), `dist\`, and the built exe under `Builds\`. Regenerable `node_modules\` and `src-tauri\target\` are excluded (together ~1.6 GB); restore with `npm install --legacy-peer-deps` and `cargo build --release`.

## 4. Performance & Bundle

| Item | Status |
|---|---|
| Lazy-loaded panels in `src/App.tsx` | Done |
| Manual vendor chunks in `vite.config.ts` (three, mediapipe, firebase, genai, react, db, d3, motion, vendor) | Done |
| Deferred `barbiMarkup.html?raw` import (own chunk, excluded from precache) | Done |

## 5. AI / Studio Features

| Item | Status |
|---|---|
| Explainer canvas upgraded to 1280x720 | Done |
| HD `.webm` export (animated progress, narration sync, VP9/VP8, 4 Mbps) | Done |
| `studyStudioService.ts` JSON extraction/sanitization hardened | Done |
| NotebookLM-style service (`notebookLmService.ts`): notebooks, sources, grounded chat, citations, notes, artifacts, deep research, summaries, export, chat modes | Done |
| NotebookLM REST routes in `src/server/routes/api.ts` + client methods in `barbiClient.ts` | Done |
| NotebookLM-style three-pane React UI (`NotebookStudioPanel.tsx`) mounted into the Study & Explainer tab: Sources rail, grounded chat with modes/citations, Studio artifact cards, notes, deep research, summarize, Markdown export and HD explainer stage | Done |
| Targeted tests: `studyStudioService.test.ts` and `reaService.test.ts` (6/6) | Passing |
| Full `node --test src/**/*.test.ts` | 48 pass / 11 fail (Node ESM resolution — missing `.ts` extensions, not confirmed code bugs) |

## 5b. BARBI Agent & Social Agent

### BARBI Agent (OpenCode environment)
- `src/components/OpenCodeAgentPanel.tsx` — full-screen-capable coding environment titled **BARBI Agent**
- Workspace tree viewer (`barbi_workspace_tree` MCP tool), session create/switch, MCP tool catalog, quick actions, maximize/restore
- **MCP Console view** — direct tool invocation for workspace tree/read/write, allowlisted `lint`/`build`/`test`, provider status, host telemetry, notebooks, God's Eye feeds and Social Agent summaries; JSON input + result panes and one-click presets
- Auto-opens via the `app-barbi-agent` Nexus sphere node, voice/text command (`barbi agent`, `opencode`, `coding environment`), or `window.openOpenCodePanel({ open: true, prompt?: string })`
- Uses OpenCode `session.prompt()` → `session.wait()` → `message.list()` flow; full workspace access guarded by `opencode.jsonc` permissions
- Status/verified: `/api/opencode/status` = background-service mode; `/api/opencode/mcp/tools` = 37 tools

### Social Agent (WhatsApp · Telegram · Instagram · TikTok)
- `src/server/social/socialAgentService.ts` — normalized inbound message model, pluggable adapters, outbound send, automation rules engine, approval queue, Telegram inbox polling
- Adapters use official/self-hosted APIs only (no scraping):
  - WhatsApp: WAHA (`WAHA_BASE_URL`, `WAHA_SESSION`, `WAHA_API_KEY`)
  - Telegram: Bot API (`TELEGRAM_BOT_TOKEN`, `TELEGRAM_CHAT_ID`)
  - Instagram: Meta Graph (`IG_ACCESS_TOKEN`, `IG_USER_ID`, needs `instagram_manage_messages`)
  - TikTok: Business Messaging webhooks (`TIKTOK_ACCESS_TOKEN`)
- `src/server/routes/social.ts` — REST under `/api/social` (`summary`, `messages`, `send`, `rules`, `approvals`, `poll/telegram`) and webhooks at `/api/social/webhook/<platform>` with constant-time secret / Meta `X-Hub-Signature-256` verification
- `src/components/SocialAgentPanel.tsx` — glass-morphic UI: connection status, unified inbox, send composer, automation rule editor, approval queue
- 8 MCP tools: `barbi_social_summary`, `barbi_social_messages`, `barbi_social_send`, `barbi_social_poll`, `barbi_social_approvals`, `barbi_social_resolve_approval`, `barbi_social_save_rule`, `barbi_social_delete_rule`
- Verified end-to-end: WAHA webhook → normalized message → rule match → approval queue (test data cleared)

## 6. Security Hardening

| Item | Status |
|---|---|
| R.E.A. SSRF guard hardened (IPv6 + mapped ranges) | Done |
| CORS allow-list via `APP_URL`, localhost fallback, credentials, 5 MB body limit | Done |
| WebSocket origin validation in `liveVoiceBridge.ts` | Done |
| AI orchestration: actionable "no provider configured" message | Done |
| MediaPipe gesture engine retry fix (`loadingPromise` reset) | Done |

## 7. UI Theming (latest work)

| Item | Status |
|---|---|
| Sphere node colors -> burnt umber palette (`#8B4513` / `#D2691E` / `#8A3324`) | Done |
| `getNodeThemeColor()` reworked: dim base, bright `#FFB833` when selected/highlighted | Done |
| Unselected nodes dimmed to ~32% opacity; full opacity on hover/select | Done |
| Node label text colors shifted to burnt umber with dim default (`text-[#D2691E]/60`) | Done |
| Command-node emblem styling -> burnt umber | Done |
| WhatsApp modal accents shifted from emerald to burnt umber | Done |
| Sphere icon/label burnt-umber + dim-until-selected second pass (`!important` overrides fixed, verified in browser at `rgba(138, 51, 36, 0.44)` idle) | Done |
| Agent panels upgraded to chamfered edge-glass: clip-path corners, 48px blur, saturation boost, dual-axis edge highlights | Done — `.barbi-agent-panel::before/::after` in `src/barbi/barbiStyles.css` |
| YouTube embed error — playback inside app + external "watch on internet" link | Done — standard embed → nocookie fallback, watchdog fallback UI, all watch links forced to `youtube.com/watch?v=<id>` |

### YouTube player notes
- Player engine in `public\barbi-runtime.js` around lines 4600–4730.
- Uses `https://www.youtube-nocookie.com/embed/<id>?autoplay=1&rel=0&modestbranding=1`.
- "Watch on YouTube" external link built as `https://www.youtube.com/watch?v=<id>`.
- Modal markup at `src\barbi\barbiMarkup.html` around lines 1285–1400.
- Curated IDs include some that may be unavailable/removed — needs verification and a reliable fallback.

## 8. Known Issues / Next Actions

1. Windows `.exe` rebuilt successfully (latest UI) and copied to Desktop + Downloads. `.msi` installer not generated (`cargo tauri build` not run).
2. Sphere icons + label text verified burnt umber / dim-until-selected in browser.
3. YouTube embed playback + external "watch on internet" link fixed.
4. Android/iOS native builds remain blocked by missing SDKs/macOS.
5. Final checks all green: `checkjs.ps1` EXIT 0, `lint.ps1` EXIT_CODE 0, `build2.ps1` EXIT_CODE 0, Tauri `cargo build --release` EXIT_CODE 0, `/` 200, `/api/health` 200, `/api/opencode/status` 200, `/api/social/summary` 200, `/api/studio/notebooks` 200, `/api/opencode/mcp/call` 200.
6. NotebookLM studio verified in browser: the `#notebooklm-studio-root` React portal mounts Sources / Chat / Studio / explainer stage inside the Study & Explainer tab, and the 1280×720 explainer canvas is present.
7. Floating BARBI Agent / Social Agent launchers verified absent in the browser (`0` launchers); both panels open correctly from their `app-barbi-agent` and `app-social-agent` Nexus sphere nodes.
8. Windows `.exe` recopied to Desktop + Downloads and all-files ZIP regenerated at `C:\Users\USER\Documents\BARBI-2.0-ALL-FILES.zip` (28.4 MB).

---

*This file is maintained as a living record of changes. Update it as work continues.*


---

## 10. Detailed System Specifications

### Runtime & toolchain
| Layer | Specification |
|---|---|
| Web server | Node.js 26.13.1 / npm 11.20.0, Express 4.21.2, `tsx` TypeScript runtime, port 3000 |
| Frontend | React 19, Vite 8.3.8, Tailwind CSS 4 (`@tailwindcss/vite`), TypeScript strict (`tsc --noEmit`) |
| PWA | `vite-plugin-pwa` 2.0.0, generated service worker + manifest, installable desktop/mobile |
| Native | Tauri 2.x (Rust release build), `barbi.exe` ~3 MB, frontendDist `../dist`, icons regenerated from user image |
| Styling | Burnt-umber/amber theme (`--accent-rgb`, `--accent-hex`), universal sci-fi glass frame: chamfers, corner brackets, hatch accents, transparent interiors + backdrop blur |
| 3D sphere | three.js 0.128.0, custom WebGL renderer, D3 overlay labels, event/pulse graph |
| Database | PostgreSQL + Drizzle ORM 0.45.4, pg 8.23.1, ARCHIVEX knowledge/history repository |
| Auth | Firebase 13.3.0 / firebase-admin 14.5.1, Google sign-in + guest mode, per-user sessions/history |
| AI | 9-provider free-tier catalog (Gemini, Groq, OpenRouter, Cerebras, GitHub Models, Mistral, HF Router, Ollama, relays), failover/quota registry, `/api/ai/chat` + `/api/ai/chat/stream` accept `providerId` |
| Coding agent | BARBI Agent = embedded OpenCode environment (`@opencode/sdk/client` 2.3.2), free provider `tidepool-alpha-free`, workspace tree/sessions/MCP console |
| MCP | `@modelcontextprotocol/sdk` 1.32.2, B.A.R.B.I MCP server with ~37 tools (workspace, lint/build/test, provider status, notebooks, God's Eye, Social) |
| Computer vision | YOLOv8n ONNX 12.8 MB (`public/model/yolov8n.onnx`), ONNX Runtime Web 1.21.0 ESM + WASM CDN, 640×640 letterbox, NCHW decode `[1,84,8400]` **channel-major**, conf 0.35, NMS IoU 0.45, IoU track IDs + centroid trails |
| Gestures | MediaPipe Tasks Vision 1.2.3, 21-point hand landmarks, pinch/zoom/fist, cursor control |
| Voice | Gemini Live WebSocket bridge, wake-word monitor, Web Speech recognition, synthesized/formant UI audio, HUD scanning boot WAV |
| Social | WAHA / Telegram Bot / Instagram Graph / TikTok Business webhooks, normalization + approval gates |
| Data Viz | D3 7.9.2 (FinTech donut, graph, charts), custom SVG gauges for speed test |
| Validated endpoints | `/`, `/api/health`, `/api/opencode/status`, `/api/social/summary`, `/api/studio/notebooks`, `/api/rea/hosted`, `/api/rea/build-agent`, `/api/rea/build-system`, `/api/speedtest/*` |
| Verification | lint exit 0, checkjs exit 0, vite build exit 0, Tauri cargo build exit 0, ZIP regenerated 48.8 MB (335 files) |

### Backups (user-requested)
- Main ZIP: `C:\Users\USER\Documents\BARBI-2.0-ALL-FILES.zip` (48.8 MB, 335 files)
- Backup folder: `C:\Users\USER\Documents\BARBI-2.0-BACKUP\` (ZIP + `barbi-app-icon.png` + `barbi-windows-icon.ico`)
- Native exe: Desktop + Downloads `B.A.R.B.I 2.0.exe`

## 11. Future Direction / Roadmap

1. **True WAN speed measurement** — current speed test transfers real bytes to/from the local B.A.R.B.I server (accurate for local throughput); add 2–3 external measurement servers/CDN endpoints for genuine internet bandwidth, plus packet-loss and geolocation.
2. **Multi-LLM conversations** — wire a dedicated "Ask Groq / Ask OpenRouter / Ask Gemini…" command to `/api/ai/chat` `providerId`, add side-by-side provider comparison, and persist per-provider histories. Requires the user to add provider keys in Settings → Secrets.
3. **Performance** — cap 3D render loop FPS when idle, virtualize long lists (Gmail/history/notebooks), split the 918 KB `barbiMarkup` chunk, pre-warm the ONNX session off the critical path, add React error boundaries.
4. **Computer Vision** — WebGL GPU backend for ONNX, quantized/int8 model for mobile, class allow/deny filters, stronger multi-object tracking (motion prediction), multi-camera support, snapshot/video export.
5. **Native packaging** — `.msi` installer via `cargo tauri build`, Android APK (Java + Android SDK), iOS (macOS + Xcode); native battery API for exact Windows ETA.
6. **OS GUI control** — via Tauri permissions + BARBI Agent allowlisted commands: verified launch/close of MATLAB, SolidWorks, Spotify desktop apps; GUI automation with approval gates.
7. **Testing quality** — repair the 11 failing Node tests (missing `.ts` extensions in ESM imports), add integration tests for speed test / CV decode / provider routing.
8. **UX polish** — continue unifying every popup on the sci-fi glass frame, keyboard-first navigation, and accessibility (ARIA labels, focus rings).

