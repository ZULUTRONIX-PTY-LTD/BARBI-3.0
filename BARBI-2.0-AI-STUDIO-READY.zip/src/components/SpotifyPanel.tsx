import { useEffect, useRef, useState } from 'react';
import { ExternalLink, Music2, Play, RefreshCw, X } from 'lucide-react';

interface SpotifyWindow {
  openSpotifyPanel?: (options: { open?: boolean; url?: string }) => void;
  showToast?: (message: string, tone?: string) => void;
}

const PRESETS = [
  { label: "Today's Top Hits", id: 'playlist/37i9dQZF1DXcBWIGoYBM5M' },
  { label: 'RapCaviar', id: 'playlist/37i9dQZF1DX0XUsuxWHRQd' },
  { label: 'Peaceful Piano', id: 'playlist/37i9dQZF1DX4sWSpwq3LiO' },
  { label: 'Deep Focus', id: 'playlist/37i9dQZF1DWZeKCadgRdKQ' },
];

function toEmbedUrl(input: string): string | null {
  const raw = input.trim();
  const match = raw.match(/open\.spotify\.com\/(track|playlist|album|artist|episode|show)\/([A-Za-z0-9]+)/);
  if (match) return `https://open.spotify.com/embed/${match[1]}/${match[2]}`;
  const direct = raw.match(/^https?:\/\/open\.spotify\.com\/embed\//);
  if (direct) return raw;
  const bare = raw.match(/^(track|playlist|album|artist|episode|show)\/([A-Za-z0-9]+)$/);
  if (bare) return `https://open.spotify.com/embed/${raw}`;
  return null;
}

function toWebUrl(input: string): string | null {
  const embed = toEmbedUrl(input);
  if (!embed) return null;
  return embed.replace('/embed/', '/');
}

export default function SpotifyPanel() {
  const [open, setOpen] = useState(false);
  const [source, setSource] = useState(PRESETS[0].id);
  const [input, setInput] = useState('');
  const [reloadKey, setReloadKey] = useState(0);
  const openRef = useRef(false);
  openRef.current = open;

  const embedUrl = `https://open.spotify.com/embed/${source}`;
  const webUrl = `https://open.spotify.com/${source}`;

  useEffect(() => {
    const onToggle = (ev: Event) => {
      const detail = (ev as CustomEvent<{ open?: boolean; url?: string }>).detail;
      const next = typeof detail?.open === 'boolean' ? detail.open : !openRef.current;
      if (detail?.url) {
        const embed = toEmbedUrl(detail.url);
        if (embed) setSource(embed.replace('https://open.spotify.com/embed/', ''));
      }
      setOpen(next);
    };
    window.addEventListener('barbi:toggle-spotify', onToggle as EventListener);
    const win = window as unknown as SpotifyWindow;
    win.openSpotifyPanel = (options) => {
      if (options?.url) {
        const embed = toEmbedUrl(options.url);
        if (embed) setSource(embed.replace('https://open.spotify.com/embed/', ''));
      }
      setOpen(options?.open !== false);
    };
    return () => {
      window.removeEventListener('barbi:toggle-spotify', onToggle as EventListener);
      delete win.openSpotifyPanel;
    };
  }, []);

  useEffect(() => {
    (window as unknown as SpotifyWindow).showToast?.(open ? 'Spotify player opened inside B.A.R.B.I' : 'Spotify player minimized', 'accent');
  }, [open]);

  if (!open) return null;

  const applyInput = () => {
    const embed = toEmbedUrl(input);
    if (!embed) {
      (window as unknown as SpotifyWindow).showToast?.('Paste a valid Spotify track / playlist / album link', 'info');
      return;
    }
    setSource(embed.replace('https://open.spotify.com/embed/', ''));
    setReloadKey((k) => k + 1);
    setInput('');
  };

  return (
    <section
      id="barbi-spotify-panel"
      aria-label="B.A.R.B.I Spotify Player"
      className="barbi-agent-panel fixed right-4 top-16 z-50 w-[min(calc(100vw-2rem),460px)] h-[min(86dvh,740px)] flex flex-col overflow-hidden text-stone-100"
    >
      <header className="barbi-agent-header flex items-center justify-between gap-2 px-3.5 py-2.5 shrink-0">
        <div className="flex items-center gap-2 min-w-0">
          <span className="w-8 h-8 rounded bg-[#1DB954]/25 border border-[#1DB954]/70 flex items-center justify-center text-[#4ADE80] shrink-0">
            <Music2 className="w-4 h-4" />
          </span>
          <div className="min-w-0">
            <div className="text-[13px] font-semibold tracking-wide text-[#FBBF24] truncate">SPOTIFY · IN-APP</div>
            <div className="text-[9px] font-mono-tech text-[#D2691E]/90 truncate">Glass player · embedded in B.A.R.B.I</div>
          </div>
        </div>
        <div className="flex items-center gap-1 shrink-0">
          <button type="button" title="Reload player" onClick={() => setReloadKey((k) => k + 1)} className="p-1.5 rounded text-[#D2691E] hover:bg-white/10 transition">
            <RefreshCw className="w-3.5 h-3.5" />
          </button>
          <button type="button" title="Open web version" onClick={() => window.open(webUrl, '_blank', 'noopener,noreferrer')} className="flex items-center gap-1 px-2 py-1.5 rounded text-[9px] font-mono-tech text-[#FBBF24] border border-[#D2691E]/60 hover:bg-[#8B4513]/40 transition">
            <ExternalLink className="w-3 h-3" /> Web
          </button>
          <button type="button" title="Close" onClick={() => setOpen(false)} className="p-1.5 rounded text-[#D2691E] hover:bg-white/10 transition">
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      </header>

      <div className="px-3 py-2 border-b border-white/10 shrink-0 space-y-2">
        <div className="flex gap-2">
          <input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => { if (e.key === 'Enter') applyInput(); }}
            placeholder="Paste Spotify track / playlist / album link…"
            className="barbi-agent-input flex-1 min-w-0 px-2.5 py-1.5 rounded text-[10px] font-mono-tech text-stone-100 placeholder:text-stone-500"
          />
          <button type="button" onClick={applyInput} className="flex items-center gap-1 px-2.5 py-1.5 rounded bg-[#8B4513]/45 border border-[#D2691E]/65 text-[#FBBF24] text-[10px] font-mono-tech hover:bg-[#8B4513]/70 transition">
            <Play className="w-3 h-3" /> Play
          </button>
        </div>
        <div className="flex gap-1.5 overflow-x-auto pb-0.5">
          {PRESETS.map((p) => (
            <button
              key={p.id}
              type="button"
              onClick={() => { setSource(p.id); setReloadKey((k) => k + 1); }}
              className={`px-2 py-1 rounded border text-[9px] font-mono-tech whitespace-nowrap shrink-0 transition ${
                source === p.id ? 'bg-[#8B4513]/55 border-[#D2691E]/80 text-[#FBBF24]' : 'bg-white/[0.03] border-white/15 text-stone-400 hover:text-stone-100'
              }`}
            >
              {p.label}
            </button>
          ))}
        </div>
      </div>

      <div className="flex-1 min-h-0 bg-black/40">
        <iframe
          key={`${source}-${reloadKey}`}
          title="Spotify Embed Player"
          src={embedUrl}
          allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture"
          loading="lazy"
          className="w-full h-full border-0"
        />
      </div>

      <div className="flex items-center justify-between gap-2 px-3 py-2 border-t border-white/10 shrink-0">
        <span className="text-[9px] font-mono-tech text-[#D2691E]/80 truncate">{webUrl}</span>
        <button type="button" onClick={() => window.open(webUrl, '_blank', 'noopener,noreferrer')} className="flex items-center gap-1 px-2 py-1 rounded border border-white/15 text-[9px] font-mono-tech text-stone-300 hover:bg-white/10 shrink-0">
          <ExternalLink className="w-3 h-3" /> Full Web Version
        </button>
      </div>
    </section>
  );
}
