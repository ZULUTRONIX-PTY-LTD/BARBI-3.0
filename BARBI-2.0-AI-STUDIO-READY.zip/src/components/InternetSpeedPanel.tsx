import { useCallback, useEffect, useRef, useState } from 'react';
import { Activity, Gauge, Globe2, RefreshCw, Wifi, X } from 'lucide-react';

type Phase = 'idle' | 'ping' | 'download' | 'upload' | 'done' | 'error';

function SpeedGauge({
  label,
  value,
  unit,
  color,
  active,
}: {
  label: string;
  value: number;
  unit: string;
  color: string;
  active: boolean;
}) {
  const max = 200;
  const pct = Math.max(0, Math.min(1, value / max));
  const radius = 62;
  const cx = 80;
  const cy = 80;
  const start = Math.PI * 0.78;
  const end = Math.PI * 2.22;
  const point = (t: number) => ({
    x: cx + radius * Math.cos(start + (end - start) * t),
    y: cy + radius * Math.sin(start + (end - start) * t),
  });
  const arcPath = (t: number) => {
    const p = point(t);
    const large = (end - start) * t > Math.PI ? 1 : 0;
    return `M ${point(0).x} ${point(0).y} A ${radius} ${radius} 0 ${large} 1 ${p.x} ${p.y}`;
  };
  const needle = point(pct);
  return (
    <div className={`flex flex-col items-center gap-1 transition ${active ? 'opacity-100' : 'opacity-80'}`}>
      <svg viewBox="0 0 160 160" className="w-[min(38vw,180px)] h-[min(38vw,180px)] drop-shadow-[0_0_16px_rgba(139,69,19,0.35)]">
        <path d={arcPath(1)} fill="none" stroke="rgba(255,255,255,0.08)" strokeWidth="7" strokeLinecap="round" />
        <path d={arcPath(Math.max(0.001, pct))} fill="none" stroke={color} strokeWidth="7" strokeLinecap="round" className="transition-all duration-300" />
        {[0, 0.25, 0.5, 0.75, 1].map((t) => {
          const p1 = point(t);
          const inner = 0.86;
          const q1 = { x: cx + radius * inner * Math.cos(start + (end - start) * t), y: cy + radius * inner * Math.sin(start + (end - start) * t) };
          return <line key={t} x1={q1.x} y1={q1.y} x2={p1.x} y2={p1.y} stroke="rgba(255,255,255,0.18)" strokeWidth="1.5" />;
        })}
        <line x1={cx} y1={cy} x2={needle.x} y2={needle.y} stroke={color} strokeWidth="2" strokeLinecap="round" />
        <circle cx={cx} cy={cy} r="5" fill={color} className="drop-shadow-[0_0_6px_currentColor]" />
        <text x={cx} y={cy + 34} textAnchor="middle" className="fill-amber-100 font-mono-tech" fontSize="21" fontWeight="700">
          {value.toFixed(1)}
        </text>
        <text x={cx} y={cy + 48} textAnchor="middle" fill="#D2691E" className="font-mono-tech" fontSize="9">
          {unit}
        </text>
      </svg>
      <div className="text-[10px] font-mono-tech uppercase tracking-[0.2em] text-[#D2691E]/90">{label}</div>
    </div>
  );
}

export default function InternetSpeedPanel() {
  const [open, setOpen] = useState(false);
  const [phase, setPhase] = useState<Phase>('idle');
  const [down, setDown] = useState(0);
  const [up, setUp] = useState(0);
  const [ping, setPing] = useState<number | null>(null);
  const [jitter, setJitter] = useState<number | null>(null);
  const [progress, setProgress] = useState(0);
  const [payloadMb, setPayloadMb] = useState(8);
  const [error, setError] = useState('');
  const abortRef = useRef<AbortController | null>(null);
  const openRef = useRef(false);
  openRef.current = open;

  useEffect(() => {
    const onToggle = (ev: Event) => {
      const detail = (ev as CustomEvent<{ open?: boolean }>).detail;
      setOpen(typeof detail?.open === 'boolean' ? detail.open : !openRef.current);
    };
    window.addEventListener('barbi:toggle-speedtest', onToggle as EventListener);
    return () => window.removeEventListener('barbi:toggle-speedtest', onToggle as EventListener);
  }, []);

  const measurePing = useCallback(async (signal: AbortSignal) => {
    const samples: number[] = [];
    for (let i = 0; i < 4; i++) {
      const t0 = performance.now();
      const r = await fetch(`/api/speedtest/ping?cb=${Date.now()}-${i}`, { cache: 'no-store', signal });
      await r.arrayBuffer();
      samples.push(performance.now() - t0);
    }
    const avg = samples.reduce((a, b) => a + b, 0) / samples.length;
    const spread = Math.max(...samples) - Math.min(...samples);
    setPing(Number(avg.toFixed(1)));
    setJitter(Number(spread.toFixed(1)));
  }, []);

  const measureDownload = useCallback(async (signal: AbortSignal) => {
    const bytesTarget = payloadMb * 1024 * 1024;
    const started = performance.now();
    const res = await fetch(`/api/speedtest/download?bytes=${bytesTarget}&cb=${Date.now()}`, { cache: 'no-store', signal });
    if (!res.ok || !res.body) throw new Error('Download endpoint unavailable');
    const total = Number(res.headers.get('Content-Length') || bytesTarget);
    const reader = res.body.getReader();
    let received = 0;
    for (;;) {
      const { done, value } = await reader.read();
      if (done) break;
      received += value.byteLength;
      setProgress(Math.min(1, received / total));
    }
    const secs = (performance.now() - started) / 1000;
    setDown(Number(((received * 8) / secs / 1_000_000).toFixed(2)));
  }, [payloadMb]);

  const measureUpload = useCallback(async (signal: AbortSignal) => {
    const size = payloadMb * 1024 * 1024;
    const payload = new Uint8Array(size);
    for (let i = 0; i < size; i += 65536) {
      crypto.getRandomValues(payload.subarray(i, Math.min(i + 65536, size)));
    }
    const started = performance.now();
    const res = await fetch('/api/speedtest/upload', {
      method: 'POST',
      headers: { 'Content-Type': 'application/octet-stream' },
      body: payload,
      signal,
    });
    if (!res.ok) throw new Error('Upload endpoint unavailable');
    await res.json();
    const secs = (performance.now() - started) / 1000;
    setUp(Number(((size * 8) / secs / 1_000_000).toFixed(2)));
  }, [payloadMb]);

  const runTest = useCallback(async () => {
    abortRef.current?.abort();
    const controller = new AbortController();
    abortRef.current = controller;
    setError('');
    setDown(0);
    setUp(0);
    setPing(null);
    setJitter(null);
    setProgress(0);
    try {
      setPhase('ping');
      await measurePing(controller.signal);
      setPhase('download');
      await measureDownload(controller.signal);
      setPhase('upload');
      await measureUpload(controller.signal);
      setPhase('done');
    } catch (err) {
      if ((err as Error).name !== 'AbortError') {
        setError((err as Error).message || 'Speed test failed');
        setPhase('error');
      }
    }
  }, [measurePing, measureDownload, measureUpload]);

  useEffect(() => () => abortRef.current?.abort(), []);

  if (!open) return null;

  const busy = phase === 'ping' || phase === 'download' || phase === 'upload';
  const phaseLabel = {
    idle: 'READY',
    ping: 'PINGING GATEWAY',
    download: 'MEASURING DOWNLOAD',
    upload: 'MEASURING UPLOAD',
    done: 'TEST COMPLETE',
    error: 'ERROR',
  }[phase];

  return (
    <section
      id="barbi-speedtest-panel"
      aria-label="B.A.R.B.I Internet Speed Test"
      className="barbi-agent-panel fixed right-4 bottom-4 z-50 w-[min(calc(100vw-2rem),640px)] h-[min(88dvh,700px)] flex flex-col overflow-hidden text-stone-100"
    >
      <header className="barbi-agent-header flex items-center justify-between gap-2 px-3.5 py-2.5 shrink-0">
        <div className="flex items-center gap-2 min-w-0">
          <span className="w-8 h-8 rounded bg-[#8B4513]/40 border border-[#D2691E]/70 flex items-center justify-center text-[#FBBF24]">
            <Gauge className="w-4 h-4" />
          </span>
          <div className="min-w-0">
            <div className="text-[13px] font-semibold tracking-wide text-[#FBBF24] truncate">NETWORK SPEED TEST</div>
            <div className="text-[9px] font-mono-tech text-[#D2691E]/90 truncate">Real-time throughput · {phaseLabel}</div>
          </div>
        </div>
        <button type="button" onClick={() => setOpen(false)} title="Close" className="p-1.5 rounded text-[#D2691E] hover:bg-white/10 transition">
          <X className="w-3.5 h-3.5" />
        </button>
      </header>

      <div className="flex-1 min-h-0 overflow-auto p-4 flex flex-col gap-4">
        <div className="grid grid-cols-2 gap-2">
          <SpeedGauge label="Download" value={down} unit="Mbps" color="#FBBF24" active={phase === 'download' || phase === 'done'} />
          <SpeedGauge label="Upload" value={up} unit="Mbps" color="#4ADE80" active={phase === 'upload' || phase === 'done'} />
        </div>

        <div className="grid grid-cols-2 gap-2">
          <div className="px-3 py-2 rounded border border-[#8B4513]/50 bg-white/[0.02]">
            <div className="text-[9px] font-mono-tech uppercase tracking-wider text-[#D2691E]/85 flex items-center gap-1.5"><Activity className="w-3 h-3" /> Latency</div>
            <div className="text-lg font-mono-tech text-amber-100">{ping !== null ? `${ping} ms` : '—'}</div>
          </div>
          <div className="px-3 py-2 rounded border border-[#8B4513]/50 bg-white/[0.02]">
            <div className="text-[9px] font-mono-tech uppercase tracking-wider text-[#D2691E]/85 flex items-center gap-1.5"><Globe2 className="w-3 h-3" /> Jitter</div>
            <div className="text-lg font-mono-tech text-amber-100">{jitter !== null ? `${jitter} ms` : '—'}</div>
          </div>
        </div>

        <div className="space-y-1.5">
          <div className="flex items-center justify-between text-[10px] font-mono-tech text-[#D2691E]/85">
            <span>Transfer progress</span>
            <span>{Math.round(progress * 100)}%</span>
          </div>
          <div className="h-1.5 bg-white/10 overflow-hidden">
            <div className="h-full bg-gradient-to-r from-[#8B4513] via-[#D2691E] to-[#FBBF24] transition-all duration-200" style={{ width: `${progress * 100}%` }} />
          </div>
        </div>

        {error && <div className="text-[10px] font-mono-tech text-rose-300">ERROR · {error}</div>}

        <div className="mt-auto flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={() => void runTest()}
            disabled={busy}
            className="flex items-center gap-1.5 px-3 py-2 rounded bg-[#8B4513]/50 border border-[#D2691E]/70 text-[#FBBF24] text-[10px] font-mono-tech hover:bg-[#8B4513]/75 transition disabled:opacity-50"
          >
            <Wifi className="w-3.5 h-3.5" /> {busy ? 'Testing…' : 'Start Real Test'}
          </button>
          <button
            type="button"
            onClick={() => { abortRef.current?.abort(); setPhase('idle'); setDown(0); setUp(0); setPing(null); setJitter(null); setProgress(0); }}
            className="flex items-center gap-1.5 px-2.5 py-2 rounded bg-white/5 border border-white/15 text-stone-300 text-[10px] font-mono-tech hover:bg-white/10 transition"
          >
            <RefreshCw className="w-3 h-3" /> Reset
          </button>
          <div className="ml-auto flex items-center gap-1.5 text-[9px] font-mono-tech text-[#D2691E]/80">
            {[2, 8, 20].map((mb) => (
              <button
                key={mb}
                type="button"
                onClick={() => setPayloadMb(mb)}
                className={`px-2 py-1 rounded border transition ${payloadMb === mb ? 'border-[#D2691E]/80 bg-[#8B4513]/40 text-[#FBBF24]' : 'border-white/15 text-stone-400 hover:text-stone-100'}`}
              >
                {mb}MB
              </button>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
