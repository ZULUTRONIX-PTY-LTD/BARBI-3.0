import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  AlertTriangle,
  Archive,
  Check,
  Edit3,
  Inbox,
  LogOut,
  Mail,
  MailOpen,
  Paperclip,
  RefreshCw,
  Reply,
  RotateCcw,
  Search,
  Send,
  ShieldCheck,
  Star,
  Tag,
  Trash2,
  X,
} from 'lucide-react';
import type { User } from 'firebase/auth';
import {
  clearWorkspaceAccessToken,
  getCurrentFirebaseUser,
  getWorkspaceAccessToken,
  initWorkspaceAuth,
  signInWithGoogleWorkspace,
  signOutBarbi,
} from '../lib/firebase';
import {
  createGmailDraft,
  deleteGmailMessagePermanently,
  fetchGmailLabels,
  fetchGmailProfile,
  getGmailMessage,
  GmailAuthExpiredError,
  listGmailMessages,
  modifyGmailMessageLabels,
  sendGmailMessage,
  trashGmailMessage,
  untrashGmailMessage,
} from '../gmail/gmailApiClient';
import {
  formatGmailShortDate,
  validateEmailDraft,
  type GmailDraftInput,
  type GmailLabel,
  type GmailMessageDetail,
  type GmailProfile,
} from '../gmail/gmailLogic';

type FolderId = 'INBOX' | 'STARRED' | 'SENT' | 'DRAFT' | 'ALL' | 'TRASH' | string;

type PendingGmailMutation =
  | { kind: 'send'; draft: GmailDraftInput }
  | { kind: 'save_draft'; draft: GmailDraftInput }
  | { kind: 'archive'; message: GmailMessageDetail }
  | { kind: 'toggle_read'; message: GmailMessageDetail; markAsRead: boolean }
  | { kind: 'toggle_star'; message: GmailMessageDetail; star: boolean }
  | { kind: 'trash'; message: GmailMessageDetail }
  | { kind: 'untrash'; message: GmailMessageDetail }
  | { kind: 'delete_permanent'; message: GmailMessageDetail };

interface GmailToggleEventDetail {
  open?: boolean;
}

const SYSTEM_FOLDERS: ReadonlyArray<{ id: FolderId; label: string }> = [
  { id: 'INBOX', label: 'Inbox' },
  { id: 'STARRED', label: 'Starred' },
  { id: 'SENT', label: 'Sent' },
  { id: 'DRAFT', label: 'Drafts' },
  { id: 'ALL', label: 'All Mail' },
  { id: 'TRASH', label: 'Trash' },
];

function formatBytes(size: number): string {
  if (!Number.isFinite(size) || size <= 0) return '0 B';
  if (size < 1024) return `${size} B`;
  if (size < 1024 * 1024) return `${(size / 1024).toFixed(1)} KB`;
  return `${(size / (1024 * 1024)).toFixed(1)} MB`;
}

function describeMutation(action: PendingGmailMutation): {
  title: string;
  confirmLabel: string;
  danger: boolean;
  details: Array<{ label: string; value: string }>;
  warning?: string;
} {
  switch (action.kind) {
    case 'send':
      return {
        title: 'Confirm Send Email',
        confirmLabel: 'Send Email',
        danger: false,
        details: [
          { label: 'To', value: action.draft.to },
          ...(action.draft.cc?.trim() ? [{ label: 'Cc', value: action.draft.cc.trim() }] : []),
          { label: 'Subject', value: action.draft.subject },
          {
            label: 'Preview',
            value:
              action.draft.body.length > 160
                ? `${action.draft.body.slice(0, 160)}…`
                : action.draft.body,
          },
        ],
        warning: 'This will immediately transmit the email from your Gmail account.',
      };
    case 'save_draft':
      return {
        title: 'Confirm Save Draft',
        confirmLabel: 'Save Draft',
        danger: false,
        details: [
          { label: 'To', value: action.draft.to || '(No recipient)' },
          { label: 'Subject', value: action.draft.subject || '(No subject)' },
        ],
      };
    case 'archive':
      return {
        title: 'Confirm Archive Message',
        confirmLabel: 'Archive',
        danger: false,
        details: [
          { label: 'Subject', value: action.message.subject },
          { label: 'From', value: action.message.fromName || action.message.from },
        ],
        warning: 'This removes the message from your Inbox label. It remains accessible in All Mail.',
      };
    case 'toggle_read':
      return {
        title: action.markAsRead ? 'Confirm Mark as Read' : 'Confirm Mark as Unread',
        confirmLabel: action.markAsRead ? 'Mark Read' : 'Mark Unread',
        danger: false,
        details: [
          { label: 'Subject', value: action.message.subject },
          { label: 'From', value: action.message.fromName || action.message.from },
        ],
      };
    case 'toggle_star':
      return {
        title: action.star ? 'Confirm Add Star' : 'Confirm Remove Star',
        confirmLabel: action.star ? 'Add Star' : 'Remove Star',
        danger: false,
        details: [
          { label: 'Subject', value: action.message.subject },
          { label: 'From', value: action.message.fromName || action.message.from },
        ],
      };
    case 'trash':
      return {
        title: 'Confirm Move to Trash',
        confirmLabel: 'Move to Trash',
        danger: true,
        details: [
          { label: 'Subject', value: action.message.subject },
          { label: 'From', value: action.message.fromName || action.message.from },
        ],
        warning: 'Messages in Trash are automatically deleted by Gmail after 30 days.',
      };
    case 'untrash':
      return {
        title: 'Confirm Restore Message',
        confirmLabel: 'Restore from Trash',
        danger: false,
        details: [
          { label: 'Subject', value: action.message.subject },
          { label: 'From', value: action.message.fromName || action.message.from },
        ],
      };
    case 'delete_permanent':
      return {
        title: 'Confirm Permanent Deletion',
        confirmLabel: 'Delete Permanently',
        danger: true,
        details: [
          { label: 'Subject', value: action.message.subject },
          { label: 'From', value: action.message.fromName || action.message.from },
        ],
        warning: 'This action permanently deletes the email from Gmail and CANNOT be undone.',
      };
  }
}

export const GmailWorkspacePanel: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [authUser, setAuthUser] = useState<User | null>(() => getCurrentFirebaseUser());
  const [accessToken, setAccessToken] = useState<string | null>(() => getWorkspaceAccessToken());
  const [authLoading, setAuthLoading] = useState(false);
  const [authError, setAuthError] = useState<string | null>(null);

  const [profile, setProfile] = useState<GmailProfile | null>(null);
  const [labels, setLabels] = useState<GmailLabel[]>([]);
  const [activeFolder, setActiveFolder] = useState<FolderId>('INBOX');
  const [searchInput, setSearchInput] = useState('');
  const [activeQuery, setActiveQuery] = useState('');

  const [messages, setMessages] = useState<GmailMessageDetail[]>([]);
  const [nextPageToken, setNextPageToken] = useState<string | undefined>(undefined);
  const [loadingList, setLoadingList] = useState(false);
  const [loadingMore, setLoadingMore] = useState(false);

  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [selectedMessage, setSelectedMessage] = useState<GmailMessageDetail | null>(null);
  const [loadingDetail, setLoadingDetail] = useState(false);

  const [composeOpen, setComposeOpen] = useState(false);
  const [draft, setDraft] = useState<GmailDraftInput>({
    to: '',
    cc: '',
    subject: '',
    body: '',
  });
  const [composeError, setComposeError] = useState<string | null>(null);

  const [pendingAction, setPendingAction] = useState<PendingGmailMutation | null>(null);
  const [mutating, setMutating] = useState(false);
  const [statusNotice, setStatusNotice] = useState<{ tone: 'ok' | 'error'; text: string } | null>(
    null
  );

  const noticeTimeoutRef = useRef<number | null>(null);

  const showNotice = useCallback((tone: 'ok' | 'error', text: string) => {
    setStatusNotice({ tone, text });
    if (noticeTimeoutRef.current) {
      window.clearTimeout(noticeTimeoutRef.current);
    }
    noticeTimeoutRef.current = window.setTimeout(() => {
      setStatusNotice(null);
    }, 5200);
  }, []);

  useEffect(() => {
    return () => {
      if (noticeTimeoutRef.current) {
        window.clearTimeout(noticeTimeoutRef.current);
      }
    };
  }, []);

  // Listen to global toggle event + sync aria-expanded on HUD button
  useEffect(() => {
    const onToggle = (ev: Event) => {
      const detail = (ev as CustomEvent<GmailToggleEventDetail>).detail;
      if (typeof detail?.open === 'boolean') {
        setIsOpen(detail.open);
      } else {
        setIsOpen((prev) => !prev);
      }
    };
    window.addEventListener('barbi:toggle-gmail', onToggle as EventListener);
    return () => window.removeEventListener('barbi:toggle-gmail', onToggle as EventListener);
  }, []);

  useEffect(() => {
    const hudBtn = document.getElementById('btn-gmail-hud');
    if (hudBtn) {
      hudBtn.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
    }
    const win = window as unknown as {
      __barbiGmailState?: {
        open: boolean;
        authenticated: boolean;
        accountEmail: string | null;
        activeFolder: string;
        messageCount: number;
      };
    };
    win.__barbiGmailState = {
      open: isOpen,
      authenticated: Boolean(accessToken),
      accountEmail: profile?.emailAddress || authUser?.email || null,
      activeFolder,
      messageCount: messages.length,
    };
  }, [isOpen, accessToken, profile, authUser, activeFolder, messages.length]);

  // Escape key handling: dismiss confirmation dialog first, else close workspace
  useEffect(() => {
    if (!isOpen) return;
    const onKeyDown = (ev: KeyboardEvent) => {
      if (ev.key === 'Escape') {
        if (pendingAction && !mutating) {
          setPendingAction(null);
        } else if (!mutating) {
          setIsOpen(false);
        }
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [isOpen, pendingAction, mutating]);

  // Subscribe to Firebase auth state (in-memory OAuth token only)
  useEffect(() => {
    const unsubscribe = initWorkspaceAuth(
      (user, token) => {
        setAuthUser(user);
        setAccessToken(token);
        setAuthError(null);
      },
      () => {
        setAuthUser(getCurrentFirebaseUser());
        setAccessToken(null);
      }
    );
    return unsubscribe;
  }, []);

  const handleAuthExpired = useCallback((err: unknown): boolean => {
    if (err instanceof GmailAuthExpiredError) {
      clearWorkspaceAccessToken();
      setAccessToken(null);
      setProfile(null);
      setAuthError(err.message);
      return true;
    }
    return false;
  }, []);

  const loadMailbox = useCallback(
    async (
      token: string,
      folder: FolderId,
      query: string,
      options?: { appendPageToken?: string }
    ) => {
      const isAppending = Boolean(options?.appendPageToken);
      if (isAppending) {
        setLoadingMore(true);
      } else {
        setLoadingList(true);
      }
      try {
        const res = await listGmailMessages(token, {
          labelId: folder,
          q: query,
          maxResults: 20,
          pageToken: options?.appendPageToken,
          includeSpamTrash: folder === 'TRASH',
        });
        setNextPageToken(res.nextPageToken);
        if (isAppending) {
          setMessages((prev) => {
            const seen = new Set(prev.map((m) => m.id));
            return [...prev, ...res.messages.filter((m) => !seen.has(m.id))];
          });
        } else {
          setMessages(res.messages);
        }
      } catch (err) {
        if (!handleAuthExpired(err)) {
          const msg = err instanceof Error ? err.message : 'Unable to load Gmail messages.';
          showNotice('error', msg);
        }
      } finally {
        if (isAppending) {
          setLoadingMore(false);
        } else {
          setLoadingList(false);
        }
      }
    },
    [handleAuthExpired, showNotice]
  );

  // Hydrate profile, labels & inbox whenever panel opens with a valid token
  useEffect(() => {
    if (!isOpen || !accessToken) return;
    let cancelled = false;

    const bootstrap = async () => {
      try {
        const [prof, lbls] = await Promise.all([
          fetchGmailProfile(accessToken),
          fetchGmailLabels(accessToken),
        ]);
        if (cancelled) return;
        setProfile(prof);
        setLabels(lbls);
      } catch (err) {
        if (!cancelled && !handleAuthExpired(err)) {
          showNotice(
            'error',
            err instanceof Error ? err.message : 'Failed to load Gmail profile.'
          );
        }
      }
    };

    void bootstrap();
    return () => {
      cancelled = true;
    };
  }, [isOpen, accessToken, handleAuthExpired, showNotice]);

  useEffect(() => {
    if (!isOpen || !accessToken) return;
    void loadMailbox(accessToken, activeFolder, activeQuery);
  }, [isOpen, accessToken, activeFolder, activeQuery, loadMailbox]);

  const handleSelectMessage = useCallback(
    async (msg: GmailMessageDetail) => {
      setComposeOpen(false);
      setSelectedId(msg.id);
      setSelectedMessage(msg);
      if (!accessToken) return;

      setLoadingDetail(true);
      try {
        const full = await getGmailMessage(accessToken, msg.id);
        setSelectedMessage(full);
      } catch (err) {
        if (!handleAuthExpired(err)) {
          showNotice('error', err instanceof Error ? err.message : 'Could not load full email.');
        }
      } finally {
        setLoadingDetail(false);
      }
    },
    [accessToken, handleAuthExpired, showNotice]
  );

  const handleGoogleSignIn = async () => {
    setAuthLoading(true);
    setAuthError(null);
    try {
      const { user, accessToken: freshToken } = await signInWithGoogleWorkspace();
      setAuthUser(user);
      setAccessToken(freshToken);
      showNotice('ok', `Connected Gmail as ${user.email || 'Google account'}.`);
    } catch (err) {
      const code = (err as { code?: string })?.code || '';
      if (code === 'auth/popup-closed-by-user') {
        setAuthError('Sign-in window was closed before completing Gmail authorization.');
      } else if (code === 'auth/popup-blocked') {
        setAuthError('Popup blocked by browser. Please allow popups for this site and try again.');
      } else {
        setAuthError(
          err instanceof Error ? err.message : 'Failed to sign in with Google for Gmail access.'
        );
      }
    } finally {
      setAuthLoading(false);
    }
  };

  const handleDisconnect = async () => {
    try {
      await signOutBarbi();
    } catch {
      clearWorkspaceAccessToken();
    }
    setAccessToken(null);
    setAuthUser(null);
    setProfile(null);
    setLabels([]);
    setMessages([]);
    setSelectedId(null);
    setSelectedMessage(null);
    setComposeOpen(false);
    setPendingAction(null);
    setAuthError(null);
  };

  const handleOpenCompose = () => {
    setComposeError(null);
    setDraft({ to: '', cc: '', subject: '', body: '' });
    setComposeOpen(true);
  };

  const handleOpenReply = (msg: GmailMessageDetail) => {
    const replyTo = msg.fromEmail || msg.from;
    const replySubject = /^re:/i.test(msg.subject) ? msg.subject : `Re: ${msg.subject}`;
    setComposeError(null);
    setDraft({
      to: replyTo,
      cc: '',
      subject: replySubject,
      body: '',
      threadId: msg.threadId,
      inReplyTo: msg.messageIdHeader || undefined,
    });
    setComposeOpen(true);
  };

  const requestSendConfirm = () => {
    const check = validateEmailDraft(draft);
    if (!check.ok) {
      setComposeError(check.error);
      return;
    }
    setComposeError(null);
    setPendingAction({ kind: 'send', draft: { ...draft } });
  };

  const requestSaveDraftConfirm = () => {
    if (!draft.to.trim() && !draft.subject.trim() && !draft.body.trim()) {
      setComposeError('Enter at least a recipient, subject, or message body to save a draft.');
      return;
    }
    setComposeError(null);
    setPendingAction({ kind: 'save_draft', draft: { ...draft } });
  };

  const executeConfirmedAction = async () => {
    if (!pendingAction || !accessToken) return;
    setMutating(true);
    try {
      switch (pendingAction.kind) {
        case 'send': {
          await sendGmailMessage(accessToken, pendingAction.draft);
          setComposeOpen(false);
          setDraft({ to: '', cc: '', subject: '', body: '' });
          showNotice('ok', `Email sent to ${pendingAction.draft.to}.`);
          void loadMailbox(accessToken, activeFolder, activeQuery);
          break;
        }
        case 'save_draft': {
          await createGmailDraft(accessToken, pendingAction.draft);
          setComposeOpen(false);
          setDraft({ to: '', cc: '', subject: '', body: '' });
          showNotice('ok', 'Draft saved to your Gmail Drafts folder.');
          if (activeFolder === 'DRAFT') {
            void loadMailbox(accessToken, activeFolder, activeQuery);
          }
          break;
        }
        case 'archive': {
          await modifyGmailMessageLabels(accessToken, pendingAction.message.id, {
            removeLabelIds: ['INBOX'],
          });
          setMessages((prev) =>
            activeFolder === 'INBOX'
              ? prev.filter((m) => m.id !== pendingAction.message.id)
              : prev.map((m) =>
                  m.id === pendingAction.message.id
                    ? { ...m, isInInbox: false, labelIds: m.labelIds.filter((l) => l !== 'INBOX') }
                    : m
                )
          );
          if (selectedId === pendingAction.message.id) {
            if (activeFolder === 'INBOX') {
              setSelectedId(null);
              setSelectedMessage(null);
            } else {
              setSelectedMessage((prev) =>
                prev
                  ? {
                      ...prev,
                      isInInbox: false,
                      labelIds: prev.labelIds.filter((l) => l !== 'INBOX'),
                    }
                  : prev
              );
            }
          }
          showNotice('ok', 'Message archived.');
          break;
        }
        case 'toggle_read': {
          await modifyGmailMessageLabels(
            accessToken,
            pendingAction.message.id,
            pendingAction.markAsRead
              ? { removeLabelIds: ['UNREAD'] }
              : { addLabelIds: ['UNREAD'] }
          );
          const nextUnread = !pendingAction.markAsRead;
          setMessages((prev) =>
            prev.map((m) =>
              m.id === pendingAction.message.id ? { ...m, isUnread: nextUnread } : m
            )
          );
          if (selectedId === pendingAction.message.id) {
            setSelectedMessage((prev) => (prev ? { ...prev, isUnread: nextUnread } : prev));
          }
          showNotice('ok', pendingAction.markAsRead ? 'Marked as read.' : 'Marked as unread.');
          break;
        }
        case 'toggle_star': {
          await modifyGmailMessageLabels(
            accessToken,
            pendingAction.message.id,
            pendingAction.star ? { addLabelIds: ['STARRED'] } : { removeLabelIds: ['STARRED'] }
          );
          setMessages((prev) =>
            prev.map((m) =>
              m.id === pendingAction.message.id ? { ...m, isStarred: pendingAction.star } : m
            )
          );
          if (selectedId === pendingAction.message.id) {
            setSelectedMessage((prev) =>
              prev ? { ...prev, isStarred: pendingAction.star } : prev
            );
          }
          showNotice('ok', pendingAction.star ? 'Message starred.' : 'Star removed.');
          break;
        }
        case 'trash': {
          await trashGmailMessage(accessToken, pendingAction.message.id);
          setMessages((prev) => prev.filter((m) => m.id !== pendingAction.message.id));
          if (selectedId === pendingAction.message.id) {
            setSelectedId(null);
            setSelectedMessage(null);
          }
          showNotice('ok', 'Message moved to Trash.');
          break;
        }
        case 'untrash': {
          await untrashGmailMessage(accessToken, pendingAction.message.id);
          setMessages((prev) => prev.filter((m) => m.id !== pendingAction.message.id));
          if (selectedId === pendingAction.message.id) {
            setSelectedId(null);
            setSelectedMessage(null);
          }
          showNotice('ok', 'Message restored from Trash.');
          break;
        }
        case 'delete_permanent': {
          await deleteGmailMessagePermanently(accessToken, pendingAction.message.id);
          setMessages((prev) => prev.filter((m) => m.id !== pendingAction.message.id));
          if (selectedId === pendingAction.message.id) {
            setSelectedId(null);
            setSelectedMessage(null);
          }
          showNotice('ok', 'Message permanently deleted.');
          break;
        }
      }
      setPendingAction(null);
    } catch (err) {
      setPendingAction(null);
      if (!handleAuthExpired(err)) {
        showNotice('error', err instanceof Error ? err.message : 'Gmail action failed.');
      }
    } finally {
      setMutating(false);
    }
  };

  const userLabels = useMemo(
    () =>
      labels
        .filter((l) => l.type === 'user')
        .sort((a, b) => a.name.localeCompare(b.name))
        .slice(0, 14),
    [labels]
  );

  const mutationCopy = useMemo(
    () => (pendingAction ? describeMutation(pendingAction) : null),
    [pendingAction]
  );

  if (!isOpen) return null;

  const needsAuth = !accessToken;

  return (
    <div
      id="barbi-gmail-panel"
      role="dialog"
      aria-modal="true"
      aria-label="B.A.R.B.I. Gmail Workspace"
      className="fixed inset-0 z-[130] flex items-center justify-center bg-black/75 backdrop-blur-md p-3 sm:p-5"
      onClick={(ev) => {
        if (ev.target === ev.currentTarget && !pendingAction && !mutating) {
          setIsOpen(false);
        }
      }}
    >
      <div className="barbi-scifi-shell relative flex flex-col w-full max-w-6xl h-[min(86vh,780px)] overflow-hidden text-stone-100">
        {/* Top Header */}
        <header className="flex items-center justify-between gap-3 px-4 py-3 border-b border-[#8B4513]/45 bg-transparent backdrop-blur-xl shrink-0">
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-8 h-8 rounded-lg bg-amber-500/15 border border-amber-400/40 flex items-center justify-center text-amber-300 shrink-0">
              <Mail className="w-4 h-4" />
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-2">
                <h2 className="text-sm font-semibold tracking-wide text-white truncate">
                  B.A.R.B.I. Gmail Workspace
                </h2>
                {profile?.emailAddress && (
                  <span className="hidden sm:inline-block text-[11px] font-mono-tech text-amber-300/90 truncate">
                    {profile.emailAddress}
                  </span>
                )}
              </div>
              <p className="text-[11px] text-slate-400 truncate">
                {needsAuth
                  ? 'Google Workspace OAuth · Client-side in-memory session'
                  : `${profile?.messagesTotal?.toLocaleString() ?? 0} messages · ${profile?.threadsTotal?.toLocaleString() ?? 0} threads`}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            {!needsAuth && (
              <>
                <button
                  type="button"
                  onClick={handleOpenCompose}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-black text-xs font-semibold transition cursor-pointer whitespace-nowrap shrink-0"
                >
                  <Edit3 className="w-3.5 h-3.5" />
                  <span>Compose</span>
                </button>
                <button
                  type="button"
                  onClick={() => accessToken && void loadMailbox(accessToken, activeFolder, activeQuery)}
                  disabled={loadingList}
                  title="Refresh mailbox"
                  className="inline-flex items-center justify-center w-8 h-8 rounded-lg border border-white/15 bg-white/5 hover:bg-white/10 text-slate-200 transition cursor-pointer disabled:opacity-50"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${loadingList ? 'animate-spin' : ''}`} />
                </button>
                <button
                  type="button"
                  onClick={() => void handleDisconnect()}
                  title="Sign out of Google Workspace"
                  className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border border-white/15 bg-white/5 hover:bg-red-500/20 hover:border-red-400/40 text-xs text-slate-200 transition cursor-pointer whitespace-nowrap shrink-0"
                >
                  <LogOut className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">Sign Out</span>
                </button>
              </>
            )}
            <button
              type="button"
              onClick={() => setIsOpen(false)}
              aria-label="Close Gmail Workspace"
              className="inline-flex items-center justify-center w-8 h-8 rounded-lg border border-white/15 bg-white/5 hover:bg-white/15 text-slate-300 hover:text-white transition cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </header>

        {/* Status Toast Strip */}
        {statusNotice && (
          <div
            role="status"
            className={`px-4 py-2 text-xs flex items-center justify-between gap-2 border-b shrink-0 ${
              statusNotice.tone === 'ok'
                ? 'bg-emerald-950/60 border-emerald-500/30 text-emerald-200'
                : 'bg-red-950/60 border-red-500/35 text-red-200'
            }`}
          >
            <div className="flex items-center gap-2 min-w-0">
              {statusNotice.tone === 'ok' ? (
                <Check className="w-3.5 h-3.5 shrink-0" />
              ) : (
                <AlertTriangle className="w-3.5 h-3.5 shrink-0" />
              )}
              <span className="truncate">{statusNotice.text}</span>
            </div>
            <button
              type="button"
              onClick={() => setStatusNotice(null)}
              className="text-current opacity-70 hover:opacity-100 cursor-pointer"
              aria-label="Dismiss notification"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        )}

        {/* Main Body: Auth Gate OR 3-Pane Gmail Client */}
        {needsAuth ? (
          <div className="flex-1 flex items-center justify-center p-6 overflow-y-auto">
            <div className="barbi-scifi-shell w-full max-w-md p-7 text-center">
              <div className="mx-auto w-12 h-12 rounded-xl bg-amber-500/15 border border-amber-400/35 flex items-center justify-center text-amber-300 mb-4">
                <Mail className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-semibold text-white mb-2">
                Connect Your Gmail Account
              </h3>
              <p className="text-xs leading-relaxed text-slate-300 mb-5">
                Sign in with Google to read, search, compose, reply, organize labels, archive, and
                manage your Gmail directly inside B.A.R.B.I. OS.
              </p>

              <div className="rounded border border-[#8B4513]/45 bg-white/[0.02] backdrop-blur-xl p-3.5 text-left mb-6 space-y-2">
                <div className="flex items-start gap-2 text-[11px] text-slate-300">
                  <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                  <span>
                    OAuth access tokens stay strictly in memory for this session and are never
                    stored in local storage.
                  </span>
                </div>
                <div className="flex items-start gap-2 text-[11px] text-slate-300">
                  <ShieldCheck className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                  <span>
                    Every send, draft save, archive, trash, or delete action requires explicit
                    confirmation before executing.
                  </span>
                </div>
              </div>

              {authError && (
                <div
                  role="alert"
                  className="mb-4 rounded-lg bg-red-950/60 border border-red-500/40 px-3 py-2 text-left text-xs text-red-200"
                >
                  {authError}
                </div>
              )}

              {/* Official Google Branded "Sign in with Google" Button */}
              <div className="flex justify-center">
                <button
                  type="button"
                  data-testid="gmail-google-signin-btn"
                  disabled={authLoading}
                  onClick={() => void handleGoogleSignIn()}
                  className="gsi-material-button inline-flex items-center justify-center gap-3 h-10 px-4 rounded-md bg-white hover:bg-[#f8f9fa] active:bg-[#eeeeee] text-[#1f1f1f] border border-[#747775] shadow-sm transition cursor-pointer disabled:opacity-60 font-sans text-sm font-medium tracking-[0.25px]"
                >
                  <svg
                    className="w-[18px] h-[18px] shrink-0"
                    viewBox="0 0 48 48"
                    aria-hidden="true"
                  >
                    <path
                      fill="#EA4335"
                      d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"
                    />
                    <path
                      fill="#4285F4"
                      d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"
                    />
                    <path
                      fill="#FBBC05"
                      d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"
                    />
                    <path
                      fill="#34A853"
                      d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"
                    />
                    <path fill="none" d="M0 0h48v48H0z" />
                  </svg>
                  <span>{authLoading ? 'Signing in…' : 'Sign in with Google'}</span>
                </button>
              </div>
            </div>
          </div>
        ) : (
          <div className="flex-1 min-h-0 flex flex-col md:flex-row">
            {/* Left Folder & Label Rail */}
            <aside className="md:w-44 shrink-0 border-b md:border-b-0 md:border-r border-white/10 bg-transparent backdrop-blur-lg p-2 overflow-x-auto md:overflow-y-auto">
              <nav aria-label="Gmail folders" className="flex md:flex-col gap-1">
                {SYSTEM_FOLDERS.map((folder) => {
                  const active = activeFolder === folder.id;
                  return (
                    <button
                      key={folder.id}
                      type="button"
                      onClick={() => {
                        setActiveFolder(folder.id);
                        setSelectedId(null);
                        setSelectedMessage(null);
                      }}
                      className={`flex items-center gap-2 px-2.5 py-1.5 rounded-lg text-xs transition cursor-pointer whitespace-nowrap shrink-0 text-left ${
                        active
                          ? 'bg-amber-500/20 text-amber-200 border border-amber-400/40 font-semibold'
                          : 'text-slate-300 hover:bg-white/5 border border-transparent'
                      }`}
                    >
                      {folder.id === 'INBOX' && <Inbox className="w-3.5 h-3.5 shrink-0" />}
                      {folder.id === 'STARRED' && <Star className="w-3.5 h-3.5 shrink-0" />}
                      {folder.id === 'SENT' && <Send className="w-3.5 h-3.5 shrink-0" />}
                      {folder.id === 'DRAFT' && <Edit3 className="w-3.5 h-3.5 shrink-0" />}
                      {folder.id === 'ALL' && <Mail className="w-3.5 h-3.5 shrink-0" />}
                      {folder.id === 'TRASH' && <Trash2 className="w-3.5 h-3.5 shrink-0" />}
                      <span>{folder.label}</span>
                    </button>
                  );
                })}
              </nav>

              {userLabels.length > 0 && (
                <div className="hidden md:block mt-4 pt-3 border-t border-white/10">
                  <div className="px-2.5 mb-1.5 text-[10px] font-mono-tech uppercase tracking-wider text-slate-500">
                    Labels
                  </div>
                  <div className="flex flex-col gap-0.5">
                    {userLabels.map((lbl) => {
                      const active = activeFolder === lbl.id;
                      return (
                        <button
                          key={lbl.id}
                          type="button"
                          onClick={() => {
                            setActiveFolder(lbl.id);
                            setSelectedId(null);
                            setSelectedMessage(null);
                          }}
                          className={`flex items-center gap-2 px-2.5 py-1.5 rounded-lg text-xs transition cursor-pointer text-left truncate ${
                            active
                              ? 'bg-amber-500/20 text-amber-200 border border-amber-400/40 font-semibold'
                              : 'text-slate-300 hover:bg-white/5 border border-transparent'
                          }`}
                        >
                          <Tag className="w-3 h-3 shrink-0 text-slate-400" />
                          <span className="truncate">{lbl.name}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}
            </aside>

            {/* Middle Search & Message List */}
            <section className="md:w-80 lg:w-96 shrink-0 border-b md:border-b-0 md:border-r border-white/10 flex flex-col min-h-0 max-h-[38vh] md:max-h-none bg-transparent backdrop-blur-lg">
              <form
                className="p-2.5 border-b border-white/10 flex items-center gap-1.5 shrink-0"
                onSubmit={(ev) => {
                  ev.preventDefault();
                  setActiveQuery(searchInput.trim());
                }}
              >
                <div className="relative flex-1">
                  <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                  <input
                    type="search"
                    value={searchInput}
                    onChange={(ev) => setSearchInput(ev.target.value)}
                    placeholder="Search Gmail (from:, subject:, is:unread)…"
                    className="w-full pl-8 pr-7 py-1.5 rounded border border-[#8B4513]/45 bg-white/[0.03] backdrop-blur-md focus:border-amber-400/60 focus:outline-none text-xs text-white placeholder:text-slate-500"
                  />
                  {searchInput && (
                    <button
                      type="button"
                      onClick={() => {
                        setSearchInput('');
                        setActiveQuery('');
                      }}
                      aria-label="Clear search"
                      className="absolute right-2 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white cursor-pointer"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  )}
                </div>
                <button
                  type="submit"
                  className="px-2.5 py-1.5 rounded-lg bg-white/10 hover:bg-white/15 text-xs text-slate-200 transition cursor-pointer shrink-0"
                >
                  Go
                </button>
              </form>

              <div className="flex-1 overflow-y-auto divide-y divide-white/5">
                {loadingList ? (
                  <div className="p-6 text-center text-xs text-slate-400">Loading messages…</div>
                ) : messages.length === 0 ? (
                  <div className="p-6 text-center text-xs text-slate-400">
                    No messages found in this view.
                  </div>
                ) : (
                  <>
                    {messages.map((msg) => {
                      const selected = msg.id === selectedId && !composeOpen;
                      return (
                        <button
                          key={msg.id}
                          type="button"
                          onClick={() => void handleSelectMessage(msg)}
                          className={`w-full text-left px-3 py-2.5 transition cursor-pointer block ${
                            selected
                              ? 'bg-amber-500/15 border-l-2 border-l-amber-400'
                              : 'hover:bg-white/5 border-l-2 border-l-transparent'
                          }`}
                        >
                          <div className="flex items-center justify-between gap-2 mb-0.5">
                            <div className="flex items-center gap-1.5 min-w-0">
                              {msg.isUnread && (
                                <span
                                  className="w-1.5 h-1.5 rounded-full bg-amber-400 shrink-0"
                                  aria-label="Unread"
                                />
                              )}
                              <span
                                className={`text-xs truncate ${
                                  msg.isUnread ? 'font-semibold text-white' : 'text-slate-300'
                                }`}
                              >
                                {msg.fromName}
                              </span>
                            </div>
                            <div className="flex items-center gap-1 shrink-0">
                              {msg.isStarred && (
                                <Star className="w-3 h-3 text-amber-400 fill-amber-400" />
                              )}
                              <span className="text-[10px] font-mono-tech text-slate-400">
                                {formatGmailShortDate(msg.internalDateMs, msg.date)}
                              </span>
                            </div>
                          </div>
                          <div
                            className={`text-xs truncate mb-0.5 ${
                              msg.isUnread ? 'font-medium text-amber-100' : 'text-slate-200'
                            }`}
                          >
                            {msg.subject}
                          </div>
                          <div className="text-[11px] text-slate-400 line-clamp-2 leading-snug">
                            {msg.snippet}
                          </div>
                        </button>
                      );
                    })}
                    {nextPageToken && (
                      <div className="p-3 text-center">
                        <button
                          type="button"
                          disabled={loadingMore}
                          onClick={() =>
                            accessToken &&
                            void loadMailbox(accessToken, activeFolder, activeQuery, {
                              appendPageToken: nextPageToken,
                            })
                          }
                          className="px-3 py-1.5 rounded-lg border border-white/15 bg-white/5 hover:bg-white/10 text-xs text-slate-200 transition cursor-pointer disabled:opacity-50"
                        >
                          {loadingMore ? 'Loading…' : 'Load more messages'}
                        </button>
                      </div>
                    )}
                  </>
                )}
              </div>
            </section>

            {/* Right Detail / Compose Pane */}
            <main className="flex-1 min-w-0 min-h-0 flex flex-col bg-transparent backdrop-blur-lg">
              {composeOpen ? (
                <div className="flex-1 flex flex-col min-h-0 p-4 overflow-y-auto">
                  <div className="flex items-center justify-between gap-2 pb-3 mb-3 border-b border-white/10">
                    <h3 className="text-sm font-semibold text-white">
                      {draft.threadId ? 'Reply to Thread' : 'New Message'}
                    </h3>
                    <button
                      type="button"
                      onClick={() => setComposeOpen(false)}
                      className="text-xs text-slate-400 hover:text-white cursor-pointer"
                    >
                      Cancel
                    </button>
                  </div>

                  {composeError && (
                    <div
                      role="alert"
                      className="mb-3 rounded-lg bg-red-950/60 border border-red-500/40 px-3 py-2 text-xs text-red-200"
                    >
                      {composeError}
                    </div>
                  )}

                  <div className="space-y-2.5 flex-1 flex flex-col">
                    <label className="block">
                      <span className="block text-[11px] font-mono-tech text-slate-400 mb-1">
                        To
                      </span>
                      <input
                        type="text"
                        value={draft.to}
                        onChange={(ev) => setDraft((d) => ({ ...d, to: ev.target.value }))}
                        placeholder="recipient@example.com"
                        className="w-full px-3 py-1.5 rounded border border-[#8B4513]/45 bg-white/[0.03] backdrop-blur-md focus:border-amber-400/60 focus:outline-none text-xs text-white"
                      />
                    </label>
                    <label className="block">
                      <span className="block text-[11px] font-mono-tech text-slate-400 mb-1">
                        Cc (optional)
                      </span>
                      <input
                        type="text"
                        value={draft.cc || ''}
                        onChange={(ev) => setDraft((d) => ({ ...d, cc: ev.target.value }))}
                        placeholder="cc@example.com"
                        className="w-full px-3 py-1.5 rounded border border-[#8B4513]/45 bg-white/[0.03] backdrop-blur-md focus:border-amber-400/60 focus:outline-none text-xs text-white"
                      />
                    </label>
                    <label className="block">
                      <span className="block text-[11px] font-mono-tech text-slate-400 mb-1">
                        Subject
                      </span>
                      <input
                        type="text"
                        value={draft.subject}
                        onChange={(ev) => setDraft((d) => ({ ...d, subject: ev.target.value }))}
                        placeholder="Subject line"
                        className="w-full px-3 py-1.5 rounded border border-[#8B4513]/45 bg-white/[0.03] backdrop-blur-md focus:border-amber-400/60 focus:outline-none text-xs text-white"
                      />
                    </label>
                    <label className="flex-1 flex flex-col min-h-[160px]">
                      <span className="block text-[11px] font-mono-tech text-slate-400 mb-1">
                        Message
                      </span>
                      <textarea
                        value={draft.body}
                        onChange={(ev) => setDraft((d) => ({ ...d, body: ev.target.value }))}
                        placeholder="Write your email message…"
                        className="flex-1 w-full px-3 py-2 rounded border border-[#8B4513]/45 bg-white/[0.03] backdrop-blur-md focus:border-amber-400/60 focus:outline-none text-xs text-white leading-relaxed resize-none"
                      />
                    </label>
                  </div>

                  <div className="pt-3 mt-3 border-t border-white/10 flex items-center justify-end gap-2">
                    <button
                      type="button"
                      onClick={requestSaveDraftConfirm}
                      className="px-3 py-1.5 rounded-lg border border-white/15 bg-white/5 hover:bg-white/10 text-xs text-slate-200 transition cursor-pointer"
                    >
                      Save Draft
                    </button>
                    <button
                      type="button"
                      onClick={requestSendConfirm}
                      className="inline-flex items-center gap-1.5 px-4 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-black text-xs font-semibold transition cursor-pointer"
                    >
                      <Send className="w-3.5 h-3.5" />
                      <span>Send Email</span>
                    </button>
                  </div>
                </div>
              ) : selectedMessage ? (
                <div className="flex-1 flex flex-col min-h-0">
                  {/* Action Toolbar */}
                  <div className="px-4 py-2.5 border-b border-white/10 flex flex-wrap items-center gap-1.5 shrink-0 bg-black/35">
                    <button
                      type="button"
                      onClick={() => handleOpenReply(selectedMessage)}
                      className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-amber-500/20 hover:bg-amber-500/30 border border-amber-400/40 text-xs text-amber-200 transition cursor-pointer"
                    >
                      <Reply className="w-3.5 h-3.5" />
                      <span>Reply</span>
                    </button>
                    <button
                      type="button"
                      onClick={() =>
                        setPendingAction({
                          kind: 'toggle_read',
                          message: selectedMessage,
                          markAsRead: selectedMessage.isUnread,
                        })
                      }
                      className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg border border-white/15 bg-white/5 hover:bg-white/10 text-xs text-slate-200 transition cursor-pointer"
                    >
                      {selectedMessage.isUnread ? (
                        <MailOpen className="w-3.5 h-3.5" />
                      ) : (
                        <Mail className="w-3.5 h-3.5" />
                      )}
                      <span>{selectedMessage.isUnread ? 'Mark Read' : 'Mark Unread'}</span>
                    </button>
                    <button
                      type="button"
                      onClick={() =>
                        setPendingAction({
                          kind: 'toggle_star',
                          message: selectedMessage,
                          star: !selectedMessage.isStarred,
                        })
                      }
                      className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg border border-white/15 bg-white/5 hover:bg-white/10 text-xs text-slate-200 transition cursor-pointer"
                    >
                      <Star
                        className={`w-3.5 h-3.5 ${
                          selectedMessage.isStarred ? 'text-amber-400 fill-amber-400' : ''
                        }`}
                      />
                      <span>{selectedMessage.isStarred ? 'Unstar' : 'Star'}</span>
                    </button>
                    {selectedMessage.isInInbox && !selectedMessage.isInTrash && (
                      <button
                        type="button"
                        onClick={() =>
                          setPendingAction({ kind: 'archive', message: selectedMessage })
                        }
                        className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg border border-white/15 bg-white/5 hover:bg-white/10 text-xs text-slate-200 transition cursor-pointer"
                      >
                        <Archive className="w-3.5 h-3.5" />
                        <span>Archive</span>
                      </button>
                    )}
                    {!selectedMessage.isInTrash ? (
                      <button
                        type="button"
                        onClick={() =>
                          setPendingAction({ kind: 'trash', message: selectedMessage })
                        }
                        className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg border border-red-500/35 bg-red-500/10 hover:bg-red-500/20 text-xs text-red-200 transition cursor-pointer"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                        <span>Trash</span>
                      </button>
                    ) : (
                      <>
                        <button
                          type="button"
                          onClick={() =>
                            setPendingAction({ kind: 'untrash', message: selectedMessage })
                          }
                          className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg border border-emerald-500/35 bg-emerald-500/10 hover:bg-emerald-500/20 text-xs text-emerald-200 transition cursor-pointer"
                        >
                          <RotateCcw className="w-3.5 h-3.5" />
                          <span>Restore</span>
                        </button>
                        <button
                          type="button"
                          onClick={() =>
                            setPendingAction({
                              kind: 'delete_permanent',
                              message: selectedMessage,
                            })
                          }
                          className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg border border-red-500/50 bg-red-600/25 hover:bg-red-600/40 text-xs text-red-100 transition cursor-pointer"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                          <span>Delete Forever</span>
                        </button>
                      </>
                    )}
                  </div>

                  {/* Message Reader Content (Safe plain text only, never raw HTML injection) */}
                  <div className="flex-1 overflow-y-auto p-5 space-y-4">
                    <div className="border-b border-white/10 pb-3">
                      <h3 className="text-base font-semibold text-white mb-2 leading-snug">
                        {selectedMessage.subject}
                      </h3>
                      <div className="text-xs space-y-1 text-slate-300">
                        <div>
                          <span className="text-slate-500 font-mono-tech mr-2">From:</span>
                          <span className="text-white font-medium">{selectedMessage.fromName}</span>
                          {selectedMessage.fromEmail &&
                            selectedMessage.fromEmail !== selectedMessage.fromName && (
                              <span className="text-slate-400 ml-1">
                                &lt;{selectedMessage.fromEmail}&gt;
                              </span>
                            )}
                        </div>
                        {selectedMessage.to && (
                          <div>
                            <span className="text-slate-500 font-mono-tech mr-2">To:</span>
                            <span>{selectedMessage.to}</span>
                          </div>
                        )}
                        {selectedMessage.cc && (
                          <div>
                            <span className="text-slate-500 font-mono-tech mr-2">Cc:</span>
                            <span>{selectedMessage.cc}</span>
                          </div>
                        )}
                        {selectedMessage.date && (
                          <div>
                            <span className="text-slate-500 font-mono-tech mr-2">Date:</span>
                            <span className="text-slate-400">{selectedMessage.date}</span>
                          </div>
                        )}
                      </div>
                    </div>

                    {selectedMessage.attachments.length > 0 && (
                      <div className="flex flex-wrap gap-2">
                        {selectedMessage.attachments.map((att, idx) => (
                          <div
                            key={`${att.filename}-${idx}`}
                            className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-white/5 border border-white/15 text-[11px] text-slate-200"
                          >
                            <Paperclip className="w-3 h-3 text-amber-300" />
                            <span className="truncate max-w-[200px]">{att.filename}</span>
                            <span className="text-slate-400 font-mono-tech">
                              ({formatBytes(att.size)})
                            </span>
                          </div>
                        ))}
                      </div>
                    )}

                    {loadingDetail ? (
                      <div className="text-xs text-slate-400 py-4">Loading full message…</div>
                    ) : (
                      <div className="text-xs sm:text-[13px] leading-relaxed text-slate-200 whitespace-pre-wrap break-words font-sans">
                        {selectedMessage.bodyText || '(Empty message body)'}
                      </div>
                    )}
                  </div>
                </div>
              ) : (
                <div className="flex-1 flex flex-col items-center justify-center p-6 text-center text-slate-400">
                  <Mail className="w-8 h-8 text-amber-400/50 mb-3" />
                  <p className="text-sm font-medium text-slate-200 mb-1">Select a message to read</p>
                  <p className="text-xs max-w-xs">
                    Choose an email from the list on the left or click Compose to write a new
                    message.
                  </p>
                </div>
              )}
            </main>
          </div>
        )}

        {/* Mandatory Custom Confirmation Modal for ALL Mutating / Destructive Gmail Actions */}
        {pendingAction && mutationCopy && (
          <div
            role="alertdialog"
            aria-modal="true"
            aria-labelledby="gmail-confirm-title"
            className="absolute inset-0 z-20 flex items-center justify-center bg-black/75 backdrop-blur-sm p-4"
          >
            <div className="barbi-scifi-shell w-full max-w-md p-5">
              <div className="flex items-start gap-3 mb-3">
                <div
                  className={`w-9 h-9 rounded-lg flex items-center justify-center shrink-0 ${
                    mutationCopy.danger
                      ? 'bg-red-500/20 text-red-300 border border-red-400/40'
                      : 'bg-amber-500/20 text-amber-300 border border-amber-400/40'
                  }`}
                >
                  <AlertTriangle className="w-4 h-4" />
                </div>
                <div className="min-w-0">
                  <h4 id="gmail-confirm-title" className="text-sm font-semibold text-white">
                    {mutationCopy.title}
                  </h4>
                  <p className="text-xs text-slate-400 mt-0.5">
                    Review the details below before B.A.R.B.I. modifies your Gmail account.
                  </p>
                </div>
              </div>

              <dl className="rounded-xl bg-white/[0.02] backdrop-blur-md border border-[#8B4513]/40 p-3 space-y-1.5 text-xs mb-3">
                {mutationCopy.details.map((row) => (
                  <div key={row.label} className="flex gap-2">
                    <dt className="text-slate-500 font-mono-tech shrink-0 w-16">{row.label}:</dt>
                    <dd className="text-slate-100 break-words min-w-0">{row.value}</dd>
                  </div>
                ))}
              </dl>

              {mutationCopy.warning && (
                <p
                  className={`text-[11px] mb-4 ${
                    mutationCopy.danger ? 'text-red-300' : 'text-amber-200/90'
                  }`}
                >
                  {mutationCopy.warning}
                </p>
              )}

              <div className="flex items-center justify-end gap-2">
                <button
                  type="button"
                  disabled={mutating}
                  onClick={() => setPendingAction(null)}
                  className="px-3.5 py-1.5 rounded-lg border border-white/15 bg-white/5 hover:bg-white/10 text-xs text-slate-200 transition cursor-pointer disabled:opacity-50"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  disabled={mutating}
                  onClick={() => void executeConfirmedAction()}
                  className={`px-4 py-1.5 rounded-lg text-xs font-semibold transition cursor-pointer disabled:opacity-50 ${
                    mutationCopy.danger
                      ? 'bg-red-600 hover:bg-red-500 text-white'
                      : 'bg-amber-500 hover:bg-amber-400 text-black'
                  }`}
                >
                  {mutating ? 'Processing…' : mutationCopy.confirmLabel}
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
