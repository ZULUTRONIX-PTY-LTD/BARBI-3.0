import { useEffect, useRef, useState } from 'react';
import { ExternalLink, Monitor, RefreshCw, Sparkles, X } from 'lucide-react';

type EngineeringKind = 'matlab' | 'simulink' | 'solidworks' | 'altium';

const APPS: Record<EngineeringKind, { title: string; subtitle: string; logo: string; webUrl: string; desktopPrompt: string }> = {
  matlab: {
    title: 'MATLAB',
    subtitle: 'Numerical computing · Matrix algebra · ODE solvers · Live Scripts',
    logo: '/icons/matlab-logo.png',
    webUrl: 'https://matlab.mathworks.com/',
    desktopPrompt: 'Check whether MATLAB is installed on this system, launch it if available, and report its version and status. Use allowlisted commands only.',
  },
  simulink: {
    title: 'SIMULINK',
    subtitle: 'Block diagrams · Control systems · Simscape physical modeling',
    logo: '/icons/matlab-logo.png',
    webUrl: 'https://www.mathworks.com/products/simulink.html',
    desktopPrompt: 'Check whether Simulink is installed alongside MATLAB on this system, launch it if available, and report its status. Use allowlisted commands only.',
  },
  altium: {
    title: 'ALTIUM DESIGNER',
    subtitle: 'PCB design · Schematic capture · Gerber fabrication · Embedded hardware',
    logo: '/icons/altium-logo.svg',
    webUrl: 'https://www.altium.com/altium-365/',
    desktopPrompt: 'Check whether Altium Designer is installed on this system, launch it if available, and report its version and status. Use allowlisted commands only.',
  },
  solidworks: {
    title: 'SOLIDWORKS',
    subtitle: 'Parametric CAD · Assemblies · CSWP workflows · FEA handoff',
    logo: '/icons/solidworks-logo.svg',
    webUrl: 'https://www.3dcontentcentral.com/',
    desktopPrompt: 'Check whether SOLIDWORKS is installed on this system, launch it if available, and report its version and status. Use allowlisted commands only.',
  },
};

interface EngineeringWindow {
  openOpenCodePanel?: (options: { open: boolean; prompt?: string }) => void;
  showToast?: (message: string, tone?: string) => void;
}

export default function EngineeringAppPanel() {
  const [open, setOpen] = useState(false);
  const [kind, setKind] = useState<EngineeringKind>('matlab');
  const [mode, setMode] = useState<'desktop' | 'web'>('web');
  const [reloadKey, setReloadKey] = useState(0);
  const openRef = useRef(false);
  openRef.current = open;

  useEffect(() => {
    const onToggle = (ev: Event) => {
      const detail = (ev as CustomEvent<{ open?: boolean; kind?: EngineeringKind; mode?: 'desktop' | 'web' }>).detail;
      const next = typeof detail?.open === 'boolean' ? detail.open : !openRef.current;
      if (detail?.kind && detail.kind in APPS) {
        setKind(detail.kind);
        if (['matlab', 'simulink', 'solidworks', 'altium'].includes(detail.kind)) setMode('desktop');
      }
      if (detail?.mode === 'desktop' || detail?.mode === 'web') setMode(detail.mode);
      setOpen(next);
    };
    window.addEventListener('barbi:toggle-engineering-app', onToggle as EventListener);
    return () => window.removeEventListener('barbi:toggle-engineering-app', onToggle as EventListener);
  }, []);

  if (!open) return null;
  const app = APPS[kind];
  // These vendors block third-party framing; show a clean handoff instead of a refused-connection frame.
  const framingBlocked = ['matlab', 'simulink', 'solidworks', 'altium'].includes(kind);

  return (
    <section
      id="barbi-engineering-app-panel"
      aria-label={`${app.title} in B.A.R.B.I`}
      className="barbi-agent-panel fixed inset-x-4 bottom-4 z-50 h-[min(88dvh,780px)] flex flex-col overflow-hidden text-stone-100"
    >
      <header className="barbi-agent-header flex items-center justify-between gap-3 px-3.5 py-2.5 shrink-0">
        <div className="flex items-center gap-3 min-w-0">
          <img src={app.logo} alt={app.title} className="w-8 h-8 object-contain barbi-hex-logo bg-black/45 border border-[#8B4513]/60 p-0.5 shrink-0" />
          <div className="min-w-0">
            <div className="text-[13px] font-semibold tracking-wide text-[#FBBF24] truncate">{app.title}</div>
            <div className="text-[9px] font-mono-tech text-[#D2691E]/90 truncate">{app.subtitle}</div>
          </div>
        </div>
        <div className="flex items-center gap-1.5 shrink-0">
          <div className="flex items-center border border-[#8B4513]/60 bg-black/30">
            {(['desktop', 'web'] as const).map((m) => (
              <button
                key={m}
                type="button"
                onClick={() => setMode(m)}
                className={`flex items-center gap-1 px-2.5 py-1 text-[9px] font-mono-tech uppercase tracking-wider transition ${
                  mode === m ? 'bg-[#8B4513]/60 text-[#FBBF24]' : 'text-stone-400 hover:text-stone-100'
                }`}
              >
                {m === 'desktop' ? <Monitor className="w-3 h-3" /> : <Sparkles className="w-3 h-3" />}
                {m}
              </button>
            ))}
          </div>
          <button type="button" onClick={() => setReloadKey((k) => k + 1)} title="Reload" className="p-1.5 rounded text-[#D2691E] hover:bg-white/10 transition">
            <RefreshCw className="w-3.5 h-3.5" />
          </button>
          <button type="button" onClick={() => window.open(app.webUrl, '_blank', 'noopener,noreferrer')} title="Open full web version" className="flex items-center gap-1 px-2 py-1.5 rounded text-[9px] font-mono-tech text-[#FBBF24] border border-[#D2691E]/60 hover:bg-[#8B4513]/40 transition">
            <ExternalLink className="w-3 h-3" /> Web
          </button>
          <button type="button" onClick={() => setOpen(false)} title="Close" className="p-1.5 rounded text-[#D2691E] hover:bg-white/10 transition">
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      </header>

      {mode === 'web' ? (
        framingBlocked ? (
          <div className="flex-1 min-h-0 overflow-auto p-6 flex flex-col items-center justify-center gap-4 text-center">
            <img src={app.logo} alt={app.title} className="w-16 h-16 object-contain" />
            <div className="text-[13px] font-semibold text-[#FBBF24]">{app.title} · WEB HANDOFF</div>
            <p className="text-[11px] text-stone-300 max-w-lg leading-relaxed">
              {app.title} blocks embedding in third-party applications (the frame would show "refused to connect"). Open the official web experience in a dedicated Chrome tab, or use Desktop mode with BARBI Agent for local control.
            </p>
            <div className="flex flex-wrap justify-center gap-2">
              <button type="button" onClick={() => window.open(app.webUrl, '_blank', 'noopener,noreferrer')} className="flex items-center gap-2 px-4 py-2 rounded bg-[#8B4513]/50 border border-[#D2691E]/75 text-[#FBBF24] text-[11px] font-mono-tech hover:bg-[#8B4513]/75 transition">
                <ExternalLink className="w-3.5 h-3.5" /> Open official web app
              </button>
              <button type="button" onClick={() => setMode('desktop')} className="px-4 py-2 rounded bg-white/5 border border-white/15 text-stone-300 text-[11px] font-mono-tech hover:bg-white/10 transition">
                Switch to Desktop
              </button>
            </div>
            <div className="text-[9px] font-mono-tech text-[#D2691E]/70 tracking-wider">PROVIDER FRAMING POLICY · EXTERNAL SESSION</div>
          </div>
        ) : (
        <div className="relative flex-1 min-h-0 bg-black/40">
          <iframe
            key={`${kind}-${reloadKey}`}
            title={`${app.title} Web`}
            src={app.webUrl}
            allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture; camera; microphone"
            className="w-full h-full border-0"
          />
          <div className="absolute bottom-0 left-0 right-0 px-3 py-1.5 bg-black/70 border-t border-white/10 flex items-center justify-between gap-2">
            <span className="text-[9px] font-mono-tech text-stone-400 truncate">Official {app.title} web experience · embedded when the provider allows framing</span>
            <button type="button" onClick={() => window.open(app.webUrl, '_blank', 'noopener,noreferrer')} className="shrink-0 text-[9px] font-mono-tech text-[#FBBF24] hover:underline">Open externally</button>
          </div>
        </div>
        )
      ) : (
        <div className="flex-1 min-h-0 overflow-auto p-6 flex flex-col items-center justify-center gap-4 text-center">
          <img src={app.logo} alt={app.title} className="w-20 h-20 object-contain" />
          <div className="text-[14px] font-semibold text-[#FBBF24]">{app.title} · DESKTOP MODE</div>
          <p className="text-[11px] text-stone-300 max-w-lg leading-relaxed">
            The licensed desktop application runs on this machine. BARBI Agent can inspect the installation, launch it, and control supported workflows through the B.A.R.B.I. MCP bridge.
          </p>
          <button
            type="button"
            onClick={() => (window as unknown as EngineeringWindow).openOpenCodePanel?.({ open: true, prompt: app.desktopPrompt })}
            className="flex items-center gap-2 px-4 py-2 rounded bg-[#8B4513]/45 border border-[#D2691E]/70 text-[#FBBF24] text-[11px] font-mono-tech hover:bg-[#8B4513]/70 transition"
          >
            <Sparkles className="w-3.5 h-3.5" /> Launch via BARBI Agent
          </button>
          <div className="text-[9px] font-mono-tech text-[#D2691E]/70 tracking-wider">DESKTOP BRIDGE · GUARDED COMMANDS</div>
        </div>
      )}
    </section>
  );
}
