import { useCallback, useEffect, useMemo, useState, type FormEvent } from 'react';
import {
  BookOpen,
  ChevronRight,
  Download,
  FileText,
  Globe2,
  Headphones,
  Link2,
  ListChecks,
  Loader2,
  Network,
  Plus,
  Search,
  Send,
  Sparkles,
  StickyNote,
  Trash2,
  Upload,
  Video,
} from 'lucide-react';
import { barbiApi } from '../api/barbiClient';

interface NotebookSource {
  id: string;
  title: string;
  type: 'text' | 'url' | 'youtube' | 'pdf' | 'audio' | 'doc';
  content: string;
  uri?: string;
  addedAt: string;
  charCount: number;
}

interface NotebookRecord {
  id: string;
  title: string;
  sources: NotebookSource[];
  createdAt: string;
  updatedAt: string;
}

interface ArtifactRecord {
  id: string;
  notebookId: string;
  type: string;
  title: string;
  content: unknown;
  createdAt: string;
}

interface NoteRecord {
  id: string;
  notebookId: string;
  title?: string;
  content: string;
  source: string;
  createdAt: string;
}

interface ChatTurn {
  role: 'user' | 'assistant';
  text: string;
  citations?: string[];
  createdAt: string;
}

interface StudyPack {
  title?: string;
  executiveSummary?: string;
  keyConcepts?: Array<{ term: string; explanation: string; equation?: string }>;
  flashcards?: Array<{ front: string; back: string }>;
  quiz?: Array<{ question: string; options: string[]; answerIndex: number }>;
  explainerScenes?: Array<{ sceneIndex?: number; title: string; narrationText?: string }>;
}

declare global {
  interface Window {
    __currentStudyPack?: StudyPack;
    renderExplainerSceneFrame?: (sceneIndex: number, progress: number) => void;
    playStudyExplainerVideo?: () => void;
    stopStudyExplainerVideo?: () => void;
    exportStudyExplainerWebm?: () => void;
  }
}

const ARTIFACT_CARDS = [
  { type: 'audio_overview', label: 'Audio Overview', hint: '2-host podcast script', icon: Headphones, color: 'text-violet-300' },
  { type: 'video_overview', label: 'Video Overview', hint: 'Cinematic scene plan', icon: Video, color: 'text-rose-300' },
  { type: 'study_guide', label: 'Study Guide', hint: 'Concepts + flashcards', icon: BookOpen, color: 'text-amber-300' },
  { type: 'briefing_doc', label: 'Briefing Doc', hint: 'Executive summary', icon: FileText, color: 'text-sky-300' },
  { type: 'mind_map', label: 'Mind Map', hint: 'Concept graph', icon: Network, color: 'text-emerald-300' },
  { type: 'faq', label: 'FAQ', hint: 'Grounded Q&A set', icon: ListChecks, color: 'text-cyan-300' },
] as const;

const CHAT_MODES = [
  { id: 'default', label: 'Default' },
  { id: 'learning_guide', label: 'Learning guide' },
  { id: 'brief', label: 'Brief' },
  { id: 'detailed', label: 'Detailed' },
] as const;

function errorText(err: unknown): string {
  return err instanceof Error ? err.message : String(err);
}

function artifactText(content: unknown): string {
  if (typeof content === 'string') return content;
  if (content && typeof content === 'object' && 'markdown' in content) {
    return String((content as { markdown: unknown }).markdown);
  }
  try {
    return JSON.stringify(content, null, 2);
  } catch {
    return String(content);
  }
}

/** NotebookLM-style research surface mounted into the Study & Explainer tab. */
export function NotebookStudioPanel() {
  const [notebooks, setNotebooks] = useState<NotebookRecord[]>([]);
  const [activeId, setActiveId] = useState('');
  const [notebook, setNotebook] = useState<NotebookRecord | null>(null);
  const [artifacts, setArtifacts] = useState<ArtifactRecord[]>([]);
  const [notes, setNotes] = useState<NoteRecord[]>([]);
  const [history, setHistory] = useState<ChatTurn[]>([]);
  const [selectedArtifact, setSelectedArtifact] = useState<ArtifactRecord | null>(null);
  const [busy, setBusy] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [sourceMode, setSourceMode] = useState<'text' | 'url' | 'discover'>('text');
  const [sourceTitle, setSourceTitle] = useState('');
  const [sourceContent, setSourceContent] = useState('');
  const [sourceUri, setSourceUri] = useState('');
  const [discoverTopic, setDiscoverTopic] = useState('');
  const [discovered, setDiscovered] = useState<Array<{ title: string; url?: string; snippet?: string; uri?: string }>>([]);
  const [chatMode, setChatMode] = useState<(typeof CHAT_MODES)[number]['id']>('default');
  const [question, setQuestion] = useState('');
  const [followUps, setFollowUps] = useState<string[]>([]);
  const [noteDraft, setNoteDraft] = useState('');
  const [studyPack, setStudyPack] = useState<StudyPack | null>(null);

  const loadNotebooks = useCallback(async () => {
    try {
      const res = await barbiApi.studioListNotebooks();
      let list = (res.notebooks || []) as NotebookRecord[];
      if (!list.length) {
        const created = await barbiApi.studioCreateNotebook('My NotebookLM Study Hub');
        list = [created.notebook as NotebookRecord];
      }
      setNotebooks(list);
      setActiveId((prev) => (prev && list.some((n) => n.id === prev) ? prev : list[0].id));
    } catch (err) {
      setNotice(`Could not load notebooks: ${errorText(err)}`);
    }
  }, []);

  const loadNotebook = useCallback(async (id: string) => {
    if (!id) return;
    setBusy('notebook');
    try {
      const [detail, chat] = await Promise.all([
        barbiApi.studioGetNotebook(id),
        barbiApi.studioChatHistory(id).catch(() => ({ history: [] as ChatTurn[] })),
      ]);
      setNotebook((detail.notebook as NotebookRecord) || null);
      setArtifacts((detail.artifacts as ArtifactRecord[]) || []);
      setNotes((detail.notes as NoteRecord[]) || []);
      setHistory((chat.history as ChatTurn[]) || []);
      setSelectedArtifact((detail.artifacts as ArtifactRecord[])?.[0] || null);
      setNotice(null);
    } catch (err) {
      setNotice(`Could not open notebook: ${errorText(err)}`);
    } finally {
      setBusy(null);
    }
  }, []);

  useEffect(() => {
    void loadNotebooks();
  }, [loadNotebooks]);

  useEffect(() => {
    if (activeId) void loadNotebook(activeId);
  }, [activeId, loadNotebook]);

  useEffect(() => {
    const id = window.requestAnimationFrame(() => {
      if (typeof window.renderExplainerSceneFrame === 'function') window.renderExplainerSceneFrame(0, 1);
    });
    return () => window.cancelAnimationFrame(id);
  }, [studyPack]);

  const createNotebook = async () => {
    setBusy('create');
    try {
      const res = await barbiApi.studioCreateNotebook(`Notebook ${new Date().toLocaleDateString()}`);
      const created = res.notebook as NotebookRecord;
      setNotebooks((prev) => [created, ...prev]);
      setActiveId(created.id);
      setNotice('New notebook created.');
    } catch (err) {
      setNotice(`Could not create notebook: ${errorText(err)}`);
    } finally {
      setBusy(null);
    }
  };

  const deleteNotebook = async () => {
    if (!activeId || !window.confirm('Delete this notebook and all of its sources, notes and artifacts?')) return;
    setBusy('delete');
    try {
      await barbiApi.studioDeleteNotebook(activeId);
      const remaining = notebooks.filter((n) => n.id !== activeId);
      setNotebooks(remaining);
      setActiveId(remaining[0]?.id || '');
      setNotice('Notebook deleted.');
    } catch (err) {
      setNotice(`Could not delete notebook: ${errorText(err)}`);
    } finally {
      setBusy(null);
    }
  };

  const refreshNotebook = useCallback(async () => {
    if (activeId) await loadNotebook(activeId);
    await loadNotebooks();
  }, [activeId, loadNotebook, loadNotebooks]);

  const addSource = async (payload: { title?: string; type?: string; content?: string; uri?: string }) => {
    if (!activeId) return;
    setBusy('source');
    try {
      await barbiApi.studioAddSource(activeId, payload);
      setSourceTitle('');
      setSourceContent('');
      setSourceUri('');
      setNotice('Source added to this notebook.');
      await refreshNotebook();
    } catch (err) {
      setNotice(`Could not add source: ${errorText(err)}`);
    } finally {
      setBusy(null);
    }
  };

  const removeSource = async (sourceId: string) => {
    if (!activeId) return;
    try {
      await barbiApi.studioRemoveSource(activeId, sourceId);
      await refreshNotebook();
    } catch (err) {
      setNotice(`Could not remove source: ${errorText(err)}`);
    }
  };

  const discover = async (e: FormEvent) => {
    e.preventDefault();
    if (discoverTopic.trim().length < 2) return;
    setBusy('discover');
    setNotice(null);
    try {
      const res = await barbiApi.studioDiscoverSources(discoverTopic.trim(), 6);
      setDiscovered((res.sources || []) as typeof discovered);
    } catch (err) {
      setNotice(`Discovery failed: ${errorText(err)}`);
    } finally {
      setBusy(null);
    }
  };

  const sendQuestion = async (e?: FormEvent, preset?: string) => {
    e?.preventDefault();
    const text = (preset ?? question).trim();
    if (!activeId || !text || busy === 'chat') return;
    setQuestion('');
    setFollowUps([]);
    setHistory((prev) => [...prev, { role: 'user', text, createdAt: new Date().toISOString() }]);
    setBusy('chat');
    try {
      const res = await barbiApi.studioChat(activeId, { question: text, mode: chatMode });
      setHistory((prev) => [...prev, {
        role: 'assistant',
        text: res.answer || 'No answer generated.',
        citations: res.citations || [],
        createdAt: new Date().toISOString(),
      }]);
      setFollowUps(res.suggestedFollowUps || []);
    } catch (err) {
      setNotice(`Chat failed: ${errorText(err)}`);
    } finally {
      setBusy(null);
    }
  };

  const generateArtifact = async (type: string) => {
    if (!activeId) return;
    setBusy(`artifact:${type}`);
    setNotice(null);
    try {
      const res = await barbiApi.studioGenerateArtifact(activeId, { type });
      const created = res.artifact as ArtifactRecord;
      setArtifacts((prev) => [created, ...prev]);
      setSelectedArtifact(created);
    } catch (err) {
      setNotice(`Generation failed: ${errorText(err)}`);
    } finally {
      setBusy(null);
    }
  };

  const generateStudyPack = async () => {
    if (!notebook) return;
    if (!notebook.sources.length) {
      setNotice('Add at least one source before generating an explainer.');
      return;
    }
    setBusy('pack');
    setNotice(null);
    try {
      const materialText = notebook.sources
        .map((src) => `### ${src.title}\n${src.content}`)
        .join('\n\n')
        .slice(0, 20_000);
      const res = await barbiApi.studioGenerateStudyPack({
        topicTitle: notebook.title,
        materialText,
      });
      const pack = (res.studyPack as StudyPack) || null;
      setStudyPack(pack);
      if (pack) {
        window.__currentStudyPack = pack;
        if (typeof window.renderExplainerSceneFrame === 'function') window.renderExplainerSceneFrame(0, 1);
      }
      setNotice(pack ? `Study pack ready — ${pack.explainerScenes?.length || 0} explainer scenes.` : 'No study pack returned.');
    } catch (err) {
      setNotice(`Study pack failed: ${errorText(err)}`);
    } finally {
      setBusy(null);
    }
  };

  const createNote = async () => {
    if (!activeId || !noteDraft.trim()) return;
    try {
      await barbiApi.studioCreateNote(activeId, { content: noteDraft.trim(), source: 'user' });
      setNoteDraft('');
      await refreshNotebook();
    } catch (err) {
      setNotice(`Could not save note: ${errorText(err)}`);
    }
  };

  const downloadExport = async () => {
    if (!activeId) return;
    try {
      const res = await fetch(`/api/studio/notebooks/${encodeURIComponent(activeId)}/export`);
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const md = await res.text();
      const blob = new Blob([md], { type: 'text/markdown;charset=utf-8' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${(notebook?.title || 'notebook').replace(/[^\w-]+/g, '-').toLowerCase()}.md`;
      a.click();
      URL.revokeObjectURL(url);
    } catch (err) {
      setNotice(`Export failed: ${errorText(err)}`);
    }
  };

  const summarizeNotebook = async () => {
    if (!activeId) return;
    setBusy('summary');
    try {
      const res = await barbiApi.studioSummarize(activeId);
      setNotice(`Summary: ${res.summary || 'No summary returned.'} ${(res.keyTopics || []).length ? `Topics: ${res.keyTopics.join(', ')}` : ''}`.slice(0, 900));
    } catch (err) {
      setNotice(`Summarize failed: ${errorText(err)}`);
    } finally {
      setBusy(null);
    }
  };

  const runDeepResearch = async () => {
    if (!activeId) return;
    setBusy('research');
    try {
      const res = await barbiApi.studioDeepResearch(activeId, {
        topic: discoverTopic.trim() || notebook?.title || 'Research topic',
        maxSources: 6,
        importToNotebook: true,
      });
      await refreshNotebook();
      setNotice(`Deep research complete. ${Array.isArray(res.sources) ? res.sources.length : 0} sources imported.`);
    } catch (err) {
      setNotice(`Deep research failed: ${errorText(err)}`);
    } finally {
      setBusy(null);
    }
  };

  const sourceCount = notebook?.sources.length || 0;
  const stage = useMemo(() => {
    const scenes = studyPack?.explainerScenes || [];
    return scenes.length ? scenes[0] : null;
  }, [studyPack]);

  return (
    <div className="space-y-3 text-stone-100">
      <div className="flex flex-wrap items-center justify-between gap-2 rounded-2xl border border-amber-400/25 bg-black/60 backdrop-blur-xl px-3 py-2">
        <div className="flex min-w-0 items-center gap-2">
          <span className="w-8 h-8 shrink-0 rounded-xl border border-amber-400/50 bg-amber-500/15 flex items-center justify-center text-amber-300">
            <BookOpen className="w-4 h-4" />
          </span>
          <div className="min-w-0">
            <div className="text-[12px] font-semibold tracking-wide text-amber-200">NotebookLM Study Studio</div>
            <div className="text-[9.5px] font-mono-tech text-stone-400">
              Grounded research · {sourceCount} {sourceCount === 1 ? 'source' : 'sources'} · {artifacts.length} artifacts
            </div>
          </div>
        </div>
        <div className="flex flex-wrap items-center gap-1.5">
          <select
            value={activeId}
            onChange={(e) => setActiveId(e.target.value)}
            aria-label="Active notebook"
            className="max-w-[210px] bg-black/70 border border-white/15 rounded-lg px-2 py-1 text-[10px] font-mono-tech text-stone-200 outline-none"
          >
            {notebooks.map((nb) => <option key={nb.id} value={nb.id}>{nb.title}</option>)}
          </select>
          <button type="button" onClick={() => void createNotebook()} className="px-2 py-1 rounded-lg border border-white/15 bg-white/5 hover:bg-white/10 text-[10px] font-mono-tech cursor-pointer flex items-center gap-1">
            <Plus className="w-3 h-3" /> New
          </button>
          <button type="button" onClick={() => void summarizeNotebook()} disabled={!!busy} className="px-2 py-1 rounded-lg border border-sky-400/35 bg-sky-500/10 hover:bg-sky-500/20 text-[10px] font-mono-tech text-sky-200 cursor-pointer disabled:opacity-40 flex items-center gap-1">
            {busy === 'summary' ? <Loader2 className="w-3 h-3 animate-spin" /> : <Sparkles className="w-3 h-3" />} Summarize
          </button>
          <button type="button" onClick={() => void runDeepResearch()} disabled={!!busy} className="px-2 py-1 rounded-lg border border-violet-400/35 bg-violet-500/10 hover:bg-violet-500/20 text-[10px] font-mono-tech text-violet-200 cursor-pointer disabled:opacity-40 flex items-center gap-1">
            {busy === 'research' ? <Loader2 className="w-3 h-3 animate-spin" /> : <Globe2 className="w-3 h-3" />} Deep research
          </button>
          <button type="button" onClick={() => void downloadExport()} className="px-2 py-1 rounded-lg border border-amber-400/35 bg-amber-500/10 hover:bg-amber-500/20 text-[10px] font-mono-tech text-amber-200 cursor-pointer flex items-center gap-1">
            <Download className="w-3 h-3" /> Export
          </button>
          <button type="button" onClick={() => void deleteNotebook()} className="px-2 py-1 rounded-lg border border-white/15 bg-white/5 hover:bg-rose-500/15 text-[10px] font-mono-tech text-stone-300 cursor-pointer" aria-label="Delete notebook">
            <Trash2 className="w-3 h-3" />
          </button>
        </div>
      </div>

      {notice && (
        <div className="rounded-xl border border-sky-400/30 bg-sky-500/10 px-3 py-1.5 text-[10.5px] font-mono-tech text-sky-100">
          {notice}
        </div>
      )}

      <div className="grid grid-cols-1 xl:grid-cols-[260px_minmax(0,1fr)_320px] gap-3 items-start">
        {/* Sources rail */}
        <section className="rounded-2xl border border-white/12 bg-black/55 backdrop-blur-xl p-3 space-y-2.5">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-mono-tech uppercase tracking-wider text-amber-300">Sources</span>
            <span className="text-[9px] font-mono-tech text-stone-500">{sourceCount} total</span>
          </div>
          <div className="flex gap-1">
            {([
              { id: 'text', label: 'Paste', icon: FileText },
              { id: 'url', label: 'Website', icon: Link2 },
              { id: 'discover', label: 'Discover', icon: Globe2 },
            ] as const).map((mode) => (
              <button
                key={mode.id}
                type="button"
                onClick={() => setSourceMode(mode.id)}
                className={`flex-1 px-1.5 py-1 rounded-lg border text-[9px] font-mono-tech cursor-pointer flex items-center justify-center gap-1 ${
                  sourceMode === mode.id
                    ? 'bg-amber-500/20 border-amber-400/50 text-amber-200'
                    : 'bg-white/5 border-white/10 text-stone-400 hover:text-stone-200'
                }`}
              >
                <mode.icon className="w-3 h-3" /> {mode.label}
              </button>
            ))}
          </div>

          {sourceMode === 'text' && (
            <div className="space-y-1.5">
              <input
                value={sourceTitle}
                onChange={(e) => setSourceTitle(e.target.value)}
                placeholder="Source title"
                className="w-full bg-black/60 border border-white/15 rounded-lg px-2 py-1 text-[10px] outline-none"
              />
              <textarea
                value={sourceContent}
                onChange={(e) => setSourceContent(e.target.value)}
                rows={4}
                placeholder="Paste lecture notes, chapter text, formulas…"
                className="w-full bg-black/60 border border-white/15 rounded-lg p-2 text-[10px] font-mono-tech outline-none resize-y"
              />
              <label className="block cursor-pointer text-center px-2 py-1 rounded-lg border border-white/15 bg-white/5 hover:bg-white/10 text-[9px] font-mono-tech text-stone-300">
                <Upload className="w-3 h-3 inline mr-1" /> Upload .txt/.md/.json
                <input
                  type="file"
                  accept=".txt,.md,.csv,.json"
                  className="hidden"
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    if (!file) return;
                    const reader = new FileReader();
                    reader.onload = () => {
                      setSourceTitle(file.name.replace(/\.[^.]+$/, ''));
                      setSourceContent(String(reader.result || '').slice(0, 20_000));
                    };
                    reader.readAsText(file);
                  }}
                />
              </label>
              <button
                type="button"
                disabled={busy === 'source' || !sourceContent.trim()}
                onClick={() => void addSource({ title: sourceTitle || 'Pasted source', type: 'text', content: sourceContent })}
                className="w-full py-1 rounded-lg border border-amber-400/45 bg-amber-500/15 hover:bg-amber-500/25 text-[10px] font-mono-tech text-amber-200 cursor-pointer disabled:opacity-40"
              >
                {busy === 'source' ? 'Adding…' : 'Add text source'}
              </button>
            </div>
          )}

          {sourceMode === 'url' && (
            <div className="space-y-1.5">
              <input
                value={sourceUri}
                onChange={(e) => setSourceUri(e.target.value)}
                placeholder="https://example.com/article"
                className="w-full bg-black/60 border border-white/15 rounded-lg px-2 py-1 text-[10px] outline-none"
              />
              <button
                type="button"
                disabled={busy === 'source' || !sourceUri.trim()}
                onClick={() => void addSource({ title: sourceTitle || sourceUri, type: 'url', uri: sourceUri })}
                className="w-full py-1 rounded-lg border border-amber-400/45 bg-amber-500/15 hover:bg-amber-500/25 text-[10px] font-mono-tech text-amber-200 cursor-pointer disabled:opacity-40"
              >
                {busy === 'source' ? 'Fetching…' : 'Import website'}
              </button>
            </div>
          )}

          {sourceMode === 'discover' && (
            <form onSubmit={discover} className="space-y-1.5">
              <div className="flex gap-1">
                <input
                  value={discoverTopic}
                  onChange={(e) => setDiscoverTopic(e.target.value)}
                  placeholder="Research topic"
                  className="flex-1 min-w-0 bg-black/60 border border-white/15 rounded-lg px-2 py-1 text-[10px] outline-none"
                />
                <button type="submit" disabled={busy === 'discover'} className="px-2 rounded-lg border border-sky-400/40 bg-sky-500/15 text-sky-200 cursor-pointer disabled:opacity-40">
                  {busy === 'discover' ? <Loader2 className="w-3 h-3 animate-spin" /> : <Search className="w-3 h-3" />}
                </button>
              </div>
              <div className="max-h-44 overflow-y-auto space-y-1">
                {discovered.map((hit, i) => (
                  <button
                    key={`${hit.url || hit.uri || hit.title}-${i}`}
                    type="button"
                    onClick={() => void addSource({
                      title: hit.title || `Source ${i + 1}`,
                      type: 'url',
                      uri: hit.url || hit.uri || '',
                      content: hit.snippet || '',
                    })}
                    className="w-full text-left p-1.5 rounded-lg border border-white/10 bg-white/5 hover:bg-white/10"
                  >
                    <div className="text-[9.5px] text-stone-200 truncate">{hit.title || hit.url}</div>
                    <div className="text-[8.5px] text-stone-500 truncate">{hit.snippet || hit.url}</div>
                  </button>
                ))}
                {!discovered.length && <div className="text-[9px] text-stone-500">Search the live web, then import results into this notebook.</div>}
              </div>
            </form>
          )}

          <div className="max-h-56 overflow-y-auto space-y-1 pt-1">
            {(notebook?.sources || []).map((src, i) => (
              <div key={src.id} className="group flex items-start gap-1.5 rounded-lg border border-white/10 bg-white/[0.035] px-2 py-1.5">
                <span className="text-[9px] font-mono-tech text-amber-300/80 mt-0.5">{String(i + 1).padStart(2, '0')}</span>
                <div className="min-w-0 flex-1">
                  <div className="text-[10px] text-stone-200 truncate">{src.title}</div>
                  <div className="text-[8.5px] font-mono-tech text-stone-500">{src.type} · {src.charCount.toLocaleString()} chars</div>
                </div>
                <button type="button" onClick={() => void removeSource(src.id)} className="opacity-40 group-hover:opacity-100 text-stone-400 hover:text-rose-300 cursor-pointer" aria-label={`Remove ${src.title}`}>
                  <Trash2 className="w-3 h-3" />
                </button>
              </div>
            ))}
            {!sourceCount && <div className="text-[9px] text-stone-500 leading-relaxed">NotebookLM answers only from your sources. Add a source to begin grounded chat.</div>}
          </div>
        </section>

        {/* Grounded chat */}
        <section className="rounded-2xl border border-white/12 bg-black/55 backdrop-blur-xl p-3 flex flex-col min-h-[520px]">
          <div className="flex flex-wrap items-center justify-between gap-2 pb-2 border-b border-white/10">
            <span className="text-[10px] font-mono-tech uppercase tracking-wider text-sky-300">Chat with your sources</span>
            <div className="flex items-center gap-1">
              <select
                value={chatMode}
                onChange={(e) => setChatMode(e.target.value as typeof chatMode)}
                aria-label="Chat mode"
                className="bg-black/70 border border-white/15 rounded-lg px-1.5 py-0.5 text-[9px] font-mono-tech text-stone-300 outline-none"
              >
                {CHAT_MODES.map((m) => <option key={m.id} value={m.id}>{m.label}</option>)}
              </select>
              <button
                type="button"
                onClick={async () => {
                  if (!activeId) return;
                  await barbiApi.studioClearChat(activeId);
                  setHistory([]);
                  setFollowUps([]);
                }}
                className="px-1.5 py-0.5 rounded-lg border border-white/15 bg-white/5 text-[9px] font-mono-tech text-stone-400 hover:text-stone-100 cursor-pointer"
              >
                Clear
              </button>
            </div>
          </div>

          <div className="flex-1 min-h-0 max-h-[46vh] overflow-y-auto py-2 space-y-2">
            {!history.length && (
              <div className="rounded-xl border border-dashed border-white/12 bg-white/[0.025] p-4 text-center space-y-2">
                <Sparkles className="w-5 h-5 mx-auto text-amber-300/70" />
                <div className="text-[11px] text-stone-300">Ask a question, request a learning guide, or explore a concept.</div>
                <div className="flex flex-wrap justify-center gap-1.5">
                  {['Summarize the key ideas', 'What equations should I memorize?', 'Create a step-by-step study plan'].map((p) => (
                    <button key={p} type="button" onClick={() => void sendQuestion(undefined, p)} className="px-2 py-1 rounded-lg border border-white/12 bg-white/5 text-[9px] font-mono-tech text-stone-300 hover:text-white cursor-pointer">
                      {p}
                    </button>
                  ))}
                </div>
              </div>
            )}
            {history.map((turn, i) => (
              <div key={`${turn.createdAt}-${i}`} className={`flex ${turn.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                <div className={`max-w-[92%] rounded-xl px-2.5 py-2 text-[10.5px] leading-relaxed whitespace-pre-wrap ${
                  turn.role === 'user'
                    ? 'bg-amber-500/15 border border-amber-400/30 text-amber-100'
                    : 'bg-white/[0.045] border border-white/10 text-stone-200'
                }`}>
                  {turn.text}
                  {!!turn.citations?.length && (
                    <div className="mt-1 flex flex-wrap gap-1">
                      {turn.citations.map((c) => (
                        <span key={c} className="px-1 rounded bg-sky-500/15 border border-sky-400/30 text-[8.5px] font-mono-tech text-sky-200">{c}</span>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            ))}
            {busy === 'chat' && (
              <div className="flex items-center gap-2 text-[10px] font-mono-tech text-amber-300">
                <Loader2 className="w-3 h-3 animate-spin" /> Grounding answer in sources…
              </div>
            )}
          </div>

          {!!followUps.length && (
            <div className="flex flex-wrap gap-1 pb-1.5">
              {followUps.map((f) => (
                <button key={f} type="button" onClick={() => void sendQuestion(undefined, f)} className="px-2 py-0.5 rounded-lg border border-white/10 bg-white/5 text-[9px] font-mono-tech text-stone-400 hover:text-white cursor-pointer">
                  <ChevronRight className="w-3 h-3 inline" /> {f}
                </button>
              ))}
            </div>
          )}

          <form onSubmit={(e) => void sendQuestion(e)} className="flex items-center gap-2 pt-2 border-t border-white/10">
            <input
              value={question}
              onChange={(e) => setQuestion(e.target.value)}
              placeholder={sourceCount ? 'Ask anything about your sources…' : 'Add a source first…'}
              disabled={!sourceCount}
              className="flex-1 min-w-0 bg-black/60 border border-white/15 rounded-lg px-2.5 py-1.5 text-[10.5px] outline-none disabled:opacity-50"
            />
            <button type="submit" disabled={!question.trim() || busy === 'chat' || !sourceCount} className="px-2.5 py-1.5 rounded-lg border border-amber-400/45 bg-amber-500/15 text-amber-200 hover:bg-amber-500/25 cursor-pointer disabled:opacity-40">
              <Send className="w-3.5 h-3.5" />
            </button>
          </form>
        </section>

        {/* Studio outputs */}
        <section className="rounded-2xl border border-white/12 bg-black/55 backdrop-blur-xl p-3 space-y-2.5">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-mono-tech uppercase tracking-wider text-violet-300">Studio</span>
            <span className="text-[9px] font-mono-tech text-stone-500">NotebookLM outputs</span>
          </div>
          <div className="grid grid-cols-2 gap-1.5">
            {ARTIFACT_CARDS.map((card) => {
              const Icon = card.icon;
              const isBusy = busy === `artifact:${card.type}`;
              return (
                <button
                  key={card.type}
                  type="button"
                  disabled={!sourceCount || !!busy}
                  onClick={() => void generateArtifact(card.type)}
                  className="text-left p-2 rounded-xl border border-white/10 bg-white/[0.035] hover:bg-white/[0.08] disabled:opacity-40 cursor-pointer space-y-1"
                >
                  <Icon className={`w-3.5 h-3.5 ${card.color}`} />
                  <div className="text-[9.5px] text-stone-200 flex items-center gap-1">
                    {card.label} {isBusy && <Loader2 className="w-2.5 h-2.5 animate-spin" />}
                  </div>
                  <div className="text-[8px] text-stone-500">{card.hint}</div>
                </button>
              );
            })}
          </div>

          <div className="border-t border-white/10 pt-2">
            <div className="flex items-center justify-between pb-1">
              <span className="text-[9.5px] font-mono-tech uppercase tracking-wider text-emerald-300">Artifacts</span>
              <span className="text-[9px] text-stone-500">{artifacts.length}</span>
            </div>
            <div className="max-h-36 overflow-y-auto space-y-1">
              {artifacts.map((art) => (
                <button
                  key={art.id}
                  type="button"
                  onClick={() => setSelectedArtifact(art)}
                  className={`w-full text-left px-2 py-1 rounded-lg border text-[9.5px] cursor-pointer ${
                    selectedArtifact?.id === art.id ? 'border-amber-400/45 bg-amber-500/10 text-amber-100' : 'border-white/10 bg-white/[0.03] text-stone-300 hover:bg-white/[0.07]'
                  }`}
                >
                  <span className="text-[8px] font-mono-tech text-stone-500 uppercase">{art.type.replace('_', ' ')} · </span>
                  {art.title}
                </button>
              ))}
              {!artifacts.length && <div className="text-[9px] text-stone-500">Generated artifacts appear here.</div>}
            </div>
            {selectedArtifact && (
              <pre className="mt-1.5 max-h-40 overflow-auto rounded-lg border border-white/10 bg-black/65 p-2 text-[9px] font-mono-tech text-stone-300 whitespace-pre-wrap">
                {artifactText(selectedArtifact.content).slice(0, 6000)}
              </pre>
            )}
          </div>

          <div className="border-t border-white/10 pt-2">
            <div className="flex items-center gap-1.5 text-[9.5px] font-mono-tech uppercase tracking-wider text-sky-300 mb-1">
              <StickyNote className="w-3 h-3" /> Notes
            </div>
            <textarea
              value={noteDraft}
              onChange={(e) => setNoteDraft(e.target.value)}
              rows={2}
              placeholder="Jot a grounded note…"
              className="w-full bg-black/60 border border-white/15 rounded-lg p-2 text-[10px] outline-none resize-none"
            />
            <button type="button" onClick={() => void createNote()} disabled={!noteDraft.trim()} className="mt-1 w-full py-1 rounded-lg border border-white/15 bg-white/5 hover:bg-white/10 text-[9.5px] font-mono-tech text-stone-300 cursor-pointer disabled:opacity-40">
              Save note
            </button>
            <div className="max-h-24 overflow-y-auto mt-1 space-y-1">
              {notes.slice(0, 8).map((note) => (
                <div key={note.id} className="px-2 py-1 rounded-lg border border-white/10 bg-white/[0.03] text-[9px] text-stone-400 truncate">
                  {note.title || note.content}
                </div>
              ))}
            </div>
          </div>
        </section>
      </div>

      {/* Explainer stage — retains the runtime canvas engine and HD export hooks. */}
      <section className="rounded-2xl border border-amber-400/25 bg-black/60 backdrop-blur-xl p-3 space-y-2">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="min-w-0">
            <div className="text-[10px] font-mono-tech uppercase tracking-wider text-amber-300">Explainer video stage</div>
            <div className="text-[9px] text-stone-500 truncate">
              {stage?.title || 'Generate a study pack to render the first scene.'}
            </div>
          </div>
          <div className="flex flex-wrap items-center gap-1.5">
            <button type="button" onClick={() => void generateStudyPack()} disabled={!sourceCount || busy === 'pack'} className="px-2.5 py-1 rounded-lg border border-amber-400/45 bg-amber-500/15 hover:bg-amber-500/25 text-[9.5px] font-mono-tech text-amber-200 cursor-pointer disabled:opacity-40 flex items-center gap-1">
              {busy === 'pack' ? <Loader2 className="w-3 h-3 animate-spin" /> : <Sparkles className="w-3 h-3" />} Generate study pack
            </button>
            <button type="button" onClick={() => window.playStudyExplainerVideo?.()} className="px-2 py-1 rounded-lg border border-emerald-400/35 bg-emerald-500/10 text-[9.5px] font-mono-tech text-emerald-200 hover:bg-emerald-500/20 cursor-pointer">Play</button>
            <button type="button" onClick={() => window.stopStudyExplainerVideo?.()} className="px-2 py-1 rounded-lg border border-white/15 bg-white/5 text-[9.5px] font-mono-tech text-stone-300 hover:bg-white/10 cursor-pointer">Stop</button>
            <button type="button" onClick={() => window.exportStudyExplainerWebm?.()} className="px-2 py-1 rounded-lg border border-sky-400/35 bg-sky-500/10 text-[9.5px] font-mono-tech text-sky-200 hover:bg-sky-500/20 cursor-pointer">Export .webm</button>
          </div>
        </div>
        <div className="grid grid-cols-1 lg:grid-cols-[minmax(0,1fr)_260px] gap-3">
          <div className="rounded-xl overflow-hidden border border-white/15 bg-black">
            <canvas id="studio-explainer-canvas" width={1280} height={720} className="w-full h-auto block" />
          </div>
          <div className="max-h-[220px] overflow-y-auto rounded-xl border border-white/10 bg-black/60 p-2 text-[9.5px] font-mono-tech text-stone-300 space-y-1.5">
            <div className="text-amber-300 uppercase">{studyPack?.title || 'Study pack preview'}</div>
            <div>{studyPack?.executiveSummary || 'Key concepts, flashcards, quiz and narration will appear here.'}</div>
            {(studyPack?.keyConcepts || []).slice(0, 6).map((k) => (
              <div key={k.term} className="border-t border-white/10 pt-1">
                <span className="text-sky-200">{k.term}:</span> {k.explanation}
                {k.equation ? <code className="text-amber-200"> [{k.equation}]</code> : null}
              </div>
            ))}
            {(studyPack?.flashcards || []).slice(0, 4).map((f, i) => (
              <div key={`${f.front}-${i}`} className="border-t border-white/10 pt-1 text-emerald-200/90">
                Q: {f.front}<br /><span className="text-emerald-300/70">A: {f.back}</span>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
