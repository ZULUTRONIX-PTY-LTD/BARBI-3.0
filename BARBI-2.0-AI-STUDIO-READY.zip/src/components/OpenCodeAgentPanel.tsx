import { useCallback, useEffect, useRef, useState, type FormEvent } from 'react';
import {
  Bot,
  CircleDot,
  FolderTree,
  Loader2,
  Maximize2,
  Minimize2,
  Plug,
  Plus,
  RefreshCw,
  Send,
  ShieldCheck,
  Terminal,
  X,
  Zap,
} from 'lucide-react';
import { apiRequest } from '../api/barbiClient';

interface OpenCodeStatus {
  available: boolean;
  mode: 'background-service' | 'embedded-sdk' | 'unavailable';
  workspace: string;
  info?: unknown;
  providers?: unknown;
  lastError?: string | null;
}

interface OpenCodeSession {
  id: string;
  title?: string;
  directory?: string;
  updatedAt?: string;
}

interface ChatLine {
  role: 'user' | 'agent' | 'system';
  text: string;
  at: string;
}

declare global {
  interface Window {
    openOpenCodePanel?: (options?: { open?: boolean; prompt?: string }) => void;
  }
}

const QUICK_ACTIONS = [
  { label: 'Audit project', prompt: 'Review the B.A.R.B.I workspace for bugs and security issues. Use barbi_workspace_tree and barbi_read_file to inspect key files, then summarize findings.' },
  { label: 'Run checks', prompt: 'Use barbi_run_command to run lint and build, then report any failures and fix them.' },
  { label: 'Study Studio', prompt: 'Create a notebook via barbi_notebook_create, add a source about control systems, then generate a study guide and flashcards.' },
  { label: "God's Eye", prompt: 'Call barbi_gods_eye_feeds and summarize the most significant live spatial-intelligence events.' },
  { label: 'Social Agent', prompt: 'Call barbi_social_summary and give me a status report across WhatsApp, Telegram, Instagram and TikTok.' },
];

// Tools the REST console can invoke directly. Other registered MCP tools remain
// available to the OpenCode agent through the chat session.
const CONSOLE_TOOLS = [
  'barbi_health',
  'barbi_provider_status',
  'barbi_system_telemetry',
  'barbi_workspace_tree',
  'barbi_read_file',
  'barbi_write_file',
  'barbi_run_command',
  'barbi_notebook_list',
  'barbi_notebook_create',
  'barbi_notebook_chat',
  'barbi_notebook_summarize',
  'barbi_generate_study_pack',
  'barbi_gods_eye_feeds',
  'barbi_social_summary',
  'barbi_social_messages',
  'barbi_social_approvals',
] as const;

function stamp() {
  return new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
}

function stringify(value: unknown): string {
  if (typeof value === 'string') return value;
  try {
    return JSON.stringify(value, null, 2);
  } catch {
    return String(value);
  }
}

/** Convert a workspace-tree tool result into a simple indented list. */
function formatTree(value: unknown): string {
  if (typeof value === 'string') return value;
  const s = stringify(value);
  return s.length > 6000 ? s.slice(0, 6000) + '\n… (truncated)' : s;
}

export function OpenCodeAgentPanel() {
  const [open, setOpen] = useState(false);
  const [maximized, setMaximized] = useState(false);
  const [status, setStatus] = useState<OpenCodeStatus | null>(null);
  const [sessions, setSessions] = useState<OpenCodeSession[]>([]);
  const [activeSession, setActiveSession] = useState<OpenCodeSession | null>(null);
  const [lines, setLines] = useState<ChatLine[]>([
    { role: 'system', text: 'BARBI Agent ready. I have full workspace access through B.A.R.B.I MCP tools. Ask me to build, inspect, run, or operate B.A.R.B.I.', at: stamp() },
  ]);
  const [draft, setDraft] = useState('');
  const [busy, setBusy] = useState(false);
  const [tools, setTools] = useState<string[]>([]);
  const [showTools, setShowTools] = useState(false);
  const [treeText, setTreeText] = useState('');
  const [treeLoading, setTreeLoading] = useState(false);
  const [view, setView] = useState<'chat' | 'workspace' | 'console'>('chat');
  const [consoleTool, setConsoleTool] = useState('barbi_workspace_tree');
  const [consoleInput, setConsoleInput] = useState('{\n  "subPath": "."\n}');
  const [consoleResult, setConsoleResult] = useState('');
  const [consoleBusy, setConsoleBusy] = useState(false);
  const scrollRef = useRef<HTMLDivElement | null>(null);

  const refresh = useCallback(async () => {
    const [nextStatus, nextSessions] = await Promise.all([
      apiRequest<OpenCodeStatus>('/api/opencode/status'),
      apiRequest<{ sessions: OpenCodeSession[] }>('/api/opencode/sessions').catch(() => ({ sessions: [] })),
    ]);
    setStatus(nextStatus);
    setSessions(nextSessions.sessions || []);
  }, []);

  const loadTree = useCallback(async () => {
    setTreeLoading(true);
    try {
      const r = await apiRequest<{ result?: unknown }>('/api/opencode/mcp/call', {
        method: 'POST',
        body: { tool: 'barbi_workspace_tree', input: { subPath: '.' } },
        timeoutMs: 30_000,
      });
      setTreeText(formatTree(r.result ?? r));
    } catch (err) {
      setTreeText(`Workspace tree unavailable: ${String(err)}`);
    } finally {
      setTreeLoading(false);
    }
  }, []);

  const runTool = useCallback(async () => {
    setConsoleBusy(true);
    let input: unknown = {};
    try {
      input = consoleInput.trim() ? JSON.parse(consoleInput) : {};
    } catch (err) {
      setConsoleResult(`Invalid JSON input: ${String(err)}`);
      setConsoleBusy(false);
      return;
    }
    try {
      const r = await apiRequest<{ result?: unknown }>('/api/opencode/mcp/call', {
        method: 'POST',
        body: { tool: consoleTool, input },
        timeoutMs: 30_000,
      });
      setConsoleResult(stringify(r.result ?? r));
    } catch (err) {
      setConsoleResult(`Tool call failed: ${String(err)}`);
    } finally {
      setConsoleBusy(false);
    }
  }, [consoleInput, consoleTool]);

  useEffect(() => {
    window.openOpenCodePanel = (options) => {
      if (typeof options?.open === 'boolean') setOpen(options.open);
      else setOpen((prev) => !prev);
      if (options?.prompt) {
        setDraft(options.prompt);
        setView('chat');
      }
    };
    return () => {
      delete window.openOpenCodePanel;
    };
  }, []);

  useEffect(() => {
    if (!open) return;
    void refresh();
    void apiRequest<{ tools: string[] }>('/api/opencode/mcp/tools')
      .then((r) => setTools(r.tools || []))
      .catch(() => undefined);
    void loadTree();
  }, [open, refresh, loadTree]);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: 'smooth' });
  }, [lines]);

  const createSession = useCallback(async () => {
    try {
      const result = await apiRequest<{ session: OpenCodeSession }>('/api/opencode/sessions', {
        method: 'POST',
        body: { title: `BARBI Agent Session ${new Date().toLocaleDateString()}` },
      });
      const session = result.session;
      if (session?.id) {
        setActiveSession(session);
        setSessions((prev) => [session, ...prev.filter((s) => s.id !== session.id)]);
        setLines((prev) => [...prev, { role: 'system', text: `Session opened: ${session.id}`, at: stamp() }]);
      }
    } catch (err) {
      setLines((prev) => [...prev, { role: 'system', text: `Failed to open session: ${String(err)}`, at: stamp() }]);
    }
  }, []);

  const send = useCallback(async (text?: string) => {
    const prompt = (text ?? draft).trim();
    if (!prompt || busy) return;
    setDraft('');
    setBusy(true);
    setView('chat');
    setLines((prev) => [...prev, { role: 'user', text: prompt, at: stamp() }]);

    try {
      let sessionID = activeSession?.id;
      if (!sessionID) {
        const created = await apiRequest<{ session: OpenCodeSession }>('/api/opencode/sessions', {
          method: 'POST',
          body: { title: 'B.A.R.B.I Agent Session' },
        });
        sessionID = created.session?.id;
        if (created.session) {
          setActiveSession(created.session);
          setSessions((prev) => [created.session, ...prev]);
        }
      }
      if (!sessionID) throw new Error('No OpenCode session available');

      const result = await apiRequest<{ result: { text?: string; messages?: unknown[] } }>(`/api/opencode/sessions/${encodeURIComponent(sessionID)}/prompt`, {
        method: 'POST',
        body: { text: prompt },
        timeoutMs: 180_000,
      });
      const agentText = result.result?.text || stringify(result.result);
      setLines((prev) => [...prev, { role: 'agent', text: agentText, at: stamp() }]);
    } catch (err) {
      setLines((prev) => [...prev, { role: 'system', text: `Error: ${String(err)}`, at: stamp() }]);
    } finally {
      setBusy(false);
    }
  }, [activeSession, busy, draft]);

  const handleSubmit = (ev: FormEvent) => {
    ev.preventDefault();
    void send();
  };

  const filteredConsoleTools = tools.filter((tool): tool is (typeof CONSOLE_TOOLS)[number] =>
    (CONSOLE_TOOLS as readonly string[]).includes(tool)
  );
  const toolOptions: readonly string[] = filteredConsoleTools.length
    ? filteredConsoleTools
    : CONSOLE_TOOLS;

  if (!open) {
    // Launch is handled by the Nexus sphere node (app-barbi-agent) and the
    // voice/text router. No floating dock button should exist.
    return null;
  }

  return (
    <aside
      aria-label="BARBI Agent OpenCode Environment"
      className={`barbi-agent-panel fixed z-50 flex flex-col rounded-2xl overflow-hidden text-stone-100 transition-all duration-200 ${
        maximized
          ? 'inset-3'
          : 'inset-x-4 bottom-4 h-[min(88dvh,780px)]'
      }`}
    >
      <header className="barbi-agent-header flex items-center justify-between gap-2 px-3.5 py-2.5 shrink-0">
        <div className="flex items-center gap-2 min-w-0">
          <span className="w-8 h-8 rounded-xl bg-[#8B4513]/40 border border-[#D2691E]/70 flex items-center justify-center text-[#FBBF24] shadow-[0_0_14px_rgba(139,69,19,0.6)]">
            <Bot className="w-4 h-4" />
          </span>
          <div className="min-w-0">
            <div className="text-[13px] font-semibold tracking-wide text-[#FBBF24] truncate">BARBI Agent</div>
            <div className="text-[9.5px] font-mono-tech text-[#D2691E]/90 truncate">
              OpenCode Environment ·{' '}
              {status?.mode === 'background-service' ? 'background service' : status?.mode === 'embedded-sdk' ? 'embedded SDK' : 'connecting…'}
              {status?.workspace ? ` · ${status.workspace.split(/[\\/]/).pop()}` : ''}
            </div>
          </div>
        </div>
        <div className="flex items-center gap-1 shrink-0">
          <button
            type="button"
            onClick={() => setView((v) => (v === 'chat' ? 'workspace' : 'chat'))}
            title="Toggle workspace tree"
            className={`p-1.5 rounded-md transition ${view === 'workspace' ? 'bg-[#8B4513]/50 text-[#FBBF24]' : 'text-[#D2691E] hover:bg-white/[0.07]'}`}
          >
            <FolderTree className="w-4 h-4" />
          </button>
          <button
            type="button"
            onClick={() => setView((v) => (v === 'console' ? 'chat' : 'console'))}
            title="Open MCP tool console (files, commands, tools)"
            className={`p-1.5 rounded-md transition ${view === 'console' ? 'bg-[#8B4513]/50 text-[#FBBF24]' : 'text-[#D2691E] hover:bg-white/[0.07]'}`}
          >
            <Terminal className="w-4 h-4" />
          </button>
          <button
            type="button"
            onClick={() => setShowTools((v) => !v)}
            title="B.A.R.B.I MCP tools"
            className={`p-1.5 rounded-md transition ${showTools ? 'bg-[#8B4513]/50 text-[#FBBF24]' : 'text-[#D2691E] hover:bg-white/[0.07]'}`}
          >
            <Plug className="w-4 h-4" />
          </button>
          <button type="button" onClick={() => setMaximized((v) => !v)} title={maximized ? 'Restore' : 'Maximize'} className="p-1.5 rounded-md text-[#D2691E] hover:bg-white/[0.07] transition">
            {maximized ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
          </button>
          <button type="button" onClick={() => setOpen(false)} aria-label="Close BARBI Agent" className="p-1.5 rounded-md text-stone-400 hover:text-white hover:bg-white/[0.07] transition">
            <X className="w-4 h-4" />
          </button>
        </div>
      </header>

      {showTools && (
        <div className="barbi-agent-divider px-3 py-2 max-h-28 overflow-y-auto shrink-0">
          <div className="text-[9.5px] font-mono-tech uppercase tracking-wider text-[#D2691E] mb-1.5">
            B.A.R.B.I MCP tools · {tools.length}
          </div>
          <div className="flex flex-wrap gap-1">
            {tools.map((tool) => (
              <span key={tool} className="barbi-agent-chip px-1.5 py-0.5 rounded text-[9px] font-mono-tech">
                {tool.replace('barbi_', '')}
              </span>
            ))}
          </div>
        </div>
      )}

      <div className="flex items-center gap-1.5 px-3 py-2 barbi-agent-divider overflow-x-auto shrink-0">
        {QUICK_ACTIONS.map((action) => (
          <button
            key={action.label}
            type="button"
            onClick={() => void send(action.prompt)}
            className="barbi-agent-chip shrink-0 px-2 py-1 rounded-lg text-[10px] cursor-pointer flex items-center gap-1"
          >
            <Zap className="w-2.5 h-2.5" />
            {action.label}
          </button>
        ))}
        <button type="button" onClick={() => void createSession()} className="barbi-agent-chip shrink-0 px-2 py-1 rounded-lg text-[10px] cursor-pointer flex items-center gap-1">
          <Plus className="w-2.5 h-2.5" /> New session
        </button>
      </div>

      {status?.lastError && (
        <div className="px-3 py-1.5 bg-red-950/40 border-b border-red-500/25 text-[10px] text-red-200 shrink-0">
          {status.lastError}
        </div>
      )}

      {view === 'console' ? (
        <div className="flex-1 min-h-0 flex flex-col">
          <div className="px-3 py-2 barbi-agent-divider shrink-0 flex flex-wrap items-center gap-2">
            <span className="text-[9.5px] font-mono-tech uppercase tracking-wider text-[#D2691E]">MCP Console</span>
            <select
              value={consoleTool}
              onChange={(e) => setConsoleTool(e.target.value)}
              aria-label="MCP tool"
              className="barbi-agent-input px-2 py-1 rounded text-[10px] font-mono-tech max-w-[240px]"
            >
              {toolOptions.map((t) => (
                <option key={t} value={t}>{t}</option>
              ))}
            </select>
            <button
              type="button"
              disabled={consoleBusy}
              onClick={() => void runTool()}
              className="barbi-agent-chip px-2.5 py-1 rounded text-[10px] font-mono-tech cursor-pointer disabled:opacity-40"
            >
              {consoleBusy ? <Loader2 className="w-3 h-3 inline animate-spin" /> : <Zap className="w-3 h-3 inline" />} Run tool
            </button>
            <span className="ml-auto text-[9px] font-mono-tech text-stone-500">Direct B.A.R.B.I MCP invocation</span>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 flex-1 min-h-0 p-3">
            <div className="flex flex-col min-h-0">
              <div className="text-[9.5px] font-mono-tech text-[#D2691E] mb-1">JSON INPUT</div>
              <textarea
                value={consoleInput}
                onChange={(e) => setConsoleInput(e.target.value)}
                spellCheck={false}
                className="barbi-agent-input flex-1 min-h-[140px] w-full p-2 rounded-lg text-[10.5px] font-mono-tech text-stone-200 resize-none outline-none"
              />
            </div>
            <div className="flex flex-col min-h-0">
              <div className="text-[9.5px] font-mono-tech text-[#D2691E] mb-1">RESULT</div>
              <pre className="barbi-agent-input flex-1 min-h-[140px] w-full p-2 rounded-lg text-[10.5px] font-mono-tech text-emerald-200/90 whitespace-pre-wrap overflow-auto">
                {consoleResult || 'Tool output will appear here.'}
              </pre>
            </div>
          </div>
          <div className="px-3 py-2 barbi-agent-divider shrink-0 flex flex-wrap gap-1.5">
            {[
              { label: 'Tree', tool: 'barbi_workspace_tree', input: '{\n  "subPath": "."\n}' },
              { label: 'Read file', tool: 'barbi_read_file', input: '{\n  "path": "package.json"\n}' },
              { label: 'Run lint', tool: 'barbi_run_command', input: '{\n  "command": "lint"\n}' },
              { label: 'Run build', tool: 'barbi_run_command', input: '{\n  "command": "build"\n}' },
              { label: 'Health', tool: 'barbi_health', input: '{}' },
              { label: 'Providers', tool: 'barbi_provider_status', input: '{}' },
              { label: 'Telemetry', tool: 'barbi_system_telemetry', input: '{}' },
              { label: 'Notebooks', tool: 'barbi_notebook_list', input: '{}' },
              { label: "God's Eye", tool: 'barbi_gods_eye_feeds', input: '{\n  "forceRefresh": false\n}' },
              { label: 'Social', tool: 'barbi_social_summary', input: '{}' },
            ].map((preset) => (
              <button
                key={preset.label}
                type="button"
                onClick={() => { setConsoleTool(preset.tool); setConsoleInput(preset.input); }}
                className="barbi-agent-chip px-2 py-0.5 rounded text-[9px] font-mono-tech cursor-pointer"
              >
                {preset.label}
              </button>
            ))}
          </div>
        </div>
      ) : view === 'workspace' ? (
        <div className="flex-1 min-h-0 flex flex-col">
          <div className="flex items-center justify-between px-3 py-1.5 barbi-agent-divider shrink-0">
            <span className="text-[9.5px] font-mono-tech uppercase tracking-wider text-[#D2691E]">Workspace tree</span>
            <button type="button" onClick={() => void loadTree()} className="barbi-agent-chip px-2 py-0.5 rounded text-[9px] flex items-center gap-1">
              <RefreshIcon loading={treeLoading} /> Refresh
            </button>
          </div>
          <pre className="flex-1 min-h-0 overflow-auto px-3 py-2 text-[10px] leading-relaxed text-stone-300 font-mono-tech whitespace-pre-wrap">
            {treeText || (treeLoading ? 'Loading workspace…' : 'No tree loaded.')}
          </pre>
          {sessions.length > 0 && (
            <div className="barbi-agent-divider px-3 py-2 max-h-28 overflow-y-auto shrink-0">
              <div className="text-[9.5px] font-mono-tech uppercase tracking-wider text-[#D2691E] mb-1">Sessions · {sessions.length}</div>
              <div className="flex flex-wrap gap-1">
                {sessions.map((s) => (
                  <button
                    key={s.id}
                    type="button"
                    onClick={() => { setActiveSession(s); setView('chat'); setLines((p) => [...p, { role: 'system', text: `Switched to session ${s.id}`, at: stamp() }]); }}
                    className={`barbi-agent-chip px-1.5 py-0.5 rounded text-[9px] font-mono-tech ${activeSession?.id === s.id ? 'ring-1 ring-[#FBBF24]/70' : ''}`}
                  >
                    {s.title || s.id.slice(0, 12)}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      ) : (
        <div ref={scrollRef} className="flex-1 min-h-0 overflow-y-auto px-3 py-3 space-y-2.5">
          {lines.map((line, i) => (
            <div key={i} className={`flex ${line.role === 'user' ? 'justify-end' : 'justify-start'}`}>
              <div
                className={`max-w-[92%] rounded-xl px-2.5 py-2 text-[11px] leading-relaxed whitespace-pre-wrap break-words ${
                  line.role === 'user'
                    ? 'barbi-agent-bubble-user text-[#FDE68A]'
                    : line.role === 'agent'
                      ? 'barbi-agent-bubble-agent text-stone-200 font-mono-tech'
                      : 'barbi-agent-bubble-agent text-[#D2691E]/90 italic'
                }`}
              >
                {line.text}
                <div className="mt-1 text-[8.5px] opacity-50 text-right font-mono-tech">{line.at}</div>
              </div>
            </div>
          ))}
          {busy && (
            <div className="flex items-center gap-2 text-[10px] text-[#FBBF24] font-mono-tech">
              <Loader2 className="w-3 h-3 animate-spin" /> BARBI Agent is working…
            </div>
          )}
        </div>
      )}

      <form onSubmit={handleSubmit} className="barbi-agent-divider px-3 py-2.5 flex items-center gap-2 shrink-0">
        <Terminal className="w-3.5 h-3.5 text-[#D2691E] shrink-0" />
        <input
          value={draft}
          onChange={(e) => setDraft(e.target.value)}
          placeholder="BARBI Agent — ask me to build, fix, or operate B.A.R.B.I…"
          className="barbi-agent-input flex-1 min-w-0 px-2.5 py-1.5 rounded-lg text-[11px] text-stone-100 placeholder-stone-500"
        />
        <button
          type="submit"
          disabled={busy || !draft.trim()}
          className="barbi-agent-chip px-3 py-1.5 rounded-lg text-[10px] font-semibold cursor-pointer disabled:opacity-40"
        >
          <Send className="w-3 h-3" />
        </button>
      </form>

      <div className="flex items-center justify-between px-3 py-1.5 barbi-agent-divider text-[9px] font-mono-tech text-stone-500 shrink-0">
        <span className="flex items-center gap-1">
          <ShieldCheck className="w-3 h-3 text-[#D2691E]" /> Full workspace access · permission guarded
        </span>
        <span className="flex items-center gap-1">
          <CircleDot className="w-3 h-3" /> {activeSession ? activeSession.id.slice(0, 14) : 'no session'}
        </span>
      </div>
    </aside>
  );
}

function RefreshIcon({ loading }: { loading: boolean }) {
  return <RefreshCw className={`w-3 h-3 ${loading ? 'animate-spin' : ''}`} />;
}
