import { useCallback, useEffect, useState, type FormEvent } from 'react';
import {
  AtSign,
  Bot,
  Check,
  CheckCircle2,
  Clock3,
  Inbox,
  Instagram,
  Loader2,
  MessageSquare,
  Plus,
  RefreshCw,
  Send,
  Settings2,
  ShieldCheck,
  Trash2,
  X,
  XCircle,
  Zap,
} from 'lucide-react';
import { barbiApi } from '../api/barbiClient';

type Platform = 'whatsapp' | 'telegram' | 'instagram' | 'tiktok';

interface Connection {
  platform: Platform;
  connected: boolean;
  mode: 'live' | 'webhook-only' | 'not-configured';
  detail: string;
  capabilities: string[];
}

interface SocialMsg {
  id: string;
  platform: Platform;
  direction: 'in' | 'out';
  threadId: string;
  author: { id: string; name: string };
  text: string;
  timestamp: number;
  matchedRuleId?: string;
}

interface Rule {
  id: string;
  name: string;
  platform: Platform | 'all';
  enabled: boolean;
  matchType: 'contains' | 'regex' | 'all';
  matchValue: string;
  replyTemplate: string;
  requireApproval: boolean;
}

interface Approval {
  id: string;
  message: SocialMsg;
  replyText: string;
  ruleId?: string;
  createdAt: number;
  status: string;
}

interface Summary {
  connections: Connection[];
  messages: SocialMsg[];
  rules: Rule[];
  approvals: Approval[];
  stats: {
    connectedPlatforms: number;
    totalPlatforms: number;
    messagesTracked: number;
    activeRules: number;
    pendingApprovals: number;
  };
}

declare global {
  interface Window {
    openSocialAgentPanel?: (options?: { open?: boolean }) => void;
  }
}

const PLATFORM_META: Record<Platform, { label: string; color: string; icon: typeof MessageSquare }> = {
  whatsapp: { label: 'WhatsApp', color: '#25D366', icon: MessageSquare },
  telegram: { label: 'Telegram', color: '#2AABEE', icon: Send },
  instagram: { label: 'Instagram', color: '#E1306C', icon: Instagram },
  tiktok: { label: 'TikTok', color: '#FE2C55', icon: AtSign },
};

const NEW_RULE: Omit<Rule, 'id'> = {
  name: '',
  platform: 'all',
  enabled: true,
  matchType: 'contains',
  matchValue: '',
  replyTemplate: 'Hi {{name}} — B.A.R.B.I. is online. How can I help?',
  requireApproval: false,
};

function timeLabel(ts: number) {
  try {
    return new Date(ts).toLocaleString([], { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
  } catch {
    return '';
  }
}

export function SocialAgentPanel() {
  const [open, setOpen] = useState(false);
  const [tab, setTab] = useState<'inbox' | 'rules' | 'approvals' | 'connections'>('inbox');
  const [summary, setSummary] = useState<Summary | null>(null);
  const [loading, setLoading] = useState(false);
  const [platformFilter, setPlatformFilter] = useState<Platform | 'all'>('all');
  const [draftPlatform, setDraftPlatform] = useState<Platform>('whatsapp');
  const [draftThread, setDraftThread] = useState('');
  const [draftText, setDraftText] = useState('');
  const [ruleDraft, setRuleDraft] = useState<Omit<Rule, 'id'> | Rule>({ ...NEW_RULE });
  const [editingRule, setEditingRule] = useState(false);
  const [toast, setToast] = useState('');

  const refresh = useCallback(async () => {
    setLoading(true);
    try {
      const data = await barbiApi.social.summary();
      setSummary(data as unknown as Summary);
    } catch (err) {
      setToast(`Failed to load: ${String(err)}`);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    window.openSocialAgentPanel = (options) => {
      if (typeof options?.open === 'boolean') setOpen(options.open);
      else setOpen((v) => !v);
    };
    return () => {
      delete window.openSocialAgentPanel;
    };
  }, []);

  useEffect(() => {
    if (open) void refresh();
  }, [open, refresh]);

  useEffect(() => {
    if (!toast) return;
    const t = setTimeout(() => setToast(''), 3200);
    return () => clearTimeout(t);
  }, [toast]);

  const handleSend = async (ev: FormEvent) => {
    ev.preventDefault();
    if (!draftThread.trim() || !draftText.trim()) return;
    try {
      const result = await barbiApi.social.send(draftPlatform, draftThread.trim(), draftText.trim());
      setToast(result.ok ? `Sent via ${PLATFORM_META[draftPlatform].label}` : `Send failed: ${result.error || 'unknown'}`);
      if (result.ok) {
        setDraftText('');
        void refresh();
      }
    } catch (err) {
      setToast(`Send failed: ${String(err)}`);
    }
  };

  const handleSaveRule = async (ev: FormEvent) => {
    ev.preventDefault();
    if (!ruleDraft.name.trim() || !ruleDraft.replyTemplate.trim()) return;
    try {
      await barbiApi.social.saveRule(ruleDraft as Record<string, unknown>);
      setToast(editingRule ? 'Rule updated' : 'Rule created');
      setRuleDraft({ ...NEW_RULE });
      setEditingRule(false);
      void refresh();
    } catch (err) {
      setToast(`Failed to save rule: ${String(err)}`);
    }
  };

  const handleResolve = async (id: string, approve: boolean) => {
    try {
      const result = await barbiApi.social.resolveApproval(id, approve);
      setToast(result.ok ? (approve ? 'Approved & delivered' : 'Rejected') : `Failed: ${result.error || 'unknown'}`);
      void refresh();
    } catch (err) {
      setToast(`Failed: ${String(err)}`);
    }
  };

  const handlePoll = async () => {
    setLoading(true);
    try {
      const result = await barbiApi.social.pollTelegram();
      setToast(`Telegram poll: ${result.processed} update(s)`);
      void refresh();
    } catch (err) {
      setToast(`Poll failed: ${String(err)}`);
    } finally {
      setLoading(false);
    }
  };

  if (!open) {
    // Launch is handled by the Nexus sphere node (app-social-agent) and the
    // voice/text router. No floating dock button should exist.
    return null;
  }

  const messages = (summary?.messages || []).filter((m) => platformFilter === 'all' || m.platform === platformFilter);

  return (
    <aside
      aria-label="B.A.R.B.I Social Agent"
      className="barbi-agent-panel fixed bottom-4 left-4 z-50 w-[min(calc(100vw-2rem),600px)] h-[min(86vh,780px)] flex flex-col rounded-2xl overflow-hidden text-stone-100"
    >
      <header className="barbi-agent-header flex items-center justify-between gap-2 px-3.5 py-2.5 shrink-0">
        <div className="flex items-center gap-2 min-w-0">
          <span className="w-7 h-7 rounded-lg bg-[#8B4513]/35 border border-[#D2691E]/60 flex items-center justify-center text-[#FBBF24]">
            <Bot className="w-4 h-4" />
          </span>
          <div className="min-w-0">
            <div className="text-[12px] font-semibold tracking-wide text-[#FBBF24] truncate">Social Agent</div>
            <div className="text-[9.5px] font-mono-tech text-[#D2691E]/85 truncate">
              {summary?.stats.connectedPlatforms ?? 0}/{summary?.stats.totalPlatforms ?? 4} connected · {summary?.stats.activeRules ?? 0} rules · {summary?.stats.pendingApprovals ?? 0} awaiting approval
            </div>
          </div>
        </div>
        <div className="flex items-center gap-1 shrink-0">
          <button type="button" onClick={() => void refresh()} title="Refresh" className="p-1.5 rounded-md text-[#D2691E] hover:bg-white/[0.07] transition">
            <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
          </button>
          <button type="button" onClick={() => setOpen(false)} aria-label="Close social agent" className="p-1.5 rounded-md text-stone-400 hover:text-white hover:bg-white/[0.07] transition">
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      </header>

      <nav className="barbi-agent-divider flex items-center gap-0.5 px-2 py-1.5 shrink-0">
        {([
          ['inbox', Inbox, 'Inbox'],
          ['rules', Zap, 'Automation'],
          ['approvals', ShieldCheck, 'Approvals'],
          ['connections', Settings2, 'Connections'],
        ] as const).map(([key, Icon, label]) => (
          <button
            key={key}
            type="button"
            onClick={() => setTab(key)}
            className={`barbi-agent-chip flex items-center gap-1.5 px-2.5 py-1.5 rounded-md text-[10px] font-medium cursor-pointer ${
              tab === key ? 'ring-1 ring-[#FBBF24]/60' : ''
            }`}
          >
            <Icon className="w-3.5 h-3.5" />
            {label}
            {key === 'approvals' && Boolean(summary?.approvals.length) && (
              <span className="px-1 rounded-full bg-red-500/30 text-red-200 text-[9px]">{summary.approvals.length}</span>
            )}
          </button>
        ))}
      </nav>

      <div className="flex-1 overflow-hidden flex flex-col">
        {tab === 'inbox' && (
          <>
            <div className="barbi-agent-divider flex items-center gap-1 px-3 py-2 overflow-x-auto shrink-0">
              <button
                type="button"
                onClick={() => setPlatformFilter('all')}
                className={`px-2 py-0.5 rounded text-[9.5px] font-mono-tech whitespace-nowrap ${platformFilter === 'all' ? 'barbi-agent-chip' : 'text-[#D2691E]/80 hover:bg-white/[0.06]'}`}
              >
                All
              </button>
              {(Object.keys(PLATFORM_META) as Platform[]).map((p) => (
                <button
                  key={p}
                  type="button"
                  onClick={() => setPlatformFilter(p)}
                  className={`px-2 py-0.5 rounded text-[9.5px] font-mono-tech whitespace-nowrap ${platformFilter === p ? 'barbi-agent-chip' : 'text-[#D2691E]/80 hover:bg-white/[0.06]'}`}
                >
                  {PLATFORM_META[p].label}
                </button>
              ))}
            </div>

            <div className="flex-1 overflow-y-auto px-3 py-2 space-y-2">
              {messages.length === 0 && (
                <div className="text-center py-10 text-[11px] text-stone-500">
                  No messages yet. Connect a platform in <button type="button" className="text-[#FBBF24] underline" onClick={() => setTab('connections')}>Connections</button>, then send a message below.
                </div>
              )}
              {messages.map((m) => {
                const meta = PLATFORM_META[m.platform];
                const Icon = meta.icon;
                return (
                  <div key={m.id} className={`p-2.5 rounded-lg border ${m.direction === 'in' ? 'bg-white/[0.035] border-[#8B4513]/25' : 'bg-[#8B4513]/15 border-[#8B4513]/45'}`}>
                    <div className="flex items-center gap-2 mb-1">
                      <Icon className="w-3.5 h-3.5" style={{ color: meta.color }} />
                      <span className="text-[10.5px] font-semibold text-stone-200">{m.author.name}</span>
                      <span className="text-[9px] text-stone-500">· {meta.label}</span>
                      <span className="ml-auto text-[9px] text-stone-600">{timeLabel(m.timestamp)}</span>
                    </div>
                    <p className="text-[11px] text-stone-300 whitespace-pre-wrap break-words">{m.text}</p>
                    {m.matchedRuleId && (
                      <div className="mt-1 text-[9px] font-mono-tech text-[#D2691E]/80">rule: {m.matchedRuleId}</div>
                    )}
                  </div>
                );
              })}
            </div>

            <form onSubmit={handleSend} className="barbi-agent-divider p-2.5 space-y-2">
              <div className="flex gap-2">
                <select
                  value={draftPlatform}
                  onChange={(e) => setDraftPlatform(e.target.value as Platform)}
                  className="w-28 px-2 py-1.5 rounded-md barbi-agent-input text-[10px] text-stone-200 outline-none"
                >
                  {(Object.keys(PLATFORM_META) as Platform[]).map((p) => (
                    <option key={p} value={p}>{PLATFORM_META[p].label}</option>
                  ))}
                </select>
                <input
                  value={draftThread}
                  onChange={(e) => setDraftThread(e.target.value)}
                  placeholder="chat ID / thread"
                  className="flex-1 px-2 py-1.5 rounded-md barbi-agent-input text-[10px] text-stone-200 placeholder-stone-600 outline-none"
                />
              </div>
              <div className="flex gap-2">
                <input
                  value={draftText}
                  onChange={(e) => setDraftText(e.target.value)}
                  placeholder="Type a reply…"
                  className="flex-1 px-2 py-1.5 rounded-md barbi-agent-input text-[11px] text-stone-200 placeholder-stone-600 outline-none"
                />
                <button type="submit" className="px-3 py-1.5 rounded-md barbi-agent-chip text-[11px] font-semibold transition">
                  <Send className="w-3.5 h-3.5" />
                </button>
              </div>
            </form>
          </>
        )}

        {tab === 'rules' && (
          <div className="flex-1 overflow-y-auto p-3 space-y-3">
            <form onSubmit={handleSaveRule} className="p-3 rounded-xl barbi-agent-bubble-agent space-y-2">
              <div className="text-[10px] font-mono-tech uppercase tracking-wider text-[#D2691E] mb-1">
                {editingRule ? 'Edit rule' : 'New automation rule'}
              </div>
              <div className="flex gap-2">
                <input
                  value={ruleDraft.name}
                  onChange={(e) => setRuleDraft({ ...ruleDraft, name: e.target.value })}
                  placeholder="Rule name"
                  className="flex-1 px-2 py-1.5 rounded barbi-agent-input text-[10px] text-stone-200 placeholder-stone-600 outline-none"
                />
                <select
                  value={ruleDraft.platform}
                  onChange={(e) => setRuleDraft({ ...ruleDraft, platform: e.target.value as Rule['platform'] })}
                  className="w-24 px-2 py-1.5 rounded barbi-agent-input text-[10px] text-stone-200 outline-none"
                >
                  <option value="all">All</option>
                  {(Object.keys(PLATFORM_META) as Platform[]).map((p) => (
                    <option key={p} value={p}>{PLATFORM_META[p].label}</option>
                  ))}
                </select>
              </div>
              <div className="flex gap-2">
                <select
                  value={ruleDraft.matchType}
                  onChange={(e) => setRuleDraft({ ...ruleDraft, matchType: e.target.value as Rule['matchType'] })}
                  className="w-28 px-2 py-1.5 rounded barbi-agent-input text-[10px] text-stone-200 outline-none"
                >
                  <option value="contains">Contains</option>
                  <option value="regex">Regex</option>
                  <option value="all">All messages</option>
                </select>
                <input
                  value={ruleDraft.matchValue}
                  onChange={(e) => setRuleDraft({ ...ruleDraft, matchValue: e.target.value })}
                  placeholder="match text or regex"
                  className="flex-1 px-2 py-1.5 rounded barbi-agent-input text-[10px] text-stone-200 placeholder-stone-600 outline-none"
                />
              </div>
              <textarea
                value={ruleDraft.replyTemplate}
                onChange={(e) => setRuleDraft({ ...ruleDraft, replyTemplate: e.target.value })}
                placeholder="Reply template (use {{name}}, {{text}}, {{platform}})"
                rows={2}
                className="w-full px-2 py-1.5 rounded barbi-agent-input text-[10px] text-stone-200 placeholder-stone-600 outline-none resize-none"
              />
              <div className="flex items-center gap-3">
                <label className="flex items-center gap-1.5 text-[10px] text-stone-400 cursor-pointer">
                  <input type="checkbox" checked={ruleDraft.enabled} onChange={(e) => setRuleDraft({ ...ruleDraft, enabled: e.target.checked })} className="accent-[#D2691E]" />
                  Enabled
                </label>
                <label className="flex items-center gap-1.5 text-[10px] text-stone-400 cursor-pointer">
                  <input type="checkbox" checked={ruleDraft.requireApproval} onChange={(e) => setRuleDraft({ ...ruleDraft, requireApproval: e.target.checked })} className="accent-[#D2691E]" />
                  Require approval
                </label>
                <div className="ml-auto flex gap-2">
                  {editingRule && (
                    <button type="button" onClick={() => { setRuleDraft({ ...NEW_RULE }); setEditingRule(false); }} className="px-2 py-1 rounded text-[10px] text-stone-400 hover:text-white">Cancel</button>
                  )}
                  <button type="submit" className="flex items-center gap-1 px-2.5 py-1 rounded barbi-agent-chip text-[10px] font-semibold">
                    {editingRule ? <Check className="w-3 h-3" /> : <Plus className="w-3 h-3" />}
                    {editingRule ? 'Update' : 'Create'}
                  </button>
                </div>
              </div>
            </form>

            {(summary?.rules || []).map((rule) => (
              <div key={rule.id} className="p-2.5 rounded-lg barbi-agent-bubble-agent flex items-start gap-2">
                <div className={`mt-0.5 w-2 h-2 rounded-full shrink-0 ${rule.enabled ? 'bg-emerald-400' : 'bg-stone-600'}`} />
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2">
                    <span className="text-[11px] font-semibold text-stone-200 truncate">{rule.name}</span>
                    <span className="text-[9px] font-mono-tech text-[#D2691E]/80">{rule.platform}</span>
                  </div>
                  <div className="text-[9.5px] font-mono-tech text-stone-500 mt-0.5">
                    {rule.matchType}: {rule.matchValue || '—'} {rule.requireApproval ? '· approval gate' : ''}
                  </div>
                  <div className="text-[10px] text-stone-400 mt-1 line-clamp-2">{rule.replyTemplate}</div>
                </div>
                <div className="flex gap-1 shrink-0">
                  <button type="button" title="Edit" onClick={() => { setRuleDraft(rule); setEditingRule(true); }} className="p-1 rounded text-[#D2691E] hover:bg-white/[0.07]"><Settings2 className="w-3.5 h-3.5" /></button>
                  <button type="button" title="Delete" onClick={async () => { await barbiApi.social.deleteRule(rule.id); void refresh(); }} className="p-1 rounded text-red-400 hover:bg-white/[0.07]"><Trash2 className="w-3.5 h-3.5" /></button>
                </div>
              </div>
            ))}
          </div>
        )}

        {tab === 'approvals' && (
          <div className="flex-1 overflow-y-auto p-3 space-y-2">
            <div className="flex items-center justify-between mb-1">
              <span className="text-[10px] font-mono-tech text-[#D2691E]">Pending approval queue · {summary?.approvals.length ?? 0}</span>
              <button type="button" onClick={() => void handlePoll()} className="flex items-center gap-1 px-2 py-1 rounded barbi-agent-chip cursor-pointer">
                <RefreshCw className="w-3 h-3" /> Poll Telegram inbox
              </button>
            </div>
            {(summary?.approvals || []).length === 0 && (
              <div className="text-center py-10 text-[11px] text-stone-500">Nothing awaiting approval.</div>
            )}
            {(summary?.approvals || []).map((a) => {
              const meta = PLATFORM_META[a.message.platform];
              return (
                <div key={a.id} className="p-3 rounded-lg barbi-agent-bubble-agent space-y-2">
                  <div className="flex items-center gap-2 text-[10px]">
                    <Clock3 className="w-3.5 h-3.5 text-amber-400" />
                    <span className="text-stone-400">{timeLabel(a.createdAt)}</span>
                    <span className="ml-auto px-1.5 py-0.5 rounded barbi-agent-chip font-mono-tech">{meta.label}</span>
                  </div>
                  <div className="text-[11px] text-stone-300">
                    <span className="text-stone-500">From {a.message.author.name}: </span>“{a.message.text}”
                  </div>
                  <div className="p-2 rounded barbi-agent-input text-[11px] text-[#FBBF24]/90">
                    Proposed reply: {a.replyText}
                  </div>
                  <div className="flex gap-2 justify-end">
                    <button type="button" onClick={() => void handleResolve(a.id, false)} className="flex items-center gap-1 px-2.5 py-1 rounded barbi-agent-chip text-red-300 text-[10px] hover:bg-red-500/25">
                      <XCircle className="w-3 h-3" /> Reject
                    </button>
                    <button type="button" onClick={() => void handleResolve(a.id, true)} className="flex items-center gap-1 px-2.5 py-1 rounded barbi-agent-chip text-emerald-300 text-[10px] hover:bg-emerald-500/25">
                      <CheckCircle2 className="w-3 h-3" /> Approve & send
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {tab === 'connections' && (
          <div className="flex-1 overflow-y-auto p-3 space-y-2">
            <div className="text-[10px] text-stone-500 mb-2 leading-relaxed">
              Connections use official APIs only — no scraping. Set the environment variables below on the host to enable read + auto-reply. Webhook URLs are ready even before credentials are added.
            </div>
            {(summary?.connections || []).map((c) => {
              const meta = PLATFORM_META[c.platform];
              const Icon = meta.icon;
              return (
                <div key={c.platform} className="p-3 rounded-lg barbi-agent-bubble-agent">
                  <div className="flex items-center gap-2">
                    <Icon className="w-4 h-4" style={{ color: meta.color }} />
                    <span className="text-[12px] font-semibold text-stone-200">{meta.label}</span>
                    <span className={`ml-auto flex items-center gap-1 text-[9.5px] font-mono-tech ${c.connected ? 'text-emerald-400' : 'text-stone-500'}`}>
                      <span className={`w-2 h-2 rounded-full ${c.connected ? 'bg-emerald-400' : 'bg-stone-600'}`} />
                      {c.mode === 'live' ? (c.connected ? 'LIVE' : 'unreachable') : c.mode === 'webhook-only' ? 'WEBHOOK' : 'NOT CONFIGURED'}
                    </span>
                  </div>
                  <div className="mt-1.5 text-[10px] text-stone-400 leading-relaxed">{c.detail}</div>
                  <div className="mt-1.5 flex flex-wrap gap-1">
                    {c.capabilities.map((cap) => (
                      <span key={cap} className="px-1.5 py-0.5 rounded barbi-agent-chip font-mono-tech text-[9px]">{cap}</span>
                    ))}
                  </div>
                  <div className="mt-2 text-[9px] font-mono-tech text-stone-600 break-all">
                    POST /api/social/webhook/{c.platform}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {toast && (
        <div className="px-3 py-2 border-t border-[#8B4513]/35 barbi-agent-bubble-agent text-[10px] text-[#FBBF24] flex items-center gap-2">
          {toast.startsWith('Failed') || toast.startsWith('Send failed') ? <XCircle className="w-3.5 h-3.5 text-red-400" /> : <Loader2 className="w-3.5 h-3.5" />}
          <span className="truncate">{toast}</span>
        </div>
      )}
    </aside>
  );
}
