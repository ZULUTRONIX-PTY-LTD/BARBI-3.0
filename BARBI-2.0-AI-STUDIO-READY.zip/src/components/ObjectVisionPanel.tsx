import { useCallback, useEffect, useRef, useState } from 'react';
import {
  Camera,
  CameraOff,
  Crosshair,
  ImageUp,
  Lock,
  ScanSearch,
  Sparkles,
  Trash2,
  Unlock,
} from 'lucide-react';
import {
  detectObjects,
  resetTracks,
  updateTracks,
  YOLO_MAX_DETECTIONS,
  type TrackedObject,
} from '../vision/objectDetector';

interface OverlayWindow {
  openOpenCodePanel?: (options: { open: boolean; prompt?: string }) => void;
  showToast?: (message: string, tone?: string) => void;
  __barbiObjectVisionState?: { open: boolean };
}

export default function ComputerVisionPanel() {
  const [open, setOpen] = useState(false);
  const [cameraOn, setCameraOn] = useState(false);
  const [status, setStatus] = useState('STANDBY');
  const [detections, setDetections] = useState<TrackedObject[]>([]);
  const [lockedId, setLockedId] = useState<number | null>(null);
  const [selectedId, setSelectedId] = useState<number | null>(null);
  const [showOnlyLocked, setShowOnlyLocked] = useState(false);
  const [source, setSource] = useState<'camera' | 'image'>('camera');

  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const imageRef = useRef<HTMLImageElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const timerRef = useRef<number | null>(null);
  const openRef = useRef(false);
  const lockedRef = useRef<number | null>(null);
  const trailsRef = useRef<Map<number, Array<{ x: number; y: number }>>>(new Map());

  openRef.current = open;
  lockedRef.current = lockedId;

  const publishState = useCallback((isOpen: boolean) => {
    (window as unknown as OverlayWindow).__barbiObjectVisionState = { open: isOpen };
  }, []);

  const stopCamera = useCallback(() => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((t) => t.stop());
      streamRef.current = null;
    }
    setCameraOn(false);
  }, []);

  const startCamera = useCallback(async () => {
    if (!navigator.mediaDevices?.getUserMedia) {
      setStatus('CAMERA_API_UNAVAILABLE — use a secure origin or the Tauri build');
      return;
    }
    try {
      setStatus('REQUESTING_CAMERA_PERMISSION');
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment', width: { ideal: 1280 }, height: { ideal: 720 } },
        audio: false,
      });
      streamRef.current = stream;
      const video = videoRef.current;
      if (video) {
        video.srcObject = stream;
        await video.play().catch(() => undefined);
      }
      setSource('camera');
      setCameraOn(true);
      setStatus('CAMERA_LIVE · YOLOv8n scanning');
      (window as unknown as OverlayWindow).showToast?.('Computer Vision camera online', 'accent');
    } catch (err) {
      const name = (err as DOMException)?.name || 'Error';
      const message = name === 'NotAllowedError'
        ? 'CAMERA_PERMISSION_DENIED — allow camera access, then press Enable Camera'
        : name === 'NotFoundError'
          ? 'NO_CAMERA_FOUND — use Image mode instead'
          : `CAMERA_ERROR_${name}`;
      setStatus(message);
      (window as unknown as OverlayWindow).showToast?.(message, 'info');
    }
  }, []);

  const drawFrame = useCallback((videoLike: HTMLVideoElement | HTMLImageElement, width: number, height: number) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    canvas.width = width;
    canvas.height = height;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.clearRect(0, 0, width, height);
    ctx.drawImage(videoLike, 0, 0, width, height);
    const line = Math.max(2, width / 420);
    const shown = showOnlyLocked ? detections.filter((d) => d.trackId === lockedRef.current) : detections;
    for (const d of shown.slice(0, YOLO_MAX_DETECTIONS)) {
      const isLocked = d.trackId === lockedRef.current;
      const isSelected = d.trackId === selectedId;
      const trail = trailsRef.current.get(d.trackId) || [];
      if (trail.length > 1) {
        ctx.beginPath();
        trail.forEach((p, i) => (i === 0 ? ctx.moveTo(p.x, p.y) : ctx.lineTo(p.x, p.y)));
        ctx.strokeStyle = isLocked ? 'rgba(248, 113, 113, 0.9)' : 'rgba(251, 191, 36, 0.55)';
        ctx.lineWidth = line;
        ctx.setLineDash([line * 2, line * 2]);
        ctx.stroke();
        ctx.setLineDash([]);
      }
      ctx.strokeStyle = isLocked ? '#F87171' : isSelected ? '#FDE68A' : '#FBBF24';
      ctx.lineWidth = isLocked ? line * 2 : line;
      ctx.strokeRect(d.x, d.y, d.width, d.height);
      const label = `${isLocked ? '◉ LOCKED ' : ''}#${d.trackId} ${d.className} ${Math.round(d.confidence * 100)}%`;
      ctx.font = `${Math.max(11, Math.round(width / 48))}px ui-monospace, monospace`;
      const tw = ctx.measureText(label).width + 12;
      const ly = Math.max(0, d.y - 24);
      ctx.fillStyle = isLocked ? 'rgba(90, 15, 15, 0.82)' : 'rgba(20, 10, 4, 0.76)';
      ctx.fillRect(d.x, ly, tw, 22);
      ctx.strokeStyle = isLocked ? '#F87171' : '#8B4513';
      ctx.lineWidth = 1;
      ctx.strokeRect(d.x, ly, tw, 22);
      ctx.fillStyle = isLocked ? '#FECACA' : '#FDE68A';
      ctx.fillText(label, d.x + 6, ly + 16);
    }
  }, [detections, selectedId, showOnlyLocked]);

  const runDetection = useCallback(async () => {
    const image = imageRef.current;
    const video = videoRef.current;
    const sourceEl = source === 'image' ? image : video;
    const width = source === 'image' ? image?.naturalWidth || 0 : video?.videoWidth || 0;
    const height = source === 'image' ? image?.naturalHeight || 0 : video?.videoHeight || 0;
    if (!sourceEl || width === 0 || height === 0 || (source === 'camera' && (!video || video.readyState < 2))) return;
    const found = await detectObjects(sourceEl, width, height);
    const tracked = updateTracks(found);
    for (const t of tracked) {
      const trail = trailsRef.current.get(t.trackId) || [];
      trail.push({ x: t.centerX, y: t.centerY });
      if (trail.length > 24) trail.shift();
      trailsRef.current.set(t.trackId, trail);
    }
    setDetections(tracked);
    const locked = tracked.find((t) => t.trackId === lockedRef.current);
    setStatus(
      source === 'image'
        ? `SNAPSHOT · ${tracked.length} objects identified${locked ? ` · locked ${locked.className}` : ''}`
        : `LIVE SCAN · ${tracked.length} objects${locked ? ` · tracking #${locked.trackId}` : ' · click a row to lock'}`,
    );
    drawFrame(sourceEl, width, height);
  }, [source, drawFrame]);

  useEffect(() => {
    if (!open || (source === 'camera' && !cameraOn) || (source === 'image' && !imageRef.current)) {
      if (timerRef.current) { window.clearInterval(timerRef.current); timerRef.current = null; }
      return;
    }
    void runDetection();
    timerRef.current = window.setInterval(() => { void runDetection(); }, 400);
    return () => { if (timerRef.current) { window.clearInterval(timerRef.current); timerRef.current = null; } };
  }, [open, cameraOn, source, runDetection]);

  useEffect(() => {
    const onToggle = (ev: Event) => {
      const detail = (ev as CustomEvent<{ open?: boolean }>).detail;
      const next = typeof detail?.open === 'boolean' ? detail.open : !openRef.current;
      setOpen(next);
      publishState(next);
      if (next && source === 'camera' && !cameraOn) void startCamera();
    };
    window.addEventListener('barbi:toggle-object-vision', onToggle as EventListener);
    return () => window.removeEventListener('barbi:toggle-object-vision', onToggle as EventListener);
  }, [startCamera, publishState, cameraOn, source]);

  useEffect(() => () => { stopCamera(); publishState(false); }, [stopCamera, publishState]);

  const onSnapshot = async () => {
    const input = document.getElementById('cv-image-input') as HTMLInputElement | null;
    input?.click();
  };

  const onImageSelected = (ev: React.ChangeEvent<HTMLInputElement>) => {
    const file = ev.target.files?.[0];
    if (!file) return;
    stopCamera();
    const img = new Image();
    img.onload = () => {
      imageRef.current = img;
      setSource('image');
      setDetections([]);
      resetTracks();
      trailsRef.current.clear();
      setLockedId(null);
      setStatus('SNAPSHOT LOADED · identifying…');
      void runDetection();
    };
    img.src = URL.createObjectURL(file);
  };

  const lockedObject = detections.find((d) => d.trackId === lockedId) || null;

  if (!open) return null;

  return (
    <section
      id="barbi-object-vision-panel"
      aria-label="B.A.R.B.I Computer Vision"
      className="barbi-agent-panel fixed z-50 flex flex-col overflow-hidden text-stone-100 inset-x-4 bottom-4 h-[min(88dvh,780px)]"
    >
      <header className="barbi-agent-header flex items-center justify-between gap-2 px-3.5 py-2.5 shrink-0">
        <div className="flex items-center gap-2 min-w-0">
          <span className="w-8 h-8 rounded bg-[#8B4513]/40 border border-[#D2691E]/70 flex items-center justify-center text-[#FBBF24] shadow-[0_0_14px_rgba(139,69,19,0.6)]">
            <Crosshair className="w-4 h-4" />
          </span>
          <div className="min-w-0">
            <div className="text-[13px] font-semibold tracking-wide text-[#FBBF24] truncate">COMPUTER VISION</div>
            <div className="text-[9.5px] font-mono-tech text-[#D2691E]/90 truncate">
              YOLOv8n · {status}
            </div>
          </div>
        </div>
        <div className="flex items-center gap-1 shrink-0">
          <button type="button" onClick={() => void startCamera()} title="Enable camera" className="p-1.5 rounded text-[#D2691E] hover:bg-white/[0.07] transition">
            <Camera className="w-3.5 h-3.5" />
          </button>
          <button type="button" onClick={() => { stopCamera(); setDetections([]); }} title="Stop camera" className="p-1.5 rounded text-[#D2691E] hover:bg-white/[0.07] transition">
            <CameraOff className="w-3.5 h-3.5" />
          </button>
          <button type="button" onClick={onSnapshot} title="Identify from image" className="p-1.5 rounded text-[#D2691E] hover:bg-white/[0.07] transition">
            <ImageUp className="w-3.5 h-3.5" />
          </button>
          <button type="button" onClick={() => { setDetections([]); resetTracks(); trailsRef.current.clear(); setLockedId(null); setStatus('TRACKS_RESET'); }} title="Clear tracks" className="p-1.5 rounded text-[#D2691E] hover:bg-white/[0.07] transition">
            <Trash2 className="w-3.5 h-3.5" />
          </button>
        </div>
      </header>

      <input id="cv-image-input" type="file" accept="image/*" className="hidden" onChange={onImageSelected} />

      <div className="relative flex-1 min-h-0 bg-black/35">
        <video ref={videoRef} autoPlay playsInline muted className={`absolute inset-0 w-full h-full object-contain ${source === 'camera' && cameraOn ? '' : 'hidden'}`} />
        <canvas
          ref={canvasRef}
          className={`absolute inset-0 w-full h-full object-contain ${cameraOn || source === 'image' ? '' : 'hidden'}`}
          onClick={(ev) => {
            const rect = ev.currentTarget.getBoundingClientRect();
            const x = ((ev.clientX - rect.left) / rect.width) * ev.currentTarget.width;
            const y = ((ev.clientY - rect.top) / rect.height) * ev.currentTarget.height;
            const hit = detections.find((d) => x >= d.x && x <= d.x + d.width && y >= d.y && y <= d.y + d.height);
            if (hit) { setSelectedId(hit.trackId); setLockedId(hit.trackId); }
          }}
        />
        {!cameraOn && source === 'camera' && (
          <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 text-[#D2691E]/85 px-6 text-center">
            <Crosshair className="w-9 h-9" />
            <div className="text-[11px] font-mono-tech uppercase tracking-widest">Camera standby</div>
            <div className="text-[10px] text-stone-400 max-w-md leading-relaxed">
              {status.includes('DENIED')
                ? 'Camera access is blocked. Allow camera permission for this app in your browser settings, then press Enable Camera. You can also identify an uploaded image instead.'
                : 'Press Enable Camera to grant access and begin live identification and tracking, or upload an image.'}
            </div>
            <button type="button" onClick={() => void startCamera()} className="px-3 py-1.5 rounded bg-[#8B4513]/50 border border-[#D2691E]/70 text-[#FBBF24] text-[10px] font-mono-tech hover:bg-[#8B4513]/70">
              Enable Camera
            </button>
          </div>
        )}
      </div>

      <div className="barbi-agent-divider flex items-center gap-2 px-3 py-2 shrink-0 flex-wrap">
        <span className="text-[9px] font-mono-tech uppercase tracking-wider text-[#D2691E]/90">Locked target</span>
        {lockedObject ? (
          <>
            <span className="text-[10px] font-mono-tech text-red-200">#{lockedObject.trackId} {lockedObject.className} · {Math.round(lockedObject.confidence * 100)}% · {(lockedObject.width).toFixed(0)}×{(lockedObject.height).toFixed(0)}px</span>
            <button type="button" onClick={() => setLockedId(null)} className="px-2 py-0.5 rounded border border-white/20 text-[9px] font-mono-tech text-stone-300 hover:bg-white/10">Unlock</button>
            <button type="button" onClick={() => (window as unknown as OverlayWindow).openOpenCodePanel?.({ open: true, prompt: `Computer Vision has locked object #${lockedObject.trackId} (${lockedObject.className}, confidence ${Math.round(lockedObject.confidence * 100)}%). Help me track and analyze this object across frames.` })} className="flex items-center gap-1 px-2 py-0.5 rounded border border-[#D2691E]/60 text-[9px] font-mono-tech text-[#FBBF24] hover:bg-[#8B4513]/40">
              <Sparkles className="w-3 h-3" /> Ask BARBI Agent
            </button>
          </>
        ) : (
          <span className="text-[10px] text-stone-500 italic">None — click an object in the frame or a row below to lock tracking</span>
        )}
        <label className="ml-auto flex items-center gap-1.5 text-[9px] font-mono-tech text-stone-400 cursor-pointer">
          <input type="checkbox" checked={showOnlyLocked} onChange={(e) => setShowOnlyLocked(e.target.checked)} className="accent-amber-500" />
          Show locked only
        </label>
      </div>

      <div className="barbi-agent-divider px-3 py-2 max-h-36 overflow-y-auto shrink-0">
        <div className="text-[9px] font-mono-tech uppercase tracking-wider text-[#D2691E]/90 mb-1.5">Tracked objects · click to lock</div>
        {detections.length === 0 ? (
          <div className="text-[10px] text-stone-400 italic">No objects yet — enable the camera or upload an image.</div>
        ) : (
          <div className="space-y-1">
            {detections.slice(0, YOLO_MAX_DETECTIONS).map((d) => (
              <button
                key={d.trackId}
                type="button"
                onClick={() => { setSelectedId(d.trackId); setLockedId(d.trackId); }}
                className={`w-full flex items-center justify-between gap-2 px-2 py-1 rounded-md border text-left transition ${d.trackId === lockedId ? 'border-red-400/70 bg-red-500/10' : 'border-white/[0.08] bg-white/[0.03] hover:bg-white/[0.07]'}`}
              >
                <span className="flex items-center gap-2 min-w-0 text-[10px] font-mono-tech text-stone-200 truncate">
                  {d.trackId === lockedId ? <Lock className="w-3 h-3 text-red-300 shrink-0" /> : <Unlock className="w-3 h-3 text-[#FBBF24] shrink-0" />}
                  #{d.trackId} {d.className}
                </span>
                <span className="text-[9px] font-mono-tech text-[#D2691E] shrink-0">{Math.round(d.confidence * 100)}%</span>
              </button>
            ))}
          </div>
        )}
      </div>

      <div className="flex items-center gap-2 px-3 py-2 border-t border-white/[0.08] shrink-0">
        <button type="button" onClick={() => void startCamera()} className="flex items-center gap-1.5 px-2.5 py-1.5 rounded bg-[#8B4513]/40 border border-[#D2691E]/60 text-[#FBBF24] text-[10px] font-mono-tech hover:bg-[#8B4513]/60 transition">
          <Camera className="w-3 h-3" /> Camera
        </button>
        <button type="button" onClick={onSnapshot} className="flex items-center gap-1.5 px-2.5 py-1.5 rounded bg-[#8B4513]/40 border border-[#D2691E]/60 text-[#FBBF24] text-[10px] font-mono-tech hover:bg-[#8B4513]/60 transition">
          <ScanSearch className="w-3 h-3" /> Image
        </button>
        <div className="ml-auto text-[9px] font-mono-tech text-[#D2691E]/80 uppercase tracking-wider flex items-center gap-1.5">
          <span className={`w-1.5 h-1.5 rounded-full ${cameraOn && source === 'camera' ? 'bg-emerald-400 animate-pulse' : source === 'image' ? 'bg-sky-400' : 'bg-stone-500'}`} />
          {cameraOn && source === 'camera' ? 'LIVE' : source === 'image' ? 'SNAPSHOT' : 'STANDBY'}
        </div>
      </div>
    </section>
  );
}
