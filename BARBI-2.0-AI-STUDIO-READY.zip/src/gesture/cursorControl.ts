/**
 * B.A.R.B.I Cursor Control
 * ------------------------
 * Turns MediaPipe hand landmarks into a real, usable pointer:
 *  - Virtual cursor overlay that follows the index fingertip (smoothed)
 *  - Pinch-to-click on ANY DOM element (buttons, inputs, tabs, sphere nodes)
 *  - Two-finger vertical scroll, fist release, dwell-free operation
 *  - Optional OS-level pointer control when running inside the Tauri desktop shell
 *
 * Browser-safe: everything degrades gracefully when Tauri is unavailable.
 */

export type CursorControlMode = 'off' | 'virtual' | 'os';

export interface CursorControlState {
  enabled: boolean;
  mode: CursorControlMode;
  x: number;
  y: number;
  pressed: boolean;
  osAvailable: boolean;
  lastTarget: string | null;
  clickCount: number;
}

export interface CursorControlOptions {
  /** 0..1 smoothing factor applied per frame. Higher = snappier. Default 0.42 */
  smoothing?: number;
  /** Minimum ms between two clicks. Default 260 */
  clickHoldMs?: number;
  /** Scroll pixels per normalized unit. Default 900 */
  scrollSensitivity?: number;
  /** Request native OS cursor when running under Tauri. Default true */
  preferOsCursor?: boolean;
  onStateChange?: (state: CursorControlState) => void;
}

type TauriInternals = {
  invoke?: (cmd: string, args?: Record<string, unknown>) => Promise<unknown>;
  __TAURI_INTERNALS__?: {
    invoke?: (cmd: string, args?: Record<string, unknown>) => Promise<unknown>;
  };
};

function getTauriInvoke(): ((cmd: string, args?: Record<string, unknown>) => Promise<unknown>) | null {
  if (typeof window === 'undefined') return null;
  const w = window as unknown as TauriInternals;
  const invoke = w.__TAURI_INTERNALS__?.invoke || w.invoke;
  return typeof invoke === 'function' ? invoke.bind(w) : null;
}

function describeTarget(el: Element | null): string | null {
  if (!el) return null;
  const tag = el.tagName.toLowerCase();
  const id = el.id ? `#${el.id}` : '';
  const label = el.getAttribute('aria-label') || el.getAttribute('title') || '';
  const cls = typeof el.className === 'string' && el.className ? `.${el.className.split(/\s+/)[0]}` : '';
  return `${tag}${id}${cls}${label ? ` [${label}]` : ''}`;
}

const CURSOR_CSS = `
#barbi-virtual-cursor {
  position: fixed;
  top: 0; left: 0;
  width: 34px; height: 34px;
  margin-left: -17px; margin-top: -17px;
  z-index: 2147483647;
  pointer-events: none;
  border-radius: 9999px;
  border: 2px solid rgba(210, 105, 30, 0.92);
  box-shadow: 0 0 0 1px rgba(0,0,0,0.65), 0 0 18px rgba(139, 69, 19, 0.75), inset 0 0 10px rgba(245, 158, 11, 0.35);
  background: radial-gradient(circle, rgba(245,158,11,0.22) 0%, rgba(139,69,19,0.08) 55%, transparent 70%);
  transition: width 90ms ease, height 90ms ease, margin 90ms ease, border-color 90ms ease;
  will-change: transform;
}
#barbi-virtual-cursor::after {
  content: '';
  position: absolute;
  inset: 50%;
  width: 5px; height: 5px;
  margin: -2.5px 0 0 -2.5px;
  border-radius: 9999px;
  background: #FBBF24;
  box-shadow: 0 0 8px #F59E0B;
}
#barbi-virtual-cursor.is-pressed {
  width: 22px; height: 22px;
  margin-left: -11px; margin-top: -11px;
  border-color: #FBBF24;
  background: radial-gradient(circle, rgba(245,158,11,0.5) 0%, rgba(139,69,19,0.18) 60%, transparent 75%);
}
#barbi-virtual-cursor.is-hidden { opacity: 0; }
#barbi-cursor-status {
  position: fixed;
  bottom: 14px; left: 50%;
  transform: translateX(-50%);
  z-index: 2147483647;
  pointer-events: none;
  padding: 5px 12px;
  border-radius: 9999px;
  border: 1px solid rgba(139, 69, 19, 0.85);
  background: rgba(12, 8, 5, 0.86);
  color: #D2691E;
  font: 600 10px/1.2 ui-monospace, SFMono-Regular, Menlo, monospace;
  letter-spacing: 0.08em;
  text-transform: uppercase;
  backdrop-filter: blur(8px);
  opacity: 0;
  transition: opacity 180ms ease;
}
#barbi-cursor-status.is-visible { opacity: 1; }
`;

class BarbiCursorController {
  private enabled = false;
  private mode: CursorControlMode = 'off';
  private options: CursorControlOptions = {};
  private cursorEl: HTMLDivElement | null = null;
  private statusEl: HTMLDivElement | null = null;
  private targetX = 0.5;
  private targetY = 0.5;
  private currentX = 0.5;
  private currentY = 0.5;
  private pressed = false;
  private wasPinched = false;
  private lastClickAt = 0;
  private clickCount = 0;
  private lastTarget: string | null = null;
  private osInvoke: ((cmd: string, args?: Record<string, unknown>) => Promise<unknown>) | null = null;
  private statusTimer: number | null = null;

  getState(): CursorControlState {
    return {
      enabled: this.enabled,
      mode: this.mode,
      x: this.currentX,
      y: this.currentY,
      pressed: this.pressed,
      osAvailable: Boolean(this.osInvoke),
      lastTarget: this.lastTarget,
      clickCount: this.clickCount,
    };
  }

  enable(options: CursorControlOptions = {}): boolean {
    if (typeof document === 'undefined') return false;
    this.options = options;
    this.osInvoke = getTauriInvoke();
    this.mode = options.preferOsCursor !== false && this.osInvoke ? 'os' : 'virtual';
    this.enabled = true;

    if (!document.getElementById('barbi-cursor-styles')) {
      const style = document.createElement('style');
      style.id = 'barbi-cursor-styles';
      style.textContent = CURSOR_CSS;
      document.head.appendChild(style);
    }

    if (this.mode === 'virtual') {
      if (!this.cursorEl) {
        this.cursorEl = document.createElement('div');
        this.cursorEl.id = 'barbi-virtual-cursor';
        this.cursorEl.setAttribute('aria-hidden', 'true');
        document.body.appendChild(this.cursorEl);
      }
      if (!this.statusEl) {
        this.statusEl = document.createElement('div');
        this.statusEl.id = 'barbi-cursor-status';
        this.statusEl.setAttribute('aria-hidden', 'true');
        document.body.appendChild(this.statusEl);
      }
      this.showStatus('Cursor control active');
    } else {
      this.showStatus('Native cursor control active');
    }

    this.emit();
    return true;
  }

  disable(): void {
    this.enabled = false;
    this.mode = 'off';
    this.pressed = false;
    this.wasPinched = false;
    if (this.cursorEl) this.cursorEl.classList.add('is-hidden');
    if (this.statusEl) this.statusEl.classList.remove('is-visible');
    this.emit();
  }

  /** Feed a normalized (0..1) fingertip position plus pinch state from the gesture frame. */
  update(normX: number, normY: number, isPinched: boolean, scrollDeltaY = 0): void {
    if (!this.enabled) return;

    const smoothing = Math.max(0.05, Math.min(1, this.options.smoothing ?? 0.42));
    this.targetX = Math.max(0, Math.min(1, normX));
    this.targetY = Math.max(0, Math.min(1, normY));
    this.currentX += (this.targetX - this.currentX) * smoothing;
    this.currentY += (this.targetY - this.currentY) * smoothing;

    const vw = typeof window !== 'undefined' ? window.innerWidth : 1920;
    const vh = typeof window !== 'undefined' ? window.innerHeight : 1080;
    const px = this.currentX * vw;
    const py = this.currentY * vh;

    if (this.mode === 'os' && this.osInvoke) {
      void this.osInvoke('barbi_cursor_move', { x: px, y: py }).catch(() => {
        // If the native bridge is missing, fall back to the virtual cursor.
        this.mode = 'virtual';
        if (!this.cursorEl) {
          this.cursorEl = document.createElement('div');
          this.cursorEl.id = 'barbi-virtual-cursor';
          this.cursorEl.setAttribute('aria-hidden', 'true');
          document.body.appendChild(this.cursorEl);
        }
      });
    } else if (this.cursorEl) {
      this.cursorEl.style.transform = `translate3d(${px}px, ${py}px, 0)`;
    }

    if (scrollDeltaY !== 0) {
      const amount = -scrollDeltaY * (this.options.scrollSensitivity ?? 900);
      if (this.mode === 'os' && this.osInvoke) {
        void this.osInvoke('barbi_cursor_scroll', { deltaY: amount }).catch(() => undefined);
      } else {
        window.scrollBy({ top: amount, behavior: 'auto' });
        const scroller = document.elementFromPoint(px, py)?.closest('[data-barbi-scroll]') as HTMLElement | null;
        if (scroller) scroller.scrollTop += amount;
      }
    }

    if (isPinched && !this.wasPinched) {
      this.press(px, py);
    } else if (!isPinched && this.wasPinched) {
      this.release(px, py);
    }
    this.wasPinched = isPinched;
    this.pressed = isPinched;
    this.emit();
  }

  /** Move to a screen point and click once (also used by UI automation). */
  clickAt(normX: number, normY: number): void {
    const vw = typeof window !== 'undefined' ? window.innerWidth : 1920;
    const vh = typeof window !== 'undefined' ? window.innerHeight : 1080;
    this.currentX = normX;
    this.currentY = normY;
    this.press(normX * vw, normY * vh);
    window.setTimeout(() => this.release(normX * vw, normY * vh), 90);
  }

  private press(px: number, py: number): void {
    this.cursorEl?.classList.add('is-pressed');
    if (this.mode === 'os' && this.osInvoke) {
      void this.osInvoke('barbi_cursor_click', { button: 'left', down: true }).catch(() => undefined);
      return;
    }
    const el = this.hitTest(px, py);
    this.lastTarget = describeTarget(el);
    if (!el) return;
    el.dispatchEvent(
      new PointerEvent('pointerdown', { bubbles: true, cancelable: true, clientX: px, clientY: py, pointerId: 99, pointerType: 'touch', isPrimary: true })
    );
    el.dispatchEvent(
      new MouseEvent('mousedown', { bubbles: true, cancelable: true, clientX: px, clientY: py, button: 0 })
    );
  }

  private release(px: number, py: number): void {
    this.cursorEl?.classList.remove('is-pressed');
    if (this.mode === 'os' && this.osInvoke) {
      void this.osInvoke('barbi_cursor_click', { button: 'left', down: false }).catch(() => undefined);
      return;
    }
    const el = this.hitTest(px, py);
    if (!el) return;
    const now = Date.now();
    if (now - this.lastClickAt < (this.options.clickHoldMs ?? 260)) return;
    this.lastClickAt = now;
    this.clickCount += 1;

    el.dispatchEvent(
      new PointerEvent('pointerup', { bubbles: true, cancelable: true, clientX: px, clientY: py, pointerId: 99, pointerType: 'touch', isPrimary: true })
    );
    el.dispatchEvent(
      new MouseEvent('mouseup', { bubbles: true, cancelable: true, clientX: px, clientY: py, button: 0 })
    );
    el.dispatchEvent(
      new MouseEvent('click', { bubbles: true, cancelable: true, clientX: px, clientY: py, button: 0 })
    );
    this.showStatus(`Clicked ${this.lastTarget || 'target'}`);
  }

  private hitTest(px: number, py: number): Element | null {
    const stack = document.elementsFromPoint(px, py);
    for (const el of stack) {
      if (el.id === 'barbi-virtual-cursor' || el.id === 'barbi-cursor-status') continue;
      if (el instanceof HTMLCanvasElement || el instanceof SVGElement) return el;
      const interactive = el.closest(
        'button,a,input,select,textarea,[role="button"],[role="tab"],[role="checkbox"],[role="switch"],[tabindex],label,.node-label,[data-barbi-click]'
      );
      if (interactive) return interactive;
    }
    return stack.find((el) => el !== this.cursorEl && el !== this.statusEl) || null;
  }

  private showStatus(text: string): void {
    if (!this.statusEl) return;
    this.statusEl.textContent = text;
    this.statusEl.classList.add('is-visible');
    if (this.statusTimer) window.clearTimeout(this.statusTimer);
    this.statusTimer = window.setTimeout(() => this.statusEl?.classList.remove('is-visible'), 1600);
  }

  private emit(): void {
    this.options.onStateChange?.(this.getState());
  }
}

export const barbiCursorController = new BarbiCursorController();
