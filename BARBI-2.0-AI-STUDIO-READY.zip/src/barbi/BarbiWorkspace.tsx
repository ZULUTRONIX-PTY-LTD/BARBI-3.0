import { useEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { installBarbiBridge } from './barbiBridge';
import { ensureBarbiThreePostProcessing } from './barbiPostProcessing';
import { NotebookStudioPanel } from '../components/NotebookStudioPanel';

declare global {
  interface Window {
    __initBarbiRuntime?: () => void;
    __barbiRuntimeBooted?: boolean;
  }
}

export function BarbiWorkspace() {
  const mountedRef = useRef(false);
  const [markup, setMarkup] = useState<string | null>(null);
  const [studioRoot, setStudioRoot] = useState<HTMLElement | null>(null);

  useEffect(() => {
    let cancelled = false;
    import('./barbiMarkup.html?raw').then((mod) => {
      if (!cancelled) setMarkup(mod.default as string);
    });
    return () => {
      cancelled = true;
    };
  }, []);

  useEffect(() => {
    if (!markup) return;
    if (mountedRef.current) return;
    mountedRef.current = true;

    ensureBarbiThreePostProcessing();
    installBarbiBridge();

    const bootRuntime = () => {
      const fn = (window as unknown as { __initBarbiRuntime?: () => void }).__initBarbiRuntime;
      if (typeof fn === 'function') fn();
    };

    if (typeof window.__initBarbiRuntime === 'function') {
      bootRuntime();
      return;
    }

    const existingScript = document.querySelector<HTMLScriptElement>('script[data-barbi-runtime="1"]');
    if (existingScript) {
      bootRuntime();
      return;
    }

    const script = document.createElement('script');
    script.src = '/barbi-runtime.js';
    script.async = false;
    script.dataset.barbiRuntime = '1';
    script.onload = bootRuntime;
    script.onerror = (err) => {
      console.error('Failed to load B.A.R.B.I runtime module:', err);
    };
    document.body.appendChild(script);
  }, [markup]);

  useEffect(() => {
    if (!markup) return;
    const raf = window.requestAnimationFrame(() => {
      setStudioRoot(document.getElementById('notebooklm-studio-root'));
    });
    return () => window.cancelAnimationFrame(raf);
  }, [markup]);

  if (!markup) {
    return (
      <div className="relative w-screen h-screen overflow-hidden bg-black select-none flex items-center justify-center text-white/60">
        Loading B.A.R.B.I workspace…
      </div>
    );
  }

  return (
    <>
      <div
        id="barbi-workspace-root"
        className="relative w-screen h-screen overflow-hidden bg-black select-none"
        dangerouslySetInnerHTML={{ __html: markup }}
      />
      {studioRoot ? createPortal(<NotebookStudioPanel />, studioRoot) : null}
    </>
  );
}
