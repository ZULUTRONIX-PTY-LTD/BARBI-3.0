import * as websfx from './websfx';

type SfxName = 'boot' | 'click' | 'back' | 'hover' | 'open' | 'close' | 'confirm' | 'alert';

interface BarbiSfxApi {
  play: (name: SfxName) => void;
  setEnabled: (enabled: boolean) => void;
  setVolume: (volume: number) => void;
  state: () => { enabled: boolean; volume: number };
}

declare global {
  interface Window {
    barbiSfx?: BarbiSfxApi;
  }
}

const ENABLE_KEY = 'barbi_sfx_enabled';
const VOLUME_KEY = 'barbi_sfx_volume';

let enabled = true;
let volume = 0.28;
try {
  enabled = window.localStorage.getItem(ENABLE_KEY) !== 'false';
  const raw = window.localStorage.getItem(VOLUME_KEY);
  if (raw !== null && raw !== '') {
    const parsed = Number(raw);
    if (Number.isFinite(parsed) && parsed >= 0 && parsed <= 1) volume = parsed;
  }
} catch {
  /* localStorage unavailable */
}

websfx.configure({ volume });

const sounds: Record<SfxName, (options?: { volume?: number }) => void> = {
  // Dry, low, mechanical tones — instrument-panel style rather than game chimes.
  boot: () => {
    websfx.beep({ frequency: 320, volume: 0.55 });
    window.setTimeout(() => websfx.longPress({ pitch: 0.7, volume: 0.35 }), 140);
  },
  click: () => websfx.press({ volume: 0.55 }),
  back: () => websfx.press({ volume: 0.45 }),
  hover: () => websfx.focus({ volume: 0.28 }),
  open: () => websfx.release({ volume: 0.5 }),
  close: () => websfx.press({ volume: 0.45 }),
  confirm: () => websfx.beep({ frequency: 520, volume: 0.5 }),
  alert: () => websfx.error({ volume: 0.5 }),
};

const api: BarbiSfxApi = {
  play(name) {
    if (!enabled || volume <= 0) return;
    try {
      sounds[name]?.();
    } catch {
      /* audio unavailable */
    }
  },
  setEnabled(next) {
    enabled = Boolean(next);
    try { window.localStorage.setItem(ENABLE_KEY, String(enabled)); } catch { /* ignore */ }
  },
  setVolume(next) {
    volume = Math.max(0, Math.min(1, Number(next) || 0));
    websfx.configure({ volume });
    try { window.localStorage.setItem(VOLUME_KEY, String(volume)); } catch { /* ignore */ }
  },
  state() {
    return { enabled, volume };
  },
};

window.barbiSfx = api;

let lastHover = 0;
document.addEventListener('click', (ev) => {
  const target = ev.target as HTMLElement | null;
  const el = target?.closest?.('button, [role="button"], select, input[type="checkbox"]') as HTMLElement | null;
  if (el && !(el as HTMLButtonElement).disabled) api.play('click');
}, true);

document.addEventListener('pointerover', (ev) => {
  const now = Date.now();
  if (now - lastHover < 90) return;
  const target = ev.target as HTMLElement | null;
  if (target?.closest?.('button, [role="button"]')) {
    lastHover = now;
    api.play('hover');
  }
}, true);

[
  'barbi:toggle-object-vision', 'barbi:toggle-gmail', 'barbi:toggle-v4-hub',
  'barbi:toggle-gods-eye', 'barbi:toggle-fs-agent', 'barbi:toggle-sphere-config',
  'barbi:toggle-gesture-nav', 'barbi:toggle-chat-panel', 'barbi:toggle-speedtest',
  'barbi:toggle-spotify', 'barbi:toggle-engineering-app',
].forEach((eventName) => {
  window.addEventListener(eventName, (ev) => {
    const detail = (ev as CustomEvent<{ open?: boolean }>).detail;
    if (typeof detail?.open === 'boolean') api.play(detail.open ? 'open' : 'close');
  }, true);
});

