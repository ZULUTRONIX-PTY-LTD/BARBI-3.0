/**
 * OpenCode Engine Adapter
 * -----------------------
 * Auto-detects a healthy background OpenCode service and connects to it with
 * @opencode/client. If none is available it embeds OpenCode directly with
 * @opencode/sdk (no HTTP listener). Both paths expose one uniform API to the
 * rest of B.A.R.B.I.
 */
import path from 'node:path';
import { OpenCode as Client } from '@opencode/client';
import { Service } from '@opencode/client/service';
import { OpenCode as Sdk } from '@opencode/sdk';

export type OpenCodeEngineMode = 'background-service' | 'embedded-sdk' | 'unavailable';

export interface OpenCodeSessionSummary {
  id: string;
  title?: string;
  directory?: string;
  updatedAt?: string;
}

type AnyClient = {
  session?: Record<string, (...args: any[]) => Promise<any>>;
  sessions?: Record<string, (...args: any[]) => Promise<any>>;
  provider?: Record<string, (...args: any[]) => Promise<any>>;
  server?: Record<string, (...args: any[]) => Promise<any>>;
  event?: Record<string, (...args: any[]) => Promise<any> | AsyncIterable<any>>;
  close?: () => Promise<void>;
  [key: string]: any;
};

interface Engine {
  mode: Exclude<OpenCodeEngineMode, 'unavailable'>;
  client: AnyClient;
  close?: () => Promise<void>;
}

let enginePromise: Promise<Engine> | null = null;
let lastError: string | null = null;

const WORKSPACE_DIR = path.resolve(process.cwd());

function pickSessionResource(client: AnyClient): Record<string, (...args: any[]) => Promise<any>> {
  return client.session || client.sessions || {};
}

async function createEngine(): Promise<Engine> {
  // 1. Prefer the shared background service when it is already healthy.
  try {
    const endpoint = await Service.discover();
    if (endpoint?.url) {
      const client = Client.make({
        baseUrl: endpoint.url,
        headers: Service.headers(endpoint),
      }) as unknown as AnyClient;
      return { mode: 'background-service', client };
    }
  } catch (err) {
    lastError = err instanceof Error ? err.message : String(err);
  }

  // 2. Embed OpenCode in-process with the SDK. No listener, no network hop.
  const sdk = (await Sdk.create()) as unknown as AnyClient;
  return {
    mode: 'embedded-sdk',
    client: sdk,
    close: () => sdk.close?.() ?? Promise.resolve(),
  };
}

export async function getOpenCodeEngine(): Promise<Engine> {
  if (!enginePromise) {
    enginePromise = createEngine().catch((err) => {
      enginePromise = null;
      lastError = err instanceof Error ? err.message : String(err);
      throw err;
    });
  }
  return enginePromise;
}

export async function getOpenCodeStatus() {
  try {
    const engine = await getOpenCodeEngine();
    let info: unknown = null;
    let providers: unknown = null;
    try {
      info = await engine.client.server?.info?.();
    } catch {
      /* older builds may not expose server.info */
    }
    try {
      providers = await engine.client.provider?.list?.();
    } catch {
      /* provider list is optional */
    }
    return {
      available: true,
      mode: engine.mode,
      workspace: WORKSPACE_DIR,
      info,
      providers,
      lastError,
    };
  } catch (err) {
    return {
      available: false,
      mode: 'unavailable' as OpenCodeEngineMode,
      workspace: WORKSPACE_DIR,
      info: null,
      providers: null,
      lastError: err instanceof Error ? err.message : String(err),
    };
  }
}

export async function listOpenCodeSessions(): Promise<OpenCodeSessionSummary[]> {
  const engine = await getOpenCodeEngine();
  const resource = pickSessionResource(engine.client);
  if (!resource.list) return [];
  const result = await resource.list();
  const rows = Array.isArray(result) ? result : ((result as any)?.data ?? (result as any)?.sessions ?? []);
  return (Array.isArray(rows) ? rows : []).map((row: any) => ({
    id: String(row?.id ?? ''),
    title: row?.title ? String(row.title) : undefined,
    directory: row?.directory ? String(row.directory) : undefined,
    updatedAt: row?.time?.updated || row?.updatedAt ? String(row?.time?.updated || row.updatedAt) : undefined,
  }));
}

export async function createOpenCodeSession(input: { title?: string; directory?: string }) {
  const engine = await getOpenCodeEngine();
  const resource = pickSessionResource(engine.client);
  if (!resource.create) throw new Error('OpenCode session.create is unavailable');
  const result = await resource.create({
    location: { directory: input.directory || WORKSPACE_DIR },
    ...(input.title ? { title: input.title } : {}),
  });
  return result?.data ?? result;
}

function extractAssistantText(messages: unknown[]): string {
  const chunks: string[] = [];
  for (const msg of messages) {
    const m = msg as { type?: string; content?: Array<{ type?: string; text?: string }> };
    if (m?.type !== 'assistant' || !Array.isArray(m.content)) continue;
    for (const part of m.content) {
      if (part?.type === 'text' && typeof part.text === 'string') chunks.push(part.text);
    }
  }
  return chunks.reverse().join('\n\n').trim();
}

export async function promptOpenCodeSession(input: { sessionID: string; text: string }) {
  const engine = await getOpenCodeEngine();
  const resource = pickSessionResource(engine.client);
  if (!resource.prompt) throw new Error('OpenCode session.prompt is unavailable');

  // `prompt` enqueues the user message and returns immediately. Wait for the
  // session to finish, then read back the assistant messages so the caller
  // receives the actual answer rather than the echoed prompt.
  const userMessage = await resource.prompt({ sessionID: input.sessionID, text: input.text });

  let waited = false;
  try {
    if (resource.wait) {
      await resource.wait({ sessionID: input.sessionID });
      waited = true;
    }
  } catch {
    /* some builds do not expose session.wait; fall back to polling below */
  }

  let messages: unknown[] = [];
  try {
    messages = await getOpenCodeMessages(input.sessionID);
    if (!waited && messages.length === 0) {
      for (let attempt = 0; attempt < 20; attempt += 1) {
        await new Promise((r) => setTimeout(r, 750));
        messages = await getOpenCodeMessages(input.sessionID);
        if (messages.some((m) => (m as { type?: string })?.type === 'assistant')) break;
      }
    }
  } catch {
    /* message read is best-effort */
  }

  const text = extractAssistantText(messages);

  let engineError: string | null = null;
  for (const msg of messages) {
    const m = msg as { type?: string; outcome?: string; finish?: string; error?: { message?: string } };
    const failed =
      (m?.type === 'idle' && m.outcome === 'failed') ||
      (m?.type === 'assistant' && m.finish === 'error');
    if (failed && m?.error?.message) {
      engineError = m.error.message;
      break;
    }
  }

  return {
    userMessage: userMessage?.data ?? userMessage,
    text: engineError
      ? `OpenCode engine error: ${engineError}`
      : text || 'OpenCode processed the prompt but returned no text output.',
    error: engineError,
    messages,
  };
}

export async function getOpenCodeMessages(sessionID: string): Promise<unknown[]> {
  const engine = await getOpenCodeEngine();
  const messageApi = engine.client.message as
    | { list?: (input: { sessionID: string; limit?: number; order?: 'asc' | 'desc'; type?: string }) => Promise<any> }
    | undefined;
  if (!messageApi?.list) return [];
  const result = await messageApi.list({ sessionID, limit: 30, order: 'desc' });
  return (result?.data ?? result ?? []) as unknown[];
}

/** Subscribe to the OpenCode event stream. Returns an unsubscribe function. */
export async function subscribeOpenCodeEvents(onEvent: (event: unknown) => void): Promise<() => void> {
  const engine = await getOpenCodeEngine();
  const event = engine.client.event;
  const subscribe = event?.subscribe;
  if (!subscribe) return () => undefined;

  const controller = new AbortController();
  void (async () => {
    try {
      const stream = await subscribe.call(event, undefined, { signal: controller.signal });
      for await (const item of stream as AsyncIterable<unknown>) {
        onEvent(item);
      }
    } catch {
      /* stream closed */
    }
  })();

  return () => controller.abort();
}

export async function closeOpenCodeEngine(): Promise<void> {
  if (!enginePromise) return;
  try {
    const engine = await enginePromise;
    await engine.close?.();
  } finally {
    enginePromise = null;
  }
}
