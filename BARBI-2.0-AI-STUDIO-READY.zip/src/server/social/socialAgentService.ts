/**
 * B.A.R.B.I Social Agent
 * ----------------------
 * One normalized inbox + reply engine across WhatsApp, Telegram, Instagram and
 * TikTok. Every platform is a pluggable adapter; inbound messages flow through
 * an automation rules engine that can reply instantly or hold for approval.
 *
 * Nothing here scrapes a website. Connections use official/self-hosted APIs:
 *  - WhatsApp: WAHA (self-hosted WhatsApp HTTP API) — WAHA_BASE_URL, WAHA_API_KEY, WAHA_SESSION
 *  - Telegram: Bot API — TELEGRAM_BOT_TOKEN, TELEGRAM_CHAT_ID
 *  - Instagram: Meta Graph API — IG_ACCESS_TOKEN, IG_USER_ID (needs instagram_manage_messages)
 *  - TikTok: Business Messaging webhooks — TIKTOK_ACCESS_TOKEN, TIKTOK_BUSINESS_ID
 */
import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';

export type SocialPlatform = 'whatsapp' | 'telegram' | 'instagram' | 'tiktok';

export interface SocialMessage {
  id: string;
  platform: SocialPlatform;
  direction: 'in' | 'out';
  threadId: string;
  author: { id: string; name: string };
  text: string;
  timestamp: number;
  matchedRuleId?: string;
  raw?: unknown;
}

export interface SocialConnection {
  platform: SocialPlatform;
  connected: boolean;
  mode: 'live' | 'webhook-only' | 'not-configured';
  detail: string;
  capabilities: Array<'read' | 'send' | 'webhook'>;
}

export interface AutomationRule {
  id: string;
  name: string;
  platform: SocialPlatform | 'all';
  enabled: boolean;
  matchType: 'contains' | 'regex' | 'all';
  matchValue: string;
  replyTemplate: string;
  requireApproval: boolean;
  createdAt: number;
}

export interface ApprovalItem {
  id: string;
  message: SocialMessage;
  replyText: string;
  ruleId?: string;
  createdAt: number;
  status: 'pending' | 'approved' | 'rejected';
}

const STORE_PATH = path.resolve(process.cwd(), '.barbi-hosted', 'social-agent-store.json');

interface StoreShape {
  rules: AutomationRule[];
  messages: SocialMessage[];
  approvals: ApprovalItem[];
  telegramOffset: number;
}

const DEFAULT_RULES: AutomationRule[] = [
  {
    id: 'rule-auto-greeting',
    name: 'Auto-reply: greeting',
    platform: 'all',
    enabled: true,
    matchType: 'contains',
    matchValue: 'hello',
    replyTemplate: 'Hi {{name}} — B.A.R.B.I. is online. How can I help you today?',
    requireApproval: false,
    createdAt: Date.now(),
  },
  {
    id: 'rule-auto-availability',
    name: 'Auto-reply: availability',
    platform: 'all',
    enabled: true,
    matchType: 'contains',
    matchValue: 'are you there',
    replyTemplate: 'Yes, {{name}} — I am here and listening. Send your message anytime.',
    requireApproval: false,
    createdAt: Date.now(),
  },
];

let store: StoreShape = {
  rules: DEFAULT_RULES.slice(),
  messages: [],
  approvals: [],
  telegramOffset: 0,
};
let loadPromise: Promise<void> | null = null;

async function ensureLoaded(): Promise<void> {
  if (!loadPromise) {
    loadPromise = (async () => {
      try {
        const raw = await fs.readFile(STORE_PATH, 'utf8');
        const parsed = JSON.parse(raw) as Partial<StoreShape>;
        store = {
          rules: Array.isArray(parsed.rules) ? parsed.rules : DEFAULT_RULES.slice(),
          messages: Array.isArray(parsed.messages) ? parsed.messages.slice(-500) : [],
          approvals: Array.isArray(parsed.approvals) ? parsed.approvals : [],
          telegramOffset: typeof parsed.telegramOffset === 'number' ? parsed.telegramOffset : 0,
        };
      } catch {
        // First run — keep defaults.
      }
    })();
  }
  return loadPromise;
}

async function persist(): Promise<void> {
  try {
    await fs.mkdir(path.dirname(STORE_PATH), { recursive: true });
    await fs.writeFile(STORE_PATH, JSON.stringify(store, null, 2), 'utf8');
  } catch {
    // Persistence is best-effort; the agent still works in memory.
  }
}

function mask(value: string | undefined): string {
  if (!value) return 'not configured';
  if (value.length <= 8) return '••••';
  return `${value.slice(0, 4)}••••${value.slice(-2)}`;
}

// ---------------------------------------------------------------- Connections

export async function getSocialConnections(): Promise<SocialConnection[]> {
  await ensureLoaded();
  const wahaUrl = process.env.WAHA_BASE_URL;
  const wahaSession = process.env.WAHA_SESSION || 'default';
  const tgToken = process.env.TELEGRAM_BOT_TOKEN;
  const igToken = process.env.IG_ACCESS_TOKEN;
  const igUser = process.env.IG_USER_ID;
  const tiktokToken = process.env.TIKTOK_ACCESS_TOKEN;

  const connections: SocialConnection[] = [];

  if (wahaUrl) {
    let detail = `WAHA at ${wahaUrl} (session ${wahaSession})`;
    let connected = false;
    try {
      const ctrl = new AbortController();
      const timer = setTimeout(() => ctrl.abort(), 4000);
      const r = await fetch(`${wahaUrl.replace(/\/$/, '')}/api/sessions/${encodeURIComponent(wahaSession)}`, {
        headers: process.env.WAHA_API_KEY ? { 'X-Api-Key': process.env.WAHA_API_KEY } : {},
        signal: ctrl.signal,
      });
      clearTimeout(timer);
      connected = r.ok;
      if (r.ok) {
        const j = await r.json().catch(() => ({}));
        detail = `WAHA session ${wahaSession}: ${j?.state || 'CONNECTED'}`;
      }
    } catch {
      detail = `WAHA configured at ${wahaUrl} but unreachable`;
    }
    connections.push({ platform: 'whatsapp', connected, mode: 'live', detail, capabilities: ['read', 'send', 'webhook'] });
  } else {
    connections.push({
      platform: 'whatsapp',
      connected: false,
      mode: 'not-configured',
      detail: 'Set WAHA_BASE_URL, WAHA_SESSION (and WAHA_API_KEY if needed) to enable read + reply.',
      capabilities: ['webhook'],
    });
  }

  connections.push({
    platform: 'telegram',
    connected: Boolean(tgToken),
    mode: tgToken ? 'live' : 'not-configured',
    detail: tgToken ? `Bot token ${mask(tgToken)}, chat ${process.env.TELEGRAM_CHAT_ID || 'default'}` : 'Set TELEGRAM_BOT_TOKEN to enable read + reply.',
    capabilities: tgToken ? ['read', 'send', 'webhook'] : ['send'],
  });

  connections.push({
    platform: 'instagram',
    connected: Boolean(igToken && igUser),
    mode: igToken && igUser ? 'live' : 'not-configured',
    detail: igToken && igUser
      ? `Graph API user ${igUser} with token ${mask(igToken)}`
      : 'Set IG_ACCESS_TOKEN and IG_USER_ID (Meta app needs instagram_manage_messages).',
    capabilities: igToken && igUser ? ['read', 'send', 'webhook'] : ['webhook'],
  });

  connections.push({
    platform: 'tiktok',
    connected: Boolean(tiktokToken),
    mode: tiktokToken ? 'webhook-only' : 'not-configured',
    detail: tiktokToken
      ? `Business Messaging token ${mask(tiktokToken)} — webhook ingest active`
      : 'Set TIKTOK_ACCESS_TOKEN and register a Business Messaging webhook.',
    capabilities: ['webhook', ...(tiktokToken ? (['send'] as const) : [])],
  });

  return connections;
}

// ---------------------------------------------------------------- Normalization

export function normalizeInbound(platform: SocialPlatform, payload: Record<string, any>): SocialMessage {
  const now = Date.now();
  if (platform === 'whatsapp') {
    // WAHA webhook: { event: "message", payload: { id, from, to, body, timestamp, chatId } }
    const p = payload.payload || payload;
    const id = String(p.id || p.messageId || crypto.randomUUID());
    const from = String(p.from || p.author || p.chatId || 'unknown');
    return {
      id: `wa:${id}`,
      platform,
      direction: p.direction === 'out' ? 'out' : 'in',
      threadId: String(p.chatId || from),
      author: { id: from, name: String(p.senderName || p.pushName || from) },
      text: String(p.body || p.text || p.caption || ''),
      timestamp: Number(p.timestamp || now / 1000) * (p.timestamp ? 1000 : 1),
      raw: payload,
    };
  }
  if (platform === 'telegram') {
    const p = payload.message || payload;
    const id = String(p.message_id || p.messageId || crypto.randomUUID());
    const chat = p.chat || {};
    const from = p.from || {};
    return {
      id: `tg:${id}`,
      platform,
      direction: 'in',
      threadId: String(chat.id || process.env.TELEGRAM_CHAT_ID || 'default'),
      author: { id: String(from.id || ''), name: String(from.username || [from.first_name, from.last_name].filter(Boolean).join(' ') || 'Telegram user') },
      text: String(p.text || p.caption || ''),
      timestamp: Number(p.date || now / 1000) * (p.date ? 1000 : 1),
      raw: payload,
    };
  }
  if (platform === 'instagram') {
    const p = payload.entry?.[0]?.messaging?.[0] || payload.payload || payload;
    const id = String(p.id || p.message?.mid || crypto.randomUUID());
    const sender = String(p.sender?.id || p.from?.id || 'unknown');
    return {
      id: `ig:${id}`,
      platform,
      direction: 'in',
      threadId: String(p.conversation?.id || p.threadId || sender),
      author: { id: sender, name: String(p.sender?.name || 'Instagram user') },
      text: String(p.message?.text || p.text || ''),
      timestamp: Number(p.timestamp || now),
      raw: payload,
    };
  }
  const p = payload.event?.message || payload.payload || payload;
  const id = String(p.message_id || p.id || crypto.randomUUID());
  const sender = String(p.sender_id || p.from || 'unknown');
  return {
    id: `tt:${id}`,
    platform,
    direction: 'in',
    threadId: String(p.conversation_id || p.chatId || sender),
    author: { id: sender, name: String(p.sender_name || 'TikTok user') },
    text: String(p.text || p.content || ''),
    timestamp: Number(p.create_time || now / 1000) * (p.create_time ? 1000 : 1),
    raw: payload,
  };
}

// ---------------------------------------------------------------- Outbound

export async function sendSocialMessage(input: {
  platform: SocialPlatform;
  threadId: string;
  text: string;
}): Promise<{ ok: boolean; detail?: string; error?: string }> {
  await ensureLoaded();
  const { platform, threadId, text } = input;
  const headers = { 'Content-Type': 'application/json' };

  try {
    if (platform === 'whatsapp') {
      const base = process.env.WAHA_BASE_URL;
      if (!base) throw new Error('WAHA_BASE_URL is not configured');
      const session = process.env.WAHA_SESSION || 'default';
      const auth: Record<string, string> = {};
      if (process.env.WAHA_API_KEY) auth['X-Api-Key'] = process.env.WAHA_API_KEY;
      const r = await fetch(`${base.replace(/\/$/, '')}/api/${encodeURIComponent(session)}/sendText`, {
        method: 'POST',
        headers: { ...headers, ...auth },
        body: JSON.stringify({ chatId: threadId, text }),
      });
      if (!r.ok) throw new Error(`WAHA returned HTTP ${r.status}`);
      const result = await r.json().catch(() => ({}));
      pushMessage({ id: `wa-out:${crypto.randomUUID()}`, platform, direction: 'out', threadId, author: { id: 'barbi', name: 'B.A.R.B.I.' }, text, timestamp: Date.now(), raw: result });
      await persist();
      return { ok: true, detail: 'Delivered via WAHA' };
    }

    if (platform === 'telegram') {
      const token = process.env.TELEGRAM_BOT_TOKEN;
      if (!token) throw new Error('TELEGRAM_BOT_TOKEN is not configured');
      const r = await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
        method: 'POST',
        headers,
        body: JSON.stringify({ chat_id: threadId || process.env.TELEGRAM_CHAT_ID, text }),
      });
      const j = await r.json().catch(() => ({}));
      if (!r.ok || j?.ok === false) throw new Error(j?.description || `Telegram HTTP ${r.status}`);
      pushMessage({ id: `tg-out:${crypto.randomUUID()}`, platform, direction: 'out', threadId, author: { id: 'barbi', name: 'B.A.R.B.I.' }, text, timestamp: Date.now(), raw: j });
      await persist();
      return { ok: true, detail: 'Delivered via Telegram Bot API' };
    }

    if (platform === 'instagram') {
      const token = process.env.IG_ACCESS_TOKEN;
      if (!token) throw new Error('IG_ACCESS_TOKEN is not configured');
      const r = await fetch(`https://graph.facebook.com/v20.0/${encodeURIComponent(threadId)}/messages`, {
        method: 'POST',
        headers,
        body: JSON.stringify({ message: { text }, access_token: token }),
      });
      const j = await r.json().catch(() => ({}));
      if (!r.ok || j?.error) throw new Error(j?.error?.message || `Instagram HTTP ${r.status}`);
      pushMessage({ id: `ig-out:${crypto.randomUUID()}`, platform, direction: 'out', threadId, author: { id: 'barbi', name: 'B.A.R.B.I.' }, text, timestamp: Date.now(), raw: j });
      await persist();
      return { ok: true, detail: 'Delivered via Meta Graph API' };
    }

    throw new Error(`TikTok outbound sending requires a Business Messaging app token; webhook ingest is active but auto-send is disabled by default.`);
  } catch (err) {
    return { ok: false, error: err instanceof Error ? err.message : String(err) };
  }
}

function pushMessage(msg: SocialMessage): void {
  store.messages.push(msg);
  if (store.messages.length > 500) store.messages.splice(0, store.messages.length - 500);
}

// ---------------------------------------------------------------- Automation

function fillTemplate(template: string, msg: SocialMessage): string {
  return template
    .replace(/\{\{name\}\}/g, msg.author.name || 'there')
    .replace(/\{\{platform\}\}/g, msg.platform)
    .replace(/\{\{text\}\}/g, msg.text.slice(0, 200));
}

function matchesRule(rule: AutomationRule, msg: SocialMessage): boolean {
  if (!rule.enabled || (rule.platform !== 'all' && rule.platform !== msg.platform)) return false;
  if (rule.matchType === 'all') return true;
  if (rule.matchType === 'contains') return msg.text.toLowerCase().includes(rule.matchValue.toLowerCase());
  if (rule.matchType === 'regex') {
    try { return new RegExp(rule.matchValue, 'i').test(msg.text); } catch { return false; }
  }
  return false;
}

/** Ingest one inbound message: normalize → match rules → reply or queue approval. */
export async function ingestSocialMessage(
  platform: SocialPlatform,
  payload: Record<string, any>
): Promise<{ message: SocialMessage; action: 'replied' | 'queued' | 'ignored'; replyText?: string; approvalId?: string }> {
  await ensureLoaded();
  const message = normalizeInbound(platform, payload);
  if (message.direction === 'out' || !message.text) {
    return { message, action: 'ignored' };
  }
  pushMessage(message);

  const rule = store.rules.find((r) => matchesRule(r, message));
  if (!rule) {
    await persist();
    return { message, action: 'ignored' };
  }

  const replyText = fillTemplate(rule.replyTemplate, message);
  message.matchedRuleId = rule.id;

  if (rule.requireApproval) {
    const approval: ApprovalItem = {
      id: crypto.randomUUID(),
      message,
      replyText,
      ruleId: rule.id,
      createdAt: Date.now(),
      status: 'pending',
    };
    store.approvals.unshift(approval);
    await persist();
    return { message, action: 'queued', replyText, approvalId: approval.id };
  }

  const result = await sendSocialMessage({ platform, threadId: message.threadId, text: replyText });
  await persist();
  return {
    message,
    action: result.ok ? 'replied' : 'queued',
    replyText,
    approvalId: result.ok ? undefined : (() => {
      const approval: ApprovalItem = {
        id: crypto.randomUUID(), message, replyText, ruleId: rule.id,
        createdAt: Date.now(), status: 'pending',
      };
      store.approvals.unshift(approval);
      return approval.id;
    })(),
  };
}

// ---------------------------------------------------------------- Polling

/** Pull new Telegram messages and run them through the automation engine. */
export async function pollTelegramInbox(): Promise<{ processed: number; results: unknown[] }> {
  const token = process.env.TELEGRAM_BOT_TOKEN;
  if (!token) return { processed: 0, results: [] };
  const results: unknown[] = [];
  try {
    const r = await fetch(`https://api.telegram.org/bot${token}/getUpdates?offset=${store.telegramOffset}&timeout=1&limit=25`);
    const j = await r.json().catch(() => ({}));
    if (!r.ok || j?.ok === false) return { processed: 0, results: [{ error: j?.description || `HTTP ${r.status}` }] };
    for (const update of j.result || []) {
      store.telegramOffset = Math.max(store.telegramOffset, Number(update.update_id || 0) + 1);
      results.push(await ingestSocialMessage('telegram', update));
    }
    await persist();
  } catch (err) {
    results.push({ error: err instanceof Error ? err.message : String(err) });
  }
  return { processed: results.length, results };
}

// ---------------------------------------------------------------- Store access

export async function listSocialMessages(input: { platform?: SocialPlatform; limit?: number } = {}): Promise<SocialMessage[]> {
  await ensureLoaded();
  const limit = Math.max(1, Math.min(500, input.limit ?? 100));
  const rows = input.platform ? store.messages.filter((m) => m.platform === input.platform) : store.messages;
  return rows.slice(-limit).reverse();
}

export async function listAutomationRules(): Promise<AutomationRule[]> {
  await ensureLoaded();
  return store.rules.slice();
}

export async function upsertAutomationRule(input: Partial<AutomationRule> & { name: string; replyTemplate: string }): Promise<AutomationRule> {
  await ensureLoaded();
  const existing = input.id ? store.rules.find((r) => r.id === input.id) : undefined;
  const rule: AutomationRule = {
    id: existing?.id || crypto.randomUUID(),
    name: input.name,
    platform: input.platform || 'all',
    enabled: input.enabled ?? true,
    matchType: input.matchType || 'contains',
    matchValue: input.matchValue || '',
    replyTemplate: input.replyTemplate,
    requireApproval: input.requireApproval ?? false,
    createdAt: existing?.createdAt || Date.now(),
  };
  if (existing) store.rules[store.rules.indexOf(existing)] = rule;
  else store.rules.push(rule);
  await persist();
  return rule;
}

export async function deleteAutomationRule(id: string): Promise<boolean> {
  await ensureLoaded();
  const idx = store.rules.findIndex((r) => r.id === id);
  if (idx < 0) return false;
  store.rules.splice(idx, 1);
  await persist();
  return true;
}

export async function listApprovals(): Promise<ApprovalItem[]> {
  await ensureLoaded();
  return store.approvals.filter((a) => a.status === 'pending').slice();
}

export async function resolveApproval(input: { id: string; approve: boolean; editedText?: string }): Promise<{ ok: boolean; error?: string; detail?: string }> {
  await ensureLoaded();
  const item = store.approvals.find((a) => a.id === input.id);
  if (!item || item.status !== 'pending') return { ok: false, error: 'Approval not found or already resolved' };
  if (!input.approve) {
    item.status = 'rejected';
    await persist();
    return { ok: true, detail: 'Reply rejected' };
  }
  const text = (input.editedText || item.replyText).trim();
  const result = await sendSocialMessage({ platform: item.message.platform, threadId: item.message.threadId, text });
  item.status = result.ok ? 'approved' : 'pending';
  await persist();
  return result.ok ? { ok: true, detail: 'Approved and delivered' } : { ok: false, error: result.error };
}

export async function getSocialAgentSummary() {
  const [connections, messages, rules, approvals] = await Promise.all([
    getSocialConnections(),
    listSocialMessages({ limit: 8 }),
    listAutomationRules(),
    listApprovals(),
  ]);
  return {
    connections,
    messages,
    rules,
    approvals,
    stats: {
      connectedPlatforms: connections.filter((c) => c.connected).length,
      totalPlatforms: connections.length,
      messagesTracked: messages.length,
      activeRules: rules.filter((r) => r.enabled).length,
      pendingApprovals: approvals.length,
    },
  };
}
