import { executePooledAiText } from '../ai/pooledAiExecutor.ts';
import { runLiveWebSearch } from '../ai/liveWebSearchService.ts';

export type SourceType = 'text' | 'url' | 'youtube' | 'pdf' | 'audio' | 'doc';

export interface NotebookSource {
  id: string;
  title: string;
  type: SourceType;
  content: string;
  uri?: string;
  addedAt: string;
  charCount: number;
}

export interface Notebook {
  id: string;
  title: string;
  sources: NotebookSource[];
  createdAt: string;
  updatedAt: string;
}

export type ArtifactType =
  | 'audio_overview'
  | 'video_overview'
  | 'mind_map'
  | 'briefing_doc'
  | 'study_guide'
  | 'faq'
  | 'timeline'
  | 'toc'
  | 'flashcards'
  | 'quiz'
  | 'infographic'
  | 'slide_deck'
  | 'data_table'
  | 'report'
  | 'blog_post';

export interface NotebookArtifact {
  id: string;
  notebookId: string;
  type: ArtifactType;
  title: string;
  content: unknown;
  createdAt: string;
}

export interface ChatTurn {
  role: 'user' | 'assistant';
  text: string;
  citations?: string[];
  createdAt: string;
}

const notebooksByUser = new Map<string, Map<string, Notebook>>();
const artifactsByNotebook = new Map<string, NotebookArtifact[]>();
const chatHistoryByNotebook = new Map<string, ChatTurn[]>();

function uid(prefix: string) {
  return `${prefix}-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
}

function getUserNotebooks(userKey: string): Map<string, Notebook> {
  if (!notebooksByUser.has(userKey)) notebooksByUser.set(userKey, new Map());
  return notebooksByUser.get(userKey)!;
}

function combinedSourceText(nb: Notebook, maxChars = 18000): string {
  return nb.sources
    .map((s, i) => `### Source ${i + 1}: ${s.title} (${s.type})\n${s.content}`)
    .join('\n\n')
    .slice(0, maxChars);
}

export function createNotebook(userKey: string, title: string): Notebook {
  const nb: Notebook = {
    id: uid('nb'),
    title: title?.trim() || 'Untitled Notebook',
    sources: [],
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };
  getUserNotebooks(userKey).set(nb.id, nb);
  artifactsByNotebook.set(nb.id, []);
  chatHistoryByNotebook.set(nb.id, []);
  return nb;
}

export function listNotebooks(userKey: string): Notebook[] {
  return Array.from(getUserNotebooks(userKey).values()).sort((a, b) => b.updatedAt.localeCompare(a.updatedAt));
}

export function getNotebook(userKey: string, id: string): Notebook | null {
  return getUserNotebooks(userKey).get(id) || null;
}

export function deleteNotebook(userKey: string, id: string): boolean {
  const ok = getUserNotebooks(userKey).delete(id);
  artifactsByNotebook.delete(id);
  chatHistoryByNotebook.delete(id);
  return ok;
}

export async function addSource(
  userKey: string,
  notebookId: string,
  source: { title?: string; type?: SourceType; content?: string; uri?: string }
): Promise<NotebookSource> {
  const nb = getNotebook(userKey, notebookId);
  if (!nb) throw new Error('Notebook not found.');

  let type: SourceType = source.type || 'text';
  let content = (source.content || '').trim();
  let title = (source.title || '').trim();
  const uri = source.uri?.trim();

  if (type === 'url' && uri) {
    try {
      const res = await fetch(uri, { redirect: 'follow' });
      const html = await res.text();
      content = html
        .replace(/<script[\s\S]*?<\/script>/gi, ' ')
        .replace(/<style[\s\S]*?<\/style>/gi, ' ')
        .replace(/<[^>]+>/g, ' ')
        .replace(/\s+/g, ' ')
        .trim()
        .slice(0, 20000);
      if (!title) title = uri;
    } catch (err) {
      throw new Error(`Failed to fetch URL: ${(err as Error)?.message || err}`);
    }
  }

  if (type === 'youtube' && uri) {
    try {
      const res = await fetch(uri, { redirect: 'follow' });
      const html = await res.text();
      const titleMatch = html.match(/<title>(.*?)<\/title>/i);
      if (titleMatch && !title) title = titleMatch[1].replace(' - YouTube', '').trim();
      content = html
        .replace(/<script[\s\S]*?<\/script>/gi, ' ')
        .replace(/<style[\s\S]*?<\/style>/gi, ' ')
        .replace(/<[^>]+>/g, ' ')
        .replace(/\s+/g, ' ')
        .trim()
        .slice(0, 20000);
      if (!content) content = `YouTube source: ${uri}`;
    } catch {
      content = content || `YouTube source: ${uri}`;
    }
    if (!title) title = uri;
  }

  if (!content) throw new Error('Source content is empty.');
  if (!title) title = `${type} source ${nb.sources.length + 1}`;

  const src: NotebookSource = {
    id: uid('src'),
    title,
    type,
    content: content.slice(0, 20000),
    uri,
    addedAt: new Date().toISOString(),
    charCount: content.length,
  };
  nb.sources.push(src);
  nb.updatedAt = new Date().toISOString();
  return src;
}

export function removeSource(userKey: string, notebookId: string, sourceId: string): boolean {
  const nb = getNotebook(userKey, notebookId);
  if (!nb) return false;
  const idx = nb.sources.findIndex((s) => s.id === sourceId);
  if (idx === -1) return false;
  nb.sources.splice(idx, 1);
  nb.updatedAt = new Date().toISOString();
  return true;
}

export async function discoverSources(topic: string, maxResults = 6): Promise<Array<{ title: string; url: string; snippet: string }>> {
  try {
    const r = await runLiveWebSearch(topic, { maxResults });
    return r.hits.map((h) => ({ title: h.title, url: h.uri, snippet: h.snippet }));
  } catch {
    return [];
  }
}

function parseJson<T>(raw: string): T | null {
  if (!raw) return null;
  try {
    const start = raw.indexOf('{');
    const end = raw.lastIndexOf('}');
    if (start !== -1 && end !== -1 && end > start) {
      return JSON.parse(raw.slice(start, end + 1)) as T;
    }
    const aStart = raw.indexOf('[');
    const aEnd = raw.lastIndexOf(']');
    if (aStart !== -1 && aEnd !== -1 && aEnd > aStart) {
      return JSON.parse(raw.slice(aStart, aEnd + 1)) as T;
    }
  } catch {
    return null;
  }
  return null;
}

export async function chatWithNotebook(params: {
  userKey: string;
  notebookId: string;
  question: string;
  allowAutoFailover?: boolean;
}): Promise<{ answer: string; citations: string[]; model: string; activeProviderId: string }> {
  const nb = getNotebook(params.userKey, params.notebookId);
  if (!nb) throw new Error('Notebook not found.');
  if (nb.sources.length === 0) throw new Error('Add at least one source before chatting.');

  const sources = combinedSourceText(nb);
  const history = chatHistoryByNotebook.get(params.notebookId) || [];
  const recent = history.slice(-6).map((t) => `${t.role.toUpperCase()}: ${t.text}`).join('\n');

  const systemInstruction = [
    'You are B.A.R.B.I NotebookLM — a grounded research assistant.',
    'Answer ONLY using the provided sources. If the answer is not in the sources, say so clearly.',
    'Cite sources by their Source number in square brackets, e.g. [Source 1], [Source 2].',
    'Be concise, accurate, and well-structured. Use markdown.',
  ].join(' ');

  const prompt = `SOURCES:\n${sources}\n\nCONVERSATION:\n${recent}\n\nQUESTION: ${params.question}\n\nAnswer with citations.`;

  const aiOut = await executePooledAiText({
    userKey: params.userKey,
    systemInstruction,
    prompt,
    allowAutoFailover: params.allowAutoFailover,
  });

  const answer = aiOut.reply || 'No answer generated.';
  const citations = Array.from(new Set((answer.match(/\[Source \d+\]/g) || []).map((c) => c)));
  const turn: ChatTurn = { role: 'user', text: params.question, createdAt: new Date().toISOString() };
  const reply: ChatTurn = { role: 'assistant', text: answer, citations, createdAt: new Date().toISOString() };
  history.push(turn, reply);
  chatHistoryByNotebook.set(params.notebookId, history);

  return { answer, citations, model: aiOut.model, activeProviderId: aiOut.activeProviderId };
}

export function getChatHistory(userKey: string, notebookId: string): ChatTurn[] {
  if (!getNotebook(userKey, notebookId)) return [];
  return chatHistoryByNotebook.get(notebookId) || [];
}

export function clearChatHistory(userKey: string, notebookId: string): void {
  if (getNotebook(userKey, notebookId)) chatHistoryByNotebook.set(notebookId, []);
}

const ARTIFACT_PROMPTS: Record<ArtifactType, (sources: string, title: string) => { system: string; prompt: string; parse: (raw: string) => unknown }> = {
  audio_overview: (sources, title) => ({
    system: 'You are a podcast script writer for NotebookLM Audio Overview. Produce a two-host (Host A and Host B) conversational podcast script exploring the sources. Return strict JSON: { "title": string, "segments": [ { "speaker": "Host A" | "Host B", "text": string } ], "estimatedMinutes": number }. 12-18 segments, warm and engaging.',
    prompt: `Notebook title: ${title}\n\nSOURCES:\n${sources}\n\nGenerate the Audio Overview podcast script.`,
    parse: (raw) => parseJson(raw),
  }),
  video_overview: (sources, title) => ({
    system: 'You are a high-quality explainer video director (NotebookLM Video Overview). Produce a cinematic, well-paced explainer with 6-8 scenes. Return strict JSON: { "title": string, "style": string, "scenes": [ { "sceneIndex": number, "title": string, "visualType": "concept_map"|"equation"|"flowchart"|"comparison"|"summary"|"title_card", "keyBullets": string[], "highlightFormula": string, "narrationText": string, "durationSec": number, "transition": "fade"|"slide"|"zoom", "visualPrompt": string } ] }. Each scene narration 1-2 sentences, duration 5-9s. visualPrompt describes the on-screen graphic.',
    prompt: `Notebook title: ${title}\n\nSOURCES:\n${sources}\n\nGenerate a high-quality explainer video overview.`,
    parse: (raw) => parseJson(raw),
  }),
  mind_map: (sources, title) => ({
    system: 'You are a mind-map generator. Return strict JSON: { "title": string, "nodes": [ { "id": string, "label": string, "group": string } ], "edges": [ { "from": string, "to": string } ] }. 12-20 nodes, meaningful connections.',
    prompt: `Notebook title: ${title}\n\nSOURCES:\n${sources}\n\nGenerate a mind map of key concepts and relationships.`,
    parse: (raw) => parseJson(raw),
  }),
  briefing_doc: (sources, title) => ({
    system: 'You are a briefing document writer. Produce a concise executive briefing document in markdown with sections: Overview, Key Points, Implications, Open Questions. Grounded in sources.',
    prompt: `Notebook title: ${title}\n\nSOURCES:\n${sources}\n\nWrite the Briefing Doc.`,
    parse: (raw) => ({ markdown: raw }),
  }),
  study_guide: (sources, title) => ({
    system: 'You are a study guide creator. Return strict JSON: { "title": string, "executiveSummary": string, "keyConcepts": [ { "term": string, "explanation": string, "equation": string } ], "flashcards": [ { "front": string, "back": string } ], "quiz": [ { "question": string, "options": string[], "answerIndex": number, "explanation": string } ], "explainerScenes": [ { "sceneIndex": number, "title": string, "visualType": string, "keyBullets": string[], "narrationText": string, "durationSec": number } ] }.',
    prompt: `Notebook title: ${title}\n\nSOURCES:\n${sources}\n\nGenerate a comprehensive study guide.`,
    parse: (raw) => parseJson(raw),
  }),
  faq: (sources, title) => ({
    system: 'You are an FAQ generator. Return strict JSON: { "title": string, "faqs": [ { "question": string, "answer": string } ] }. 8-12 Q&A pairs grounded in sources.',
    prompt: `Notebook title: ${title}\n\nSOURCES:\n${sources}\n\nGenerate an FAQ from the sources.`,
    parse: (raw) => parseJson(raw),
  }),
  timeline: (sources, title) => ({
    system: 'You are a timeline extractor. Return strict JSON: { "title": string, "events": [ { "date": string, "title": string, "description": string } ] }. Chronological order.',
    prompt: `Notebook title: ${title}\n\nSOURCES:\n${sources}\n\nExtract a timeline of key events/dates.`,
    parse: (raw) => parseJson(raw),
  }),
  toc: (sources, title) => ({
    system: 'You are a table-of-contents generator. Return strict JSON: { "title": string, "sections": [ { "heading": string, "subsections": string[] } ] }.',
    prompt: `Notebook title: ${title}\n\nSOURCES:\n${sources}\n\nGenerate a table of contents / outline.`,
    parse: (raw) => parseJson(raw),
  }),
  flashcards: (sources, title) => ({
    system: 'You are a flashcard generator. Return strict JSON: { "title": string, "cards": [ { "front": string, "back": string } ] }. 10-15 cards.',
    prompt: `Notebook title: ${title}\n\nSOURCES:\n${sources}\n\nGenerate flashcards.`,
    parse: (raw) => parseJson(raw),
  }),
  quiz: (sources, title) => ({
    system: 'You are a quiz generator. Return strict JSON: { "title": string, "questions": [ { "question": string, "options": string[], "answerIndex": number, "explanation": string } ] }. 5-8 MCQs, 4 options each.',
    prompt: `Notebook title: ${title}\n\nSOURCES:\n${sources}\n\nGenerate a quiz.`,
    parse: (raw) => parseJson(raw),
  }),
  infographic: (sources, title) => ({
    system: 'You are an infographic outline generator. Return strict JSON: { "title": string, "sections": [ { "heading": string, "stat": string, "description": string } ] }. 5-7 sections with key stats.',
    prompt: `Notebook title: ${title}\n\nSOURCES:\n${sources}\n\nGenerate an infographic outline.`,
    parse: (raw) => parseJson(raw),
  }),
  slide_deck: (sources, title) => ({
    system: 'You are a slide deck generator. Return strict JSON: { "title": string, "slides": [ { "title": string, "bullets": string[] } ] }. 8-12 slides.',
    prompt: `Notebook title: ${title}\n\nSOURCES:\n${sources}\n\nGenerate a slide deck outline.`,
    parse: (raw) => parseJson(raw),
  }),
  data_table: (sources, title) => ({
    system: 'You are a data table extractor. Return strict JSON: { "title": string, "columns": string[], "rows": string[][] }. Extract structured data from sources.',
    prompt: `Notebook title: ${title}\n\nSOURCES:\n${sources}\n\nExtract a data table from the sources.`,
    parse: (raw) => parseJson(raw),
  }),
  report: (sources, title) => ({
    system: 'You are a research report writer. Produce a comprehensive report in markdown with sections: Executive Summary, Background, Methodology/Approach, Findings, Analysis, Conclusions, Recommendations. Grounded in sources.',
    prompt: `Notebook title: ${title}\n\nSOURCES:\n${sources}\n\nWrite the full research report.`,
    parse: (raw) => ({ markdown: raw }),
  }),
  blog_post: (sources, title) => ({
    system: 'You are a blog post writer. Produce an engaging, well-structured blog post in markdown with a catchy title, intro, body sections, and conclusion. Grounded in sources.',
    prompt: `Notebook title: ${title}\n\nSOURCES:\n${sources}\n\nWrite the blog post.`,
    parse: (raw) => ({ markdown: raw }),
  }),
};

export async function generateArtifact(params: {
  userKey: string;
  notebookId: string;
  type: ArtifactType;
  allowAutoFailover?: boolean;
}): Promise<NotebookArtifact> {
  const nb = getNotebook(params.userKey, params.notebookId);
  if (!nb) throw new Error('Notebook not found.');
  if (nb.sources.length === 0) throw new Error('Add at least one source before generating.');

  const sources = combinedSourceText(nb);
  const spec = ARTIFACT_PROMPTS[params.type];
  if (!spec) throw new Error(`Unknown artifact type: ${params.type}`);

  const { system, prompt, parse } = spec(sources, nb.title);
  const aiOut = await executePooledAiText({
    userKey: params.userKey,
    systemInstruction: system,
    prompt,
    allowAutoFailover: params.allowAutoFailover,
  });

  let content: unknown = aiOut.reply || '';
  if (aiOut.reply) {
    const parsed = parse(aiOut.reply);
    if (parsed) content = parsed;
  }

  const artifact: NotebookArtifact = {
    id: uid('art'),
    notebookId: params.notebookId,
    type: params.type,
    title: `${params.type.replace(/_/g, ' ')} — ${nb.title}`,
    content,
    createdAt: new Date().toISOString(),
  };
  const list = artifactsByNotebook.get(params.notebookId) || [];
  list.unshift(artifact);
  artifactsByNotebook.set(params.notebookId, list);
  return artifact;
}

export function listArtifacts(userKey: string, notebookId: string): NotebookArtifact[] {
  if (!getNotebook(userKey, notebookId)) return [];
  return artifactsByNotebook.get(notebookId) || [];
}

export function getArtifact(userKey: string, notebookId: string, artifactId: string): NotebookArtifact | null {
  if (!getNotebook(userKey, notebookId)) return null;
  return (artifactsByNotebook.get(notebookId) || []).find((a) => a.id === artifactId) || null;
}

export function deleteArtifact(userKey: string, notebookId: string, artifactId: string): boolean {
  if (!getNotebook(userKey, notebookId)) return false;
  const list = artifactsByNotebook.get(notebookId) || [];
  const idx = list.findIndex((a) => a.id === artifactId);
  if (idx === -1) return false;
  list.splice(idx, 1);
  return true;
}

// ---------- Notes ----------
export interface NotebookNote {
  id: string;
  notebookId: string;
  title: string;
  content: string;
  source: 'user' | 'chat' | 'artifact';
  createdAt: string;
  updatedAt: string;
}

const notesByNotebook = new Map<string, NotebookNote[]>();

export function createNote(userKey: string, notebookId: string, note: { title?: string; content: string; source?: NotebookNote['source'] }): NotebookNote {
  if (!getNotebook(userKey, notebookId)) throw new Error('Notebook not found.');
  const n: NotebookNote = {
    id: uid('note'),
    notebookId,
    title: note.title?.trim() || 'Untitled Note',
    content: note.content,
    source: note.source || 'user',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };
  const list = notesByNotebook.get(notebookId) || [];
  list.unshift(n);
  notesByNotebook.set(notebookId, list);
  return n;
}

export function listNotes(userKey: string, notebookId: string): NotebookNote[] {
  if (!getNotebook(userKey, notebookId)) return [];
  return notesByNotebook.get(notebookId) || [];
}

export function updateNote(userKey: string, notebookId: string, noteId: string, patch: { title?: string; content?: string }): NotebookNote | null {
  if (!getNotebook(userKey, notebookId)) return null;
  const list = notesByNotebook.get(notebookId) || [];
  const n = list.find((x) => x.id === noteId);
  if (!n) return null;
  if (patch.title !== undefined) n.title = patch.title;
  if (patch.content !== undefined) n.content = patch.content;
  n.updatedAt = new Date().toISOString();
  return n;
}

export function deleteNote(userKey: string, notebookId: string, noteId: string): boolean {
  if (!getNotebook(userKey, notebookId)) return false;
  const list = notesByNotebook.get(notebookId) || [];
  const idx = list.findIndex((x) => x.id === noteId);
  if (idx === -1) return false;
  list.splice(idx, 1);
  return true;
}

export async function noteToSource(userKey: string, notebookId: string, noteId: string): Promise<NotebookSource | null> {
  const note = (notesByNotebook.get(notebookId) || []).find((n) => n.id === noteId);
  if (!note || !getNotebook(userKey, notebookId)) return null;
  return addSource(userKey, notebookId, { title: note.title, type: 'text', content: note.content });
}

// ---------- Deep Research ----------
export async function deepResearch(params: {
  userKey: string;
  notebookId?: string;
  topic: string;
  maxSources?: number;
  allowAutoFailover?: boolean;
}): Promise<{ report: unknown; sources: Array<{ title: string; url: string; snippet: string }>; importedNotebookId?: string }> {
  const maxSources = Math.max(3, Math.min(12, params.maxSources || 6));
  const searchResults = await discoverSources(params.topic, maxSources);

  const fetched: Array<{ title: string; url: string; snippet: string; content: string }> = [];
  for (const r of searchResults) {
    let content = r.snippet;
    try {
      const res = await fetch(r.url, { redirect: 'follow' });
      const html = await res.text();
      content = html
        .replace(/<script[\s\S]*?<\/script>/gi, ' ')
        .replace(/<style[\s\S]*?<\/style>/gi, ' ')
        .replace(/<[^>]+>/g, ' ')
        .replace(/\s+/g, ' ')
        .trim()
        .slice(0, 6000);
      if (!content) content = r.snippet;
    } catch {
      // keep snippet
    }
    fetched.push({ ...r, content });
  }

  const sourcesText = fetched
    .map((s, i) => `### Source ${i + 1}: ${s.title} (${s.url})\n${s.content || s.snippet}`)
    .join('\n\n')
    .slice(0, 18000);

  const systemInstruction = [
    'You are B.A.R.B.I Deep Research — a multi-step research analyst.',
    'Synthesize the provided web sources into a comprehensive research report.',
    'Return strict JSON: { "title": string, "executiveSummary": string, "keyFindings": string[], "detailedAnalysis": string, "sourceNotes": [ { "sourceIndex": number, "takeaway": string } ], "openQuestions": string[], "recommendations": string[] }.',
    'Ground every claim in the sources and cite source indices.',
  ].join(' ');

  const prompt = `Research topic: ${params.topic}\n\nSOURCES:\n${sourcesText}\n\nProduce the deep research report.`;

  const aiOut = await executePooledAiText({
    userKey: params.userKey,
    systemInstruction,
    prompt,
    allowAutoFailover: params.allowAutoFailover,
  });

  let report: unknown = aiOut.reply || '';
  const parsed = parseJson(aiOut.reply || '');
  if (parsed) report = parsed;

  let importedNotebookId: string | undefined;
  if (params.notebookId) {
    const nb = getNotebook(params.userKey, params.notebookId);
    if (nb) {
      for (const s of fetched) {
        try {
          await addSource(params.userKey, params.notebookId, {
            title: s.title,
            type: 'url',
            uri: s.url,
            content: s.content,
          });
        } catch {
          // ignore duplicates/errors
        }
      }
      importedNotebookId = params.notebookId;
    }
  }

  return {
    report,
    sources: fetched.map((s) => ({ title: s.title, url: s.url, snippet: s.snippet })),
    importedNotebookId,
  };
}

// ---------- Chat modes ----------
export type ChatMode = 'default' | 'learning_guide' | 'brief' | 'detailed';

export async function chatWithNotebookMode(params: {
  userKey: string;
  notebookId: string;
  question: string;
  mode?: ChatMode;
  allowAutoFailover?: boolean;
}): Promise<{ answer: string; citations: string[]; suggestedFollowUps: string[]; model: string; activeProviderId: string }> {
  const base = await chatWithNotebook({
    userKey: params.userKey,
    notebookId: params.notebookId,
    question: params.question,
    allowAutoFailover: params.allowAutoFailover,
  });

  const nb = getNotebook(params.userKey, params.notebookId);
  const sources = nb ? combinedSourceText(nb).slice(0, 6000) : '';
  let suggestedFollowUps: string[] = [];
  try {
    const aiOut = await executePooledAiText({
      userKey: params.userKey,
      systemInstruction: 'Generate 3 concise follow-up questions a curious learner might ask next, based on the sources and the Q&A. Return strict JSON: { "questions": string[] }.',
      prompt: `SOURCES:\n${sources}\n\nQ: ${params.question}\nA: ${base.answer}\n\nGenerate follow-up questions.`,
      allowAutoFailover: params.allowAutoFailover,
    });
    const p = parseJson<{ questions?: string[] }>(aiOut.reply || '');
    if (p?.questions) suggestedFollowUps = p.questions.slice(0, 3);
  } catch {
    suggestedFollowUps = [];
  }

  return { ...base, suggestedFollowUps };
}

// ---------- Notebook summary / auto-title ----------
export async function summarizeNotebook(params: {
  userKey: string;
  notebookId: string;
  allowAutoFailover?: boolean;
}): Promise<{ title: string; summary: string; keyTopics: string[] }> {
  const nb = getNotebook(params.userKey, params.notebookId);
  if (!nb) throw new Error('Notebook not found.');
  if (nb.sources.length === 0) throw new Error('Add at least one source first.');

  const sources = combinedSourceText(nb);
  const aiOut = await executePooledAiText({
    userKey: params.userKey,
    systemInstruction: 'You are a notebook summarizer. Return strict JSON: { "title": string, "summary": string, "keyTopics": string[] }.',
    prompt: `SOURCES:\n${sources}\n\nSummarize this notebook: propose a concise title, a 2-3 sentence summary, and 5-8 key topics.`,
    allowAutoFailover: params.allowAutoFailover,
  });
  const parsed = parseJson<{ title?: string; summary?: string; keyTopics?: string[] }>(aiOut.reply || '');
  return {
    title: parsed?.title || nb.title,
    summary: parsed?.summary || '',
    keyTopics: parsed?.keyTopics || [],
  };
}

// ---------- Export notebook as markdown ----------
export function exportNotebookMarkdown(userKey: string, notebookId: string): string {
  const nb = getNotebook(userKey, notebookId);
  if (!nb) return '';
  const lines: string[] = [];
  lines.push(`# ${nb.title}`);
  lines.push('');
  lines.push(`_Created: ${nb.createdAt}_`);
  lines.push('');
  lines.push('## Sources');
  lines.push('');
  nb.sources.forEach((s, i) => {
    lines.push(`### Source ${i + 1}: ${s.title}`);
    lines.push(`- Type: ${s.type}`);
    if (s.uri) lines.push(`- URI: ${s.uri}`);
    lines.push('');
    lines.push(s.content.slice(0, 2000));
    lines.push('');
  });
  const arts = artifactsByNotebook.get(notebookId) || [];
  if (arts.length > 0) {
    lines.push('## Generated Artifacts');
    lines.push('');
    arts.forEach((a) => {
      lines.push(`### ${a.type}: ${a.title}`);
      lines.push('```json');
      lines.push(JSON.stringify(a.content, null, 2).slice(0, 4000));
      lines.push('```');
      lines.push('');
    });
  }
  const notes = notesByNotebook.get(notebookId) || [];
  if (notes.length > 0) {
    lines.push('## Notes');
    lines.push('');
    notes.forEach((n) => {
      lines.push(`### ${n.title}`);
      lines.push(n.content);
      lines.push('');
    });
  }
  return lines.join('\n');
}

// ---------- Artifact customization wrapper ----------
export async function generateArtifactCustom(params: {
  userKey: string;
  notebookId: string;
  type: ArtifactType;
  instructions?: string;
  allowAutoFailover?: boolean;
}): Promise<NotebookArtifact> {
  const nb = getNotebook(params.userKey, params.notebookId);
  if (!nb) throw new Error('Notebook not found.');
  if (nb.sources.length === 0) throw new Error('Add at least one source before generating.');

  const sources = combinedSourceText(nb);
  const spec = ARTIFACT_PROMPTS[params.type];
  if (!spec) throw new Error(`Unknown artifact type: ${params.type}`);

  const { system, prompt, parse } = spec(sources, nb.title);
  const extra = params.instructions ? `\n\nADDITIONAL INSTRUCTIONS: ${params.instructions}` : '';
  const aiOut = await executePooledAiText({
    userKey: params.userKey,
    systemInstruction: system,
    prompt: prompt + extra,
    allowAutoFailover: params.allowAutoFailover,
  });

  let content: unknown = aiOut.reply || '';
  if (aiOut.reply) {
    const parsed = parse(aiOut.reply);
    if (parsed) content = parsed;
  }

  const artifact: NotebookArtifact = {
    id: uid('art'),
    notebookId: params.notebookId,
    type: params.type,
    title: `${params.type.replace(/_/g, ' ')} — ${nb.title}`,
    content,
    createdAt: new Date().toISOString(),
  };
  const list = artifactsByNotebook.get(params.notebookId) || [];
  list.unshift(artifact);
  artifactsByNotebook.set(params.notebookId, list);
  return artifact;
}

export const ARTIFACT_TYPES: ArtifactType[] = Object.keys(ARTIFACT_PROMPTS) as ArtifactType[];
