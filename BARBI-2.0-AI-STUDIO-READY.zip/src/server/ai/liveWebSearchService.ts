import {
  formatSourceHost,
  sanitizeExternalHttpUrl,
  type ChatGroundingMetadata,
  type ChatGroundingSource,
} from '../../chat/chatLogic.ts';

export interface LiveWebSearchHit {
  title: string;
  uri: string;
  domain: string;
  snippet: string;
  publishedAt?: string;
  provider: 'google-news' | 'mdn' | 'npm' | 'nodejs-dist' | 'wikipedia' | 'hackernews';
}

export interface LiveWebSearchResult {
  query: string;
  searchedAtIso: string;
  hits: LiveWebSearchHit[];
  grounding: ChatGroundingMetadata;
  contextText: string;
}

const FETCH_TIMEOUT_MS = 4500;
const USER_AGENT = 'BARBI-OS/4.0 (+https://zulutronix.local)';

function decodeXmlEntities(input: string): string {
  return String(input || '')
    .replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, '$1')
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&#39;|&apos;/g, "'")
    .replace(/<[^>]+>/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function cleanSearchQuery(rawPrompt: string): string {
  const cleaned = String(rawPrompt || '')
    .replace(/[\r\n]+/g, ' ')
    .replace(/\b(please|can you|could you|tell me|what is|what are|right now|according to|explain|hey barbi|barbi)\b/gi, ' ')
    .replace(/[?!.,;:"()[\]{}]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
  if (cleaned.length >= 3) return cleaned.slice(0, 120);
  return String(rawPrompt || '').replace(/\s+/g, ' ').trim().slice(0, 120);
}

async function fetchWithTimeout(url: string): Promise<Response | null> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), FETCH_TIMEOUT_MS);
  try {
    const res = await fetch(url, {
      headers: {
        'User-Agent': USER_AGENT,
        Accept: 'application/json, application/rss+xml, application/xml, text/xml, */*',
      },
      signal: controller.signal,
    });
    if (!res.ok) return null;
    return res;
  } catch {
    return null;
  } finally {
    clearTimeout(timer);
  }
}

async function searchGoogleNewsRss(query: string, limit = 4): Promise<LiveWebSearchHit[]> {
  const url = `https://news.google.com/rss/search?q=${encodeURIComponent(query)}&hl=en-US&gl=US&ceid=US:en`;
  const res = await fetchWithTimeout(url);
  if (!res) return [];
  const xml = await res.text();
  const hits: LiveWebSearchHit[] = [];
  const itemRegex = /<item>([\s\S]*?)<\/item>/gi;
  let match: RegExpExecArray | null;
  while ((match = itemRegex.exec(xml)) !== null && hits.length < limit) {
    const block = match[1];
    const titleRaw = block.match(/<title>([\s\S]*?)<\/title>/i)?.[1] || '';
    const linkRaw = block.match(/<link>([\s\S]*?)<\/link>/i)?.[1] || '';
    const pubDateRaw = block.match(/<pubDate>([\s\S]*?)<\/pubDate>/i)?.[1] || '';
    const sourceRaw = block.match(/<source[^>]*>([\s\S]*?)<\/source>/i)?.[1] || '';
    const sourceUrl = block.match(/<source[^>]*url="([^"]+)"/i)?.[1] || '';

    const safeUri = sanitizeExternalHttpUrl(decodeXmlEntities(linkRaw));
    if (!safeUri) continue;
    const title = decodeXmlEntities(titleRaw);
    const sourceName = decodeXmlEntities(sourceRaw);
    const domain = sourceUrl ? formatSourceHost(sourceUrl, sourceName) : formatSourceHost(safeUri, sourceName || title);
    const publishedAt = decodeXmlEntities(pubDateRaw);

    hits.push({
      title: title || domain,
      uri: safeUri,
      domain,
      snippet: `${sourceName ? `[${sourceName}] ` : ''}${title}${publishedAt ? ` (${publishedAt})` : ''}`,
      publishedAt,
      provider: 'google-news',
    });
  }
  return hits;
}

async function searchWikipedia(query: string, limit = 3): Promise<LiveWebSearchHit[]> {
  const url = `https://en.wikipedia.org/w/api.php?action=query&list=search&srsearch=${encodeURIComponent(query)}&format=json&srlimit=${limit}`;
  const res = await fetchWithTimeout(url);
  if (!res) return [];
  const json = (await res.json()) as {
    query?: { search?: Array<{ title?: string; snippet?: string; timestamp?: string }> };
  };
  const items = json?.query?.search || [];
  return items
    .map((item): LiveWebSearchHit | null => {
      const title = String(item.title || '').trim();
      if (!title) return null;
      const uri = `https://en.wikipedia.org/wiki/${encodeURIComponent(title.replace(/\s+/g, '_'))}`;
      return {
        title: `${title} — Wikipedia`,
        uri,
        domain: 'en.wikipedia.org',
        snippet: decodeXmlEntities(String(item.snippet || '')),
        publishedAt: item.timestamp,
        provider: 'wikipedia',
      };
    })
    .filter((h): h is LiveWebSearchHit => Boolean(h));
}

async function searchMdnDocs(query: string, limit = 3): Promise<LiveWebSearchHit[]> {
  const url = `https://developer.mozilla.org/api/v1/search?q=${encodeURIComponent(query)}&size=${limit}`;
  const res = await fetchWithTimeout(url);
  if (!res) return [];
  const json = (await res.json()) as {
    documents?: Array<{ mdn_url?: string; title?: string; summary?: string }>;
  };
  return (json?.documents || [])
    .slice(0, limit)
    .map((doc): LiveWebSearchHit | null => {
      if (!doc.mdn_url || !doc.title) return null;
      const uri = `https://developer.mozilla.org${doc.mdn_url}`;
      return {
        title: `${doc.title} — MDN Web Docs`,
        uri,
        domain: 'developer.mozilla.org',
        snippet: decodeXmlEntities(doc.summary || doc.title),
        provider: 'mdn',
      };
    })
    .filter((h): h is LiveWebSearchHit => Boolean(h));
}

async function searchNpmRegistry(query: string, limit = 3): Promise<LiveWebSearchHit[]> {
  const url = `https://registry.npmjs.org/-/v1/search?text=${encodeURIComponent(query)}&size=${limit}`;
  const res = await fetchWithTimeout(url);
  if (!res) return [];
  const json = (await res.json()) as {
    objects?: Array<{
      package?: {
        name?: string;
        version?: string;
        description?: string;
        date?: string;
        links?: { homepage?: string; npm?: string; repository?: string };
      };
    }>;
  };
  return (json?.objects || [])
    .slice(0, limit)
    .map((entry): LiveWebSearchHit | null => {
      const pkg = entry.package;
      if (!pkg?.name || !pkg?.version) return null;
      const rawUri = pkg.links?.homepage || pkg.links?.npm || `https://www.npmjs.com/package/${encodeURIComponent(pkg.name)}`;
      const safeUri = sanitizeExternalHttpUrl(rawUri);
      if (!safeUri) return null;
      return {
        title: `${pkg.name} v${pkg.version} (npm)`,
        uri: safeUri,
        domain: formatSourceHost(safeUri, pkg.name),
        snippet: `${pkg.name} latest version ${pkg.version}${pkg.date ? ` (published ${pkg.date.slice(0, 10)})` : ''}: ${pkg.description || ''}`.trim(),
        publishedAt: pkg.date,
        provider: 'npm',
      };
    })
    .filter((h): h is LiveWebSearchHit => Boolean(h));
}

async function searchNodeJsReleasesIfRelevant(rawQuery: string): Promise<LiveWebSearchHit[]> {
  if (!/\bnode(?:\.js|js)?\b/i.test(rawQuery)) return [];
  const res = await fetchWithTimeout('https://nodejs.org/dist/index.json');
  if (!res) return [];
  const rows = (await res.json()) as Array<{ version?: string; date?: string; lts?: string | false }>;
  if (!Array.isArray(rows) || rows.length === 0) return [];
  const latestStable = rows.find((r) => r.version && !/alpha|beta|rc/i.test(r.version));
  const latestLts = rows.find((r) => r.version && typeof r.lts === 'string' && r.lts.length > 0);
  const parts: string[] = [];
  if (latestLts) parts.push(`Latest LTS: ${latestLts.version} ("${latestLts.lts}", released ${latestLts.date})`);
  if (latestStable) parts.push(`Latest Current: ${latestStable.version} (released ${latestStable.date})`);
  if (parts.length === 0) return [];
  return [
    {
      title: 'Node.js Official Releases Index',
      uri: 'https://nodejs.org/en/about/previous-releases',
      domain: 'nodejs.org',
      snippet: parts.join(' · '),
      publishedAt: latestLts?.date || latestStable?.date,
      provider: 'nodejs-dist',
    },
  ];
}

async function searchHackerNews(query: string, limit = 3): Promise<LiveWebSearchHit[]> {
  const url = `https://hn.algolia.com/api/v1/search?query=${encodeURIComponent(query)}&tags=story&hitsPerPage=${limit}`;
  const res = await fetchWithTimeout(url);
  if (!res) return [];
  const json = (await res.json()) as {
    hits?: Array<{ title?: string; url?: string; objectID?: string; created_at?: string; points?: number }>;
  };
  return (json?.hits || [])
    .slice(0, limit)
    .map((hit): LiveWebSearchHit | null => {
      const safeUri = sanitizeExternalHttpUrl(hit.url || (hit.objectID ? `https://news.ycombinator.com/item?id=${hit.objectID}` : ''));
      if (!safeUri || !hit.title) return null;
      return {
        title: hit.title,
        uri: safeUri,
        domain: formatSourceHost(safeUri, hit.title),
        snippet: `${hit.title}${hit.created_at ? ` (${hit.created_at.slice(0, 10)})` : ''}`,
        publishedAt: hit.created_at,
        provider: 'hackernews',
      };
    })
    .filter((h): h is LiveWebSearchHit => Boolean(h));
}

export async function runLiveWebSearch(
  rawPrompt: string,
  options?: { maxResults?: number }
): Promise<LiveWebSearchResult> {
  const query = cleanSearchQuery(rawPrompt);
  const searchedAtIso = new Date().toISOString();
  const maxResults = Math.min(Math.max(options?.maxResults ?? 8, 3), 12);

  const isTechQuery =
    /\b(api|docs|documentation|version|release|lts|typescript|javascript|node|react|vite|python|rust|css|html|browser|web|sdk|library|framework|npm|github|ai|gemini|model|cuda|esp32|firmware)\b/i.test(
      rawPrompt
    );

  const settled = await Promise.allSettled([
    searchNodeJsReleasesIfRelevant(rawPrompt),
    searchGoogleNewsRss(query, 4),
    ...(isTechQuery ? [searchMdnDocs(query, 3), searchNpmRegistry(query, 3), searchHackerNews(query, 2)] : []),
    searchWikipedia(query, 2),
  ]);

  const allHits: LiveWebSearchHit[] = [];
  const seenUris = new Set<string>();

  for (const res of settled) {
    if (res.status !== 'fulfilled') continue;
    for (const hit of res.value) {
      if (seenUris.has(hit.uri)) continue;
      seenUris.add(hit.uri);
      allHits.push(hit);
      if (allHits.length >= maxResults) break;
    }
    if (allHits.length >= maxResults) break;
  }

  const sources: ChatGroundingSource[] = allHits.map((h) => ({
    title: h.title.slice(0, 140),
    uri: h.uri,
    domain: h.domain,
  }));

  const contextLines = allHits.map(
    (hit, idx) =>
      `[${idx + 1}] ${hit.title} (${hit.domain})${hit.publishedAt ? ` [${hit.publishedAt}]` : ''}\nURL: ${hit.uri}\nSummary: ${hit.snippet}`
  );

  return {
    query,
    searchedAtIso,
    hits: allHits,
    grounding: {
      webSearchQueries: [query],
      sources,
    },
    contextText:
      allHits.length > 0
        ? `[Live Web Search Results retrieved at ${searchedAtIso} for query "${query}"]\n${contextLines.join('\n\n')}`
        : '',
  };
}
