/**
 * B.A.R.B.I Social Agent REST + webhook routes.
 * Mounted at /api/social in routes/api.ts.
 *
 * Webhook endpoints (no browser auth — verified by provider secret where the
 * provider supports it):
 *   POST /api/social/webhook/whatsapp   (WAHA)
 *   POST /api/social/webhook/telegram   (Telegram setWebhook)
 *   POST /api/social/webhook/instagram  (Meta Graph)
 *   POST /api/social/webhook/tiktok     (TikTok Business Messaging)
 */
import { Router, type Response } from 'express';
import { z } from 'zod';
import crypto from 'node:crypto';
import { optionalAuth, type AuthRequest } from '../../middleware/auth.ts';
import {
  deleteAutomationRule,
  getSocialAgentSummary,
  ingestSocialMessage,
  listApprovals,
  listAutomationRules,
  listSocialMessages,
  pollTelegramInbox,
  resolveApproval,
  sendSocialMessage,
  upsertAutomationRule,
  type SocialPlatform,
} from '../social/socialAgentService.ts';

export const socialRouter = Router();

function fail(res: Response, status: number, message: string, details?: unknown) {
  return res.status(status).json({ error: message, ...(details ? { details } : {}) });
}

const PLATFORMS: SocialPlatform[] = ['whatsapp', 'telegram', 'instagram', 'tiktok'];

function isPlatform(value: string): value is SocialPlatform {
  return PLATFORMS.includes(value as SocialPlatform);
}

// ------------------------------------------------------------------ Dashboard
socialRouter.get('/summary', optionalAuth, async (_req: AuthRequest, res) => {
  try {
    return res.json(await getSocialAgentSummary());
  } catch (err) {
    return fail(res, 500, 'Failed to load social agent summary.', (err as Error)?.message);
  }
});

socialRouter.get('/messages', optionalAuth, async (req: AuthRequest, res) => {
  try {
    const platform = typeof req.query.platform === 'string' ? req.query.platform : undefined;
    const limit = typeof req.query.limit === 'string' ? Number(req.query.limit) : 100;
    if (platform && !isPlatform(platform)) return fail(res, 400, 'Unknown platform.');
    return res.json({ messages: await listSocialMessages({ platform, limit }) });
  } catch (err) {
    return fail(res, 500, 'Failed to list messages.', (err as Error)?.message);
  }
});

// ------------------------------------------------------------------ Send
const sendSchema = z.object({
  platform: z.enum(['whatsapp', 'telegram', 'instagram', 'tiktok']),
  threadId: z.string().min(1).max(200),
  text: z.string().min(1).max(4000),
});

socialRouter.post('/send', optionalAuth, async (req: AuthRequest, res) => {
  const parsed = sendSchema.safeParse(req.body);
  if (!parsed.success) return fail(res, 400, 'Invalid send payload.', parsed.error.flatten());
  try {
    const result = await sendSocialMessage(parsed.data);
    return res.status(result.ok ? 200 : 502).json(result);
  } catch (err) {
    return fail(res, 500, 'Send failed.', (err as Error)?.message);
  }
});

// ------------------------------------------------------------------ Rules
socialRouter.get('/rules', optionalAuth, async (_req: AuthRequest, res) => {
  return res.json({ rules: await listAutomationRules() });
});

const ruleSchema = z.object({
  id: z.string().optional(),
  name: z.string().min(1).max(120),
  platform: z.enum(['whatsapp', 'telegram', 'instagram', 'tiktok', 'all']).optional(),
  enabled: z.boolean().optional(),
  matchType: z.enum(['contains', 'regex', 'all']).optional(),
  matchValue: z.string().max(500).optional(),
  replyTemplate: z.string().min(1).max(2000),
  requireApproval: z.boolean().optional(),
});

socialRouter.post('/rules', optionalAuth, async (req: AuthRequest, res) => {
  const parsed = ruleSchema.safeParse(req.body);
  if (!parsed.success) return fail(res, 400, 'Invalid rule payload.', parsed.error.flatten());
  return res.json({ rule: await upsertAutomationRule(parsed.data) });
});

socialRouter.put('/rules/:id', optionalAuth, async (req: AuthRequest, res) => {
  const parsed = ruleSchema.safeParse({ ...req.body, id: req.params.id });
  if (!parsed.success) return fail(res, 400, 'Invalid rule payload.', parsed.error.flatten());
  return res.json({ rule: await upsertAutomationRule(parsed.data) });
});

socialRouter.delete('/rules/:id', optionalAuth, async (req: AuthRequest, res) => {
  const ok = await deleteAutomationRule(req.params.id);
  return res.json({ ok });
});

// ------------------------------------------------------------------ Approvals
socialRouter.get('/approvals', optionalAuth, async (_req: AuthRequest, res) => {
  return res.json({ approvals: await listApprovals() });
});

const approvalSchema = z.object({
  approve: z.boolean(),
  editedText: z.string().max(4000).optional(),
});

socialRouter.post('/approvals/:id/resolve', optionalAuth, async (req: AuthRequest, res) => {
  const parsed = approvalSchema.safeParse(req.body);
  if (!parsed.success) return fail(res, 400, 'Invalid approval payload.', parsed.error.flatten());
  const result = await resolveApproval({ id: req.params.id, ...parsed.data });
  return res.status(result.ok ? 200 : 502).json(result);
});

// ------------------------------------------------------------------ Polling
socialRouter.post('/poll/telegram', optionalAuth, async (_req: AuthRequest, res) => {
  try {
    return res.json(await pollTelegramInbox());
  } catch (err) {
    return fail(res, 500, 'Telegram poll failed.', (err as Error)?.message);
  }
});

// ------------------------------------------------------------------ Webhooks
/**
 * Constant-time secret check shared across providers. Set the matching env var
 * to require a secret; when unset, the webhook accepts traffic (works with
 * local tunnels / WAHA without a webhook secret).
 */
function webhookAuthorized(platform: SocialPlatform, req: AuthRequest, res: Response): boolean {
  const secrets: Record<SocialPlatform, string | undefined> = {
    whatsapp: process.env.WAHA_WEBHOOK_SECRET,
    telegram: process.env.TELEGRAM_WEBHOOK_SECRET,
    instagram: process.env.IG_WEBHOOK_SECRET,
    tiktok: process.env.TIKTOK_WEBHOOK_SECRET,
  };
  const expected = secrets[platform];
  if (!expected) return true;

  const supplied =
    (req.headers['x-webhook-secret'] as string | undefined) ||
    (typeof req.query.secret === 'string' ? req.query.secret : undefined) ||
    '';

  // Meta sends X-Hub-Signature-256: sha256=<hmac(body)>
  const metaSig = req.headers['x-hub-signature-256'] as string | undefined;
  if (platform === 'instagram' && metaSig) {
    const digest = 'sha256=' + crypto.createHmac('sha256', expected).update(JSON.stringify(req.body)).digest('hex');
    const a = Buffer.from(metaSig);
    const b = Buffer.from(digest);
    if (a.length === b.length && crypto.timingSafeEqual(a, b)) return true;
  }

  const a = Buffer.from(supplied);
  const b = Buffer.from(expected);
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) {
    fail(res, 401, 'Invalid webhook secret.');
    return false;
  }
  return true;
}

function registerWebhook(platform: SocialPlatform) {
  socialRouter.post(`/webhook/${platform}`, async (req: AuthRequest, res) => {
    if (!webhookAuthorized(platform, req, res)) return;
    try {
      // Telegram challenges / Meta verification are GET; POSTs are real events.
      const result = await ingestSocialMessage(platform, req.body || {});
      return res.json({ ok: true, ...result });
    } catch (err) {
      return fail(res, 500, 'Webhook processing failed.', (err as Error)?.message);
    }
  });
}

PLATFORMS.forEach(registerWebhook);

// Meta verification handshake (GET hub.challenge)
socialRouter.get('/webhook/instagram', (req, res) => {
  const verifyToken = process.env.IG_VERIFY_TOKEN;
  if (verifyToken && req.query['hub.verify_token'] !== verifyToken) {
    return fail(res, 403, 'Invalid verification token.');
  }
  return res.status(200).send(String(req.query['hub.challenge'] || ''));
});

socialRouter.get('/webhook/tiktok', (req, res) => {
  return res.status(200).send(String(req.query.challenge || req.query['hub.challenge'] || ''));
});
