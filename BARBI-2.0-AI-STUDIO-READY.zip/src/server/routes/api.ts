import { Router, raw, type Response } from 'express';
import { z } from 'zod';
import os from 'node:os';
import { optionalAuth, requireAuth, type AuthRequest } from '../../middleware/auth.ts';
import {
  generateBarbiChatStream,
  generateBarbiChatTurn,
  hasConfiguredGeminiKey,
  transcribeAudioBuffer,
} from '../ai/geminiService.ts';
import {
  callOpenAiCompatibleProvider,
  estimateTokenCount,
  getProviderQuotaSnapshot,
  selectBestAvailableProvider,
  streamOpenAiCompatibleProvider,
  updateUserRoutingPrefs,
} from '../ai/providerRegistry.ts';
import {
  buildAndHostSystemBundle,
  buildCustomAgentBlueprint,
  getHostedSystemBundle,
  listHostedSystems,
  studyExternalPlatform,
  syncReaGithubRepo,
} from '../rea/reaService.ts';
import { generateNotebookStudyPack } from '../studio/studyStudioService.ts';
import {
  addMemorySource,
  appendConversationTurn,
  createKnowledgeEdge,
  createOrUpdateKnowledgeNode,
  createTimerSession,
  deleteConversation,
  deleteHabit,
  deleteKnowledgeEdge,
  deleteKnowledgeNode,
  exportFullArchivexBackup,
  getConversationMessages,
  getUserSettingsRecord,
  listContradictionsAndTimeline,
  listConversations,
  listHabits,
  listKnowledgeEdges,
  listKnowledgeNodes,
  listMemorySources,
  listTimerSessions,
  resolveContradiction,
  retrieveRelevantPastConversations,
  saveUserSettingsRecord,
  seedUserArchivexIfEmpty,
  semanticSearchKnowledgeNodes,
  upsertHabit,
} from '../archivex/repository.ts';
import { testDbConnection } from '../../db/index.ts';
import { collectEdgeControlHealth } from '../health/edgeHealthService.ts';
import {
  assimilateCustomGitHubRepo,
  exportDeploymentStack,
  getV4CatalogSnapshot,
  mountStarterPack,
  mountV4Module,
  removeAssimilatedRepo,
  searchGitHubForAssimilation,
  setFinTechRailMode,
  syncModuleFromGitHub,
  syncPackOrTierFromGitHub,
  unmountV4Module,
} from '../v4/githubModuleService.ts';
import { fetchGodsEyeFeedsSnapshot } from '../v4/godsEyeService.ts';
import { runFsAgentAnalysis } from '../ai/fsAgentService.ts';
import { opencodeRouter } from './opencode.ts';
import { socialRouter } from './social.ts';

export const apiRouter = Router();

// OpenCode bidirectional integration (embedded agent + B.A.R.B.I MCP bridge)
apiRouter.use('/opencode', opencodeRouter);

// B.A.R.B.I Social Agent — normalized inbox, replies, automation rules, webhooks
apiRouter.use('/social', socialRouter);

function sendError(res: Response, status: number, message: string, details?: unknown) {
  return res.status(status).json({ error: message, ...(details ? { details } : {}) });
}

// 1. Health & Diagnostics
apiRouter.get('/health', async (_req, res) => {
  const dbOk = await testDbConnection();
  return res.json({
    ok: dbOk,
    service: 'B.A.R.B.I 2.0 PIOS Engine',
    database: dbOk ? 'postgresql+pgvector' : 'disconnected',
    aiConfigured: hasConfiguredGeminiKey(),
    timestamp: new Date().toISOString(),
  });
});

// Real-time internet speed test endpoints (client measures transfer of real bytes)
apiRouter.get('/speedtest/ping', (_req, res) => {
  res.setHeader('Cache-Control', 'no-store');
  return res.json({ ok: true, t: Date.now() });
});

apiRouter.get('/speedtest/download', (req, res) => {
  const requested = Number(req.query.bytes);
  const bytes = Math.min(25_000_000, Math.max(100_000, Number.isFinite(requested) ? requested : 8_000_000));
  const chunk = Buffer.alloc(64 * 1024, 0x5a);
  res.setHeader('Content-Type', 'application/octet-stream');
  res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate');
  res.setHeader('X-Test-Bytes', String(bytes));
  res.setHeader('Content-Length', String(bytes));
  let sent = 0;
  const pump = () => {
    while (sent < bytes) {
      const size = Math.min(chunk.length, bytes - sent);
      sent += size;
      if (!res.write(chunk.subarray(0, size))) {
        res.once('drain', pump);
        return;
      }
    }
    res.end();
  };
  pump();
});

apiRouter.post('/speedtest/upload', raw({ type: '*/*', limit: '25mb' }), (req, res) => {
  const bytes = Buffer.isBuffer(req.body) ? req.body.length : 0;
  return res.json({ ok: bytes > 0, bytes });
});

// 2. Real Host OS Telemetry
apiRouter.get('/system/telemetry', (_req, res) => {
  const cpus = os.cpus();
  const totalMem = os.totalmem();
  const freeMem = os.freemem();
  const usedMemPct = Math.round(((totalMem - freeMem) / Math.max(1, totalMem)) * 100);
  const load = os.loadavg();
  const cpuLoadPct = Math.min(99, Math.max(4, Math.round((load[0] / Math.max(1, cpus.length)) * 100)));

  return res.json({
    platform: os.platform(),
    arch: os.arch(),
    cpuCount: cpus.length,
    cpuModel: cpus[0]?.model || 'Host Compute Core',
    cpuLoadPct,
    memoryUsedPct: usedMemPct,
    memoryTotalGb: Number((totalMem / 1024 ** 3).toFixed(2)),
    memoryFreeGb: Number((freeMem / 1024 ** 3).toFixed(2)),
    uptimeSeconds: Math.round(os.uptime()),
  });
});

// 2B. Edge-Native Control Layer System Health Summary
apiRouter.get('/system/edge-health', optionalAuth, async (req: AuthRequest, res) => {
  try {
    const userKey = req.user?.uid || 'guest';
    const summary = await collectEdgeControlHealth(userKey);
    return res.json(summary);
  } catch (err) {
    return sendError(res, 500, (err as Error)?.message || 'Failed to collect edge-native health metrics.');
  }
});

// 3. Server-Side Weather Proxy (Open-Meteo, zero client API key needed)
apiRouter.get('/weather', async (req, res) => {
  try {
    const lat = Number(req.query.lat ?? -25.7479);
    const lon = Number(req.query.lon ?? 28.2293);
    if (!Number.isFinite(lat) || !Number.isFinite(lon)) {
      return sendError(res, 400, 'Invalid coordinates.');
    }
    const url = `https://api.open-meteo.com/v1/forecast?latitude=${lat.toFixed(4)}&longitude=${lon.toFixed(4)}&current=temperature_2m,relative_humidity_2m,apparent_temperature,wind_speed_10m,weather_code&daily=temperature_2m_max,temperature_2m_min,precipitation_probability_max&timezone=auto`;
    const r = await fetch(url);
    if (!r.ok) {
      return sendError(res, 502, 'Upstream weather telemetry unavailable.');
    }
    const data = await r.json();
    return res.json(data);
  } catch (err) {
    return sendError(res, 502, (err as Error)?.message || 'Weather proxy failed.');
  }
});

// 4. GitHub Public Repository Capability Explorer (Server-side proxy + optional import)
apiRouter.get('/integrations/github/search', async (req, res) => {
  try {
    const q = String(req.query.q || 'mechatronics esp32 robotics').trim().slice(0, 120);
    if (!q) return sendError(res, 400, 'Query q is required.');
    const ghRes = await fetch(
      `https://api.github.com/search/repositories?q=${encodeURIComponent(q)}&sort=stars&order=desc&per_page=8`,
      {
        headers: {
          Accept: 'application/vnd.github+json',
          'User-Agent': 'BARBI-PIOS-2.0',
        },
      }
    );
    if (!ghRes.ok) {
      return sendError(res, 502, `GitHub API returned ${ghRes.status}`);
    }
    const json = (await ghRes.json()) as {
      items?: Array<{
        full_name: string;
        html_url: string;
        description: string | null;
        stargazers_count: number;
        language: string | null;
        topics?: string[];
        updated_at: string;
      }>;
    };
    const items = (json.items || []).map((repo) => ({
      fullName: repo.full_name,
      url: repo.html_url,
      description: repo.description || 'No description provided.',
      stars: repo.stargazers_count,
      language: repo.language || 'Unknown',
      topics: (repo.topics || []).slice(0, 6),
      updatedAt: repo.updated_at,
    }));
    return res.json({ query: q, items });
  } catch (err) {
    return sendError(res, 502, (err as Error)?.message || 'GitHub search failed.');
  }
});

// 5. Server-Side Telegram Relay (uses server env secrets, never client tokens)
const telegramSendSchema = z.object({
  text: z.string().min(1).max(4000),
  chatId: z.string().max(120).optional(),
});

apiRouter.post('/integrations/telegram/send', optionalAuth, async (req: AuthRequest, res) => {
  const parsed = telegramSendSchema.safeParse(req.body);
  if (!parsed.success) {
    return sendError(res, 400, 'Invalid Telegram payload.', parsed.error.flatten());
  }
  const botToken = process.env.TELEGRAM_BOT_TOKEN;
  const chatId = parsed.data.chatId?.trim() || process.env.TELEGRAM_CHAT_ID;
  if (!botToken || !chatId) {
    return res.status(503).json({
      configured: false,
      error: 'Telegram server relay is not configured on this host (TELEGRAM_BOT_TOKEN / TELEGRAM_CHAT_ID).',
    });
  }
  try {
    const tgRes = await fetch(`https://api.telegram.org/bot${botToken}/sendMessage`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ chat_id: chatId, text: parsed.data.text }),
    });
    const tgJson = await tgRes.json();
    if (!tgRes.ok) {
      return sendError(res, 502, 'Telegram API delivery failed.', tgJson);
    }
    return res.json({ ok: true, result: tgJson });
  } catch (err) {
    return sendError(res, 502, (err as Error)?.message || 'Telegram request failed.');
  }
});

// 6. Authenticated Workspace Bootstrap
apiRouter.post('/bootstrap', requireAuth, async (req: AuthRequest, res) => {
  try {
    const uid = req.user!.uid;
    await seedUserArchivexIfEmpty(uid);

    const [
      nodes,
      edges,
      sources,
      contradictionsAndTimeline,
      conversationsList,
      habitRows,
      timerRows,
      settingsRow,
    ] = await Promise.all([
      listKnowledgeNodes(uid, { limit: 300 }),
      listKnowledgeEdges(uid),
      listMemorySources(uid),
      listContradictionsAndTimeline(uid),
      listConversations(uid),
      listHabits(uid),
      listTimerSessions(uid),
      getUserSettingsRecord(uid),
    ]);

    return res.json({
      user: {
        uid,
        email: req.user!.email || '',
        name: req.user!.name || 'Treasure Trinity Zulu',
      },
      nodes,
      edges,
      sources,
      contradictions: contradictionsAndTimeline.contradictions,
      timelineEvents: contradictionsAndTimeline.timeline,
      conversations: conversationsList,
      habits: habitRows,
      timerSessions: timerRows,
      settings: settingsRow,
    });
  } catch (err) {
    return sendError(res, 500, (err as Error)?.message || 'Failed to bootstrap workspace.');
  }
});

// 7. ARCHIVEX Knowledge Nodes CRUD & Semantic Vector Search
const nodePayloadSchema = z.object({
  nodeKey: z.string().max(160).optional(),
  label: z.string().min(1).max(200),
  category: z.string().max(64).optional(),
  domain: z.string().max(64).optional(),
  nexusCategory: z.string().max(120).optional(),
  tier: z.string().max(32).optional(),
  icon: z.string().max(16).optional(),
  summary: z.string().max(600).optional(),
  content: z.string().min(1).max(16000),
  evidence: z.string().max(4000).optional(),
  source: z.string().max(240).optional(),
  sourceUri: z.string().max(512).optional(),
  verificationStatus: z.string().max(64).optional(),
  confidence: z.number().min(0).max(1).optional(),
  year: z.number().int().min(1900).max(2200).optional(),
  isoTimestamp: z.string().max(64).optional(),
  datePrecision: z.string().max(32).optional(),
  metadata: z.record(z.string(), z.unknown()).optional(),
});

apiRouter.get('/memories', requireAuth, async (req: AuthRequest, res) => {
  try {
    const nodes = await listKnowledgeNodes(req.user!.uid, {
      domain: typeof req.query.domain === 'string' ? req.query.domain : undefined,
      category: typeof req.query.category === 'string' ? req.query.category : undefined,
      query: typeof req.query.q === 'string' ? req.query.q : undefined,
    });
    return res.json({ nodes });
  } catch (err) {
    return sendError(res, 500, (err as Error)?.message || 'Failed to list memories.');
  }
});

apiRouter.post('/memories', requireAuth, async (req: AuthRequest, res) => {
  const parsed = nodePayloadSchema.safeParse(req.body);
  if (!parsed.success) {
    return sendError(res, 400, 'Invalid memory payload.', parsed.error.flatten());
  }
  try {
    const result = await createOrUpdateKnowledgeNode(req.user!.uid, parsed.data);
    return res.status(201).json(result);
  } catch (err) {
    return sendError(res, 500, (err as Error)?.message || 'Failed to save memory.');
  }
});

apiRouter.put('/memories/:nodeKey', requireAuth, async (req: AuthRequest, res) => {
  const parsed = nodePayloadSchema.safeParse({ ...req.body, nodeKey: req.params.nodeKey });
  if (!parsed.success) {
    return sendError(res, 400, 'Invalid memory update payload.', parsed.error.flatten());
  }
  try {
    const result = await createOrUpdateKnowledgeNode(req.user!.uid, parsed.data);
    return res.json(result);
  } catch (err) {
    return sendError(res, 500, (err as Error)?.message || 'Failed to update memory.');
  }
});

apiRouter.delete('/memories/:nodeKey', requireAuth, async (req: AuthRequest, res) => {
  try {
    const hard = req.query.hard === 'true';
    const deleted = await deleteKnowledgeNode(req.user!.uid, String(req.params.nodeKey), hard);
    if (!deleted) return sendError(res, 404, 'Memory node not found.');
    return res.json({ ok: true, deleted });
  } catch (err) {
    return sendError(res, 500, (err as Error)?.message || 'Failed to delete memory.');
  }
});

apiRouter.post('/memories/search', requireAuth, async (req: AuthRequest, res) => {
  const schema = z.object({ query: z.string().min(1).max(1000), limit: z.number().int().min(1).max(30).optional() });
  const parsed = schema.safeParse(req.body);
  if (!parsed.success) {
    return sendError(res, 400, 'Invalid search query.', parsed.error.flatten());
  }
  try {
    const out = await semanticSearchKnowledgeNodes(
      req.user!.uid,
      parsed.data.query,
      parsed.data.limit || 8
    );
    return res.json(out);
  } catch (err) {
    return sendError(res, 500, (err as Error)?.message || 'Semantic search failed.');
  }
});

// 8. Knowledge Graph Edges & Sources & Contradictions & Timeline
apiRouter.get('/edges', requireAuth, async (req: AuthRequest, res) => {
  try {
    const edges = await listKnowledgeEdges(req.user!.uid);
    return res.json({ edges });
  } catch (err) {
    return sendError(res, 500, (err as Error)?.message || 'Failed to load edges.');
  }
});

apiRouter.post('/edges', requireAuth, async (req: AuthRequest, res) => {
  const schema = z.object({
    sourceNodeKey: z.string().min(1).max(160),
    targetNodeKey: z.string().min(1).max(160),
    relationType: z.string().min(1).max(64).default('RELATES_TO'),
    weight: z.number().min(0).max(1).optional(),
    evidence: z.string().max(1000).optional(),
    source: z.string().max(240).optional(),
  });
  const parsed = schema.safeParse(req.body);
  if (!parsed.success) return sendError(res, 400, 'Invalid edge payload.', parsed.error.flatten());
  try {
    const edge = await createKnowledgeEdge(req.user!.uid, parsed.data);
    return res.status(201).json({ edge });
  } catch (err) {
    return sendError(res, 500, (err as Error)?.message || 'Failed to save edge.');
  }
});

apiRouter.delete('/edges/:id', requireAuth, async (req: AuthRequest, res) => {
  const id = Number(req.params.id);
  if (!Number.isInteger(id)) return sendError(res, 400, 'Invalid edge id.');
  try {
    const deleted = await deleteKnowledgeEdge(req.user!.uid, id);
    if (!deleted) return sendError(res, 404, 'Edge not found.');
    return res.json({ ok: true });
  } catch (err) {
    return sendError(res, 500, (err as Error)?.message || 'Failed to delete edge.');
  }
});

apiRouter.get('/sources', requireAuth, async (req: AuthRequest, res) => {
  try {
    const nodeKey = typeof req.query.nodeKey === 'string' ? req.query.nodeKey : undefined;
    const sources = await listMemorySources(req.user!.uid, nodeKey);
    return res.json({ sources });
  } catch (err) {
    return sendError(res, 500, (err as Error)?.message || 'Failed to load memory sources.');
  }
});

apiRouter.post('/sources', requireAuth, async (req: AuthRequest, res) => {
  const schema = z.object({
    nodeKey: z.string().min(1).max(160),
    sourceType: z.string().max(48).optional(),
    sourceTitle: z.string().min(1).max(240),
    sourceUri: z.string().max(512).optional(),
    excerpt: z.string().max(2000).optional(),
  });
  const parsed = schema.safeParse(req.body);
  if (!parsed.success) return sendError(res, 400, 'Invalid source payload.', parsed.error.flatten());
  try {
    const source = await addMemorySource(req.user!.uid, parsed.data);
    return res.status(201).json({ source });
  } catch (err) {
    return sendError(res, 500, (err as Error)?.message || 'Failed to save source.');
  }
});

apiRouter.get('/contradictions', requireAuth, async (req: AuthRequest, res) => {
  try {
    const data = await listContradictionsAndTimeline(req.user!.uid);
    return res.json(data);
  } catch (err) {
    return sendError(res, 500, (err as Error)?.message || 'Failed to load integrity records.');
  }
});

apiRouter.patch('/contradictions/:key', requireAuth, async (req: AuthRequest, res) => {
  const schema = z.object({
    status: z.enum(['PENDING_CONFIRMATION', 'VERIFIED_CORRECTION', 'DISMISSED']),
    correctedRecord: z.string().max(2000).optional(),
  });
  const parsed = schema.safeParse(req.body);
  if (!parsed.success) return sendError(res, 400, 'Invalid resolution payload.');
  try {
    const updated = await resolveContradiction(
      req.user!.uid,
      String(req.params.key),
      parsed.data.status,
      parsed.data.correctedRecord
    );
    if (!updated) return sendError(res, 404, 'Contradiction record not found.');
    return res.json({ contradiction: updated });
  } catch (err) {
    return sendError(res, 500, (err as Error)?.message || 'Failed to resolve contradiction.');
  }
});

apiRouter.get('/timeline', requireAuth, async (req: AuthRequest, res) => {
  try {
    const data = await listContradictionsAndTimeline(req.user!.uid);
    return res.json({ timelineEvents: data.timeline });
  } catch (err) {
    return sendError(res, 500, (err as Error)?.message || 'Failed to load timeline.');
  }
});

// 9. Persistent Conversations & Messages
apiRouter.get('/conversations', requireAuth, async (req: AuthRequest, res) => {
  try {
    const items = await listConversations(req.user!.uid);
    return res.json({ conversations: items });
  } catch (err) {
    return sendError(res, 500, (err as Error)?.message || 'Failed to list conversations.');
  }
});

apiRouter.get('/conversations/:key/messages', requireAuth, async (req: AuthRequest, res) => {
  try {
    const result = await getConversationMessages(req.user!.uid, String(req.params.key));
    if (!result) return sendError(res, 404, 'Conversation not found.');
    return res.json(result);
  } catch (err) {
    return sendError(res, 500, (err as Error)?.message || 'Failed to fetch conversation messages.');
  }
});

apiRouter.post('/conversations/:key/messages', requireAuth, async (req: AuthRequest, res) => {
  const schema = z.object({
    title: z.string().max(120).optional(),
    sender: z.enum(['user', 'barbi', 'system']),
    content: z.string().min(1).max(32000),
    model: z.string().max(64).optional(),
    thinkingUsed: z.boolean().optional(),
    activatedNodes: z.array(z.string()).optional(),
    attachments: z
      .array(z.object({ name: z.string(), type: z.string(), mimeType: z.string().optional() }))
      .optional(),
  });
  const parsed = schema.safeParse(req.body);
  if (!parsed.success) return sendError(res, 400, 'Invalid message payload.');
  try {
    const saved = await appendConversationTurn(req.user!.uid, {
      conversationKey: String(req.params.key),
      ...parsed.data,
    });
    return res.status(201).json(saved);
  } catch (err) {
    return sendError(res, 500, (err as Error)?.message || 'Failed to store conversation message.');
  }
});

apiRouter.delete('/conversations/:key', requireAuth, async (req: AuthRequest, res) => {
  try {
    const deleted = await deleteConversation(req.user!.uid, String(req.params.key));
    if (!deleted) return sendError(res, 404, 'Conversation not found.');
    return res.json({ ok: true });
  } catch (err) {
    return sendError(res, 500, (err as Error)?.message || 'Failed to delete conversation.');
  }
});

// 10. Habits, Smart Timer Sessions, User Settings, Backup Export
apiRouter.get('/habits', requireAuth, async (req: AuthRequest, res) => {
  try {
    const rows = await listHabits(req.user!.uid);
    return res.json({ habits: rows });
  } catch (err) {
    return sendError(res, 500, (err as Error)?.message || 'Failed to load habits.');
  }
});

apiRouter.post('/habits', requireAuth, async (req: AuthRequest, res) => {
  const schema = z.object({
    habitKey: z.string().max(100).optional(),
    title: z.string().min(1).max(280),
    category: z.string().max(48).optional(),
    completed: z.boolean().optional(),
    streak: z.number().int().min(0).max(99999).optional(),
    dueTime: z.string().max(32).optional(),
    reminderEnabled: z.boolean().optional(),
  });
  const parsed = schema.safeParse(req.body);
  if (!parsed.success) return sendError(res, 400, 'Invalid habit payload.');
  try {
    const habit = await upsertHabit(req.user!.uid, parsed.data);
    return res.status(201).json({ habit });
  } catch (err) {
    return sendError(res, 500, (err as Error)?.message || 'Failed to save habit.');
  }
});

apiRouter.delete('/habits/:key', requireAuth, async (req: AuthRequest, res) => {
  try {
    const deleted = await deleteHabit(req.user!.uid, String(req.params.key));
    if (!deleted) return sendError(res, 404, 'Habit not found.');
    return res.json({ ok: true });
  } catch (err) {
    return sendError(res, 500, (err as Error)?.message || 'Failed to delete habit.');
  }
});

apiRouter.get('/timer-sessions', requireAuth, async (req: AuthRequest, res) => {
  try {
    const sessions = await listTimerSessions(req.user!.uid);
    return res.json({ sessions });
  } catch (err) {
    return sendError(res, 500, (err as Error)?.message || 'Failed to load timer sessions.');
  }
});

apiRouter.post('/timer-sessions', requireAuth, async (req: AuthRequest, res) => {
  const schema = z.object({
    mode: z.string().max(32).default('focus'),
    durationSeconds: z.number().int().min(1).max(86400),
    completedSeconds: z.number().int().min(0).max(86400),
    status: z.string().max(32).default('completed'),
    label: z.string().max(120).optional(),
  });
  const parsed = schema.safeParse(req.body);
  if (!parsed.success) return sendError(res, 400, 'Invalid timer session payload.');
  try {
    const session = await createTimerSession(req.user!.uid, parsed.data);
    return res.status(201).json({ session });
  } catch (err) {
    return sendError(res, 500, (err as Error)?.message || 'Failed to log timer session.');
  }
});

apiRouter.get('/settings', requireAuth, async (req: AuthRequest, res) => {
  try {
    const settings = await getUserSettingsRecord(req.user!.uid);
    return res.json({ settings });
  } catch (err) {
    return sendError(res, 500, (err as Error)?.message || 'Failed to load settings.');
  }
});

apiRouter.put('/settings', requireAuth, async (req: AuthRequest, res) => {
  const schema = z.object({
    settingsJson: z.record(z.string(), z.unknown()).default({}),
    voiceSettingsJson: z.record(z.string(), z.unknown()).default({}),
  });
  const parsed = schema.safeParse(req.body);
  if (!parsed.success) return sendError(res, 400, 'Invalid settings payload.');
  try {
    const settings = await saveUserSettingsRecord(
      req.user!.uid,
      parsed.data.settingsJson,
      parsed.data.voiceSettingsJson
    );
    return res.json({ settings });
  } catch (err) {
    return sendError(res, 500, (err as Error)?.message || 'Failed to save settings.');
  }
});

apiRouter.get('/export', requireAuth, async (req: AuthRequest, res) => {
  try {
    const backup = await exportFullArchivexBackup(req.user!.uid);
    return res.json(backup);
  } catch (err) {
    return sendError(res, 500, (err as Error)?.message || 'Failed to export ARCHIVEX backup.');
  }
});

// 11. Modular Server-Side AI Chat & Voice Transcription
const aiChatSchema = z.object({
  prompt: z.string().min(1).max(20000),
  conversationKey: z.string().max(120).optional(),
  honorific: z.string().max(64).optional(),
  deepThink: z.boolean().optional(),
  quickMode: z.boolean().optional(),
  enableGoogleSearch: z.boolean().optional(),
  history: z
    .array(
      z.object({
        role: z.enum(['user', 'assistant']),
        content: z.string().max(8000),
      })
    )
    .max(20)
    .optional(),
  localNodesContext: z.string().max(6000).optional(),
  uiSnapshot: z.string().max(4000).optional(),
  providerId: z.string().max(40).optional(),
  preferredGeminiModel: z.enum(['gemini-4-hydrogen', 'gemini-3.1-flash-lite']).optional(),
  allowAutoFailover: z.boolean().optional(),
  attachments: z
    .array(
      z.object({
        name: z.string().max(240),
        mimeType: z.string().max(120).optional(),
        base64Data: z.string().max(8_000_000).optional(),
        textExcerpt: z.string().max(12000).optional(),
      })
    )
    .max(4)
    .optional(),
});

// 11A. Free-Tier Multi-Provider Quota Monitor & Priority Arrangement
apiRouter.get('/ai/providers', optionalAuth, (req: AuthRequest, res) => {
  const userKey = req.user?.uid || 'guest';
  return res.json(getProviderQuotaSnapshot(userKey));
});

apiRouter.put('/ai/providers/preferences', optionalAuth, (req: AuthRequest, res) => {
  const schema = z.object({
    priorityOrder: z.array(z.string().max(40)).optional(),
    enabled: z.record(z.string(), z.boolean()).optional(),
    selectedProviderId: z.string().max(40).optional(),
    switchMode: z.enum(['auto', 'recommend']).optional(),
  });
  const parsed = schema.safeParse(req.body);
  if (!parsed.success) return sendError(res, 400, 'Invalid provider preferences payload.');
  const userKey = req.user?.uid || 'guest';
  updateUserRoutingPrefs(userKey, parsed.data);
  return res.json(getProviderQuotaSnapshot(userKey));
});

apiRouter.post('/ai/providers/switch', optionalAuth, (req: AuthRequest, res) => {
  const schema = z.object({ providerId: z.string().min(1).max(40) });
  const parsed = schema.safeParse(req.body);
  if (!parsed.success) return sendError(res, 400, 'Invalid providerId.');
  const userKey = req.user?.uid || 'guest';
  updateUserRoutingPrefs(userKey, { selectedProviderId: parsed.data.providerId });
  return res.json(getProviderQuotaSnapshot(userKey));
});

apiRouter.post('/ai/chat', optionalAuth, async (req: AuthRequest, res) => {
  const parsed = aiChatSchema.safeParse(req.body);
  if (!parsed.success) {
    return sendError(res, 400, 'Invalid AI chat request.', parsed.error.flatten());
  }

  const uid = req.user?.uid;
  const userKey = uid || 'guest';
  const conversationKey = parsed.data.conversationKey || `conv-session-${Date.now()}`;

  let memoryContext = '';
  let conversationContext = '';
  const activatedNodeKeys: string[] = [];

  if (uid) {
    try {
      const [semNodes, pastTurns] = await Promise.all([
        semanticSearchKnowledgeNodes(uid, parsed.data.prompt, 6),
        retrieveRelevantPastConversations(uid, parsed.data.prompt, 4),
      ]);
      if (semNodes.results.length > 0) {
        memoryContext = semNodes.results
          .map((n) => {
            activatedNodeKeys.push(n.nodeKey);
            return `- ${n.label} [${n.verificationStatus}, sim=${n.similarity.toFixed(2)}]: ${n.content}`;
          })
          .join('\n');
      }
      if (pastTurns.length > 0) {
        conversationContext = pastTurns
          .map((t) => `- [${t.sender}] ${t.content.slice(0, 240)}`)
          .join('\n');
      }
    } catch (err) {
      console.warn('Semantic retrieval skipped:', (err as Error)?.message || err);
    }
  }

  const estimatedTokens = estimateTokenCount(parsed.data.prompt + memoryContext + conversationContext) + 500;
  const prefsSnapshot = getProviderQuotaSnapshot(userKey);
  const routingDecision = selectBestAvailableProvider(userKey, [], Date.now(), estimatedTokens);

  // HARD FREE-TIER STOP: never exceed free tier! Throw warning recommendation instead of overrunning cap
  if (
    prefsSnapshot.switchMode === 'recommend' &&
    routingDecision.needsSwitchPrompt &&
    routingDecision.recommendedNext &&
    !parsed.data.providerId &&
    !parsed.data.allowAutoFailover
  ) {
    return res.json({
      reply: '',
      model: routingDecision.primary?.modelId || 'gemini-4-hydrogen',
      thinkingLevel: 'MEDIUM',
      provider: 'rate-limit-recommendation',
      toolInvocations: [],
      conversationKey,
      activatedNodes: activatedNodeKeys,
      fallback: false,
      switchRecommendation: {
        currentProvider: routingDecision.primary,
        recommendedProvider: routingDecision.recommendedNext,
        cooldownRemainingSec: routingDecision.primary?.cooldownRemainingSec || 30,
        reason: routingDecision.reason,
        warningType: 'HARD_STOP_PREVENT_EXCEED',
      },
      quotaSnapshot: getProviderQuotaSnapshot(userKey),
    });
  }

  const enableGoogleSearch = parsed.data.enableGoogleSearch !== false;
  const geminiReady = prefsSnapshot.providers.some(
    (p) => p.id === 'gemini' && p.enabled && p.configured && (p.status === 'READY' || p.status === 'LOW_QUOTA')
  );
  const orderedCandidates = [
    ...(parsed.data.providerId ? [parsed.data.providerId] : []),
    ...(!parsed.data.providerId && enableGoogleSearch && geminiReady ? ['gemini'] : []),
    ...(routingDecision.primary ? [routingDecision.primary.id] : []),
    ...prefsSnapshot.providers
      .filter((p) => p.enabled && p.configured && (p.status === 'READY' || p.status === 'LOW_QUOTA'))
      .map((p) => p.id),
  ].filter((id, idx, arr) => arr.indexOf(id) === idx);

  const failoverTrail: Array<{ providerId: string; status: string; reason?: string }> = [];
  let aiResult: Awaited<ReturnType<typeof generateBarbiChatTurn>> | null = null;
  let activeProviderId = orderedCandidates[0] || 'gemini';

  for (const candidateId of orderedCandidates) {
    activeProviderId = candidateId;
    try {
      if (candidateId === 'gemini') {
        const gRes = await generateBarbiChatTurn({
          prompt: parsed.data.prompt,
          honorific: parsed.data.honorific,
          history: parsed.data.history,
          memoryContext,
          conversationContext,
          graphContext: parsed.data.localNodesContext,
          uiSnapshot: parsed.data.uiSnapshot,
          attachments: parsed.data.attachments,
          deepThink: parsed.data.deepThink,
          quickMode: parsed.data.quickMode,
          enableGoogleSearch,
          onToolCall: uid
            ? async (fnName, args) => {
                if (fnName === 'save_archivex_memory') {
                  const saved = await createOrUpdateKnowledgeNode(uid, {
                    label: String(args.label || 'Captured Insight'),
                    content: String(args.content || parsed.data.prompt),
                    category: typeof args.category === 'string' ? args.category : 'KNOWLEDGE',
                    domain: typeof args.domain === 'string' ? args.domain : undefined,
                    source: 'BARBI_TOOL_CALL',
                    verificationStatus: 'USER_REPORTED',
                  });
                  return {
                    saved: true,
                    nodeKey: saved.node.nodeKey,
                    contradiction: saved.detectedContradiction,
                  };
                }
                if (fnName === 'create_productivity_habit') {
                  const habit = await upsertHabit(uid, {
                    title: String(args.title || 'Follow-up Engineering Action'),
                    category: typeof args.category === 'string' ? args.category : 'professional',
                    completed: false,
                    streak: 0,
                  });
                  return { created: true, habitKey: habit.habitKey, title: habit.title };
                }
                return { ok: false, reason: 'Unknown tool' };
              }
            : undefined,
        });
        if (gRes.reply) {
          aiResult = gRes;
          failoverTrail.push({ providerId: 'gemini', status: 'succeeded' });
          break;
        }
        failoverTrail.push({ providerId: 'gemini', status: 'skipped', reason: 'Empty reply or key missing' });
      } else {
        const systemInstruction = [
          `You are B.A.R.B.I. (Brilliant Adaptive Reasoning Brain Interface), the personal cognitive AI operating system of Treasure Trinity Zulu.`,
          `Always refer to yourself simply in the first person as "I" (never say "Zulutro and I"). Address the user respectfully as "${parsed.data.honorific || 'Chief Engineer'}" or "Treasure".`,
          parsed.data.uiSnapshot ? `[Live B.A.R.B.I. Screen State]\n${parsed.data.uiSnapshot}` : '',
          memoryContext ? `[ARCHIVEX Persistent Memories]\n${memoryContext}` : '',
          conversationContext ? `[Retrieved Prior Conversations]\n${conversationContext}` : '',
          parsed.data.localNodesContext ? `[Active Knowledge Graph]\n${parsed.data.localNodesContext}` : '',
        ]
          .filter(Boolean)
          .join('\n');

        const extRes = await callOpenAiCompatibleProvider({
          providerId: candidateId,
          systemInstruction,
          prompt: parsed.data.prompt,
          history: parsed.data.history,
        });
        aiResult = {
          reply: extRes.reply,
          model: `${candidateId}:${extRes.model}`,
          thinkingLevel: 'MEDIUM',
          provider: 'gemini',
          toolInvocations: [],
        };
        failoverTrail.push({ providerId: candidateId, status: 'succeeded' });
        break;
      }
      } catch (err) {
      const reason = (err as Error)?.message || 'error';
      failoverTrail.push({
        providerId: candidateId,
        status: 'failed',
        reason,
      });
      const isTransient = /503|502|504|UNAVAILABLE|overloaded|high demand|timeout|abort/i.test(reason);
      if (prefsSnapshot.switchMode === 'recommend' && parsed.data.allowAutoFailover === false && !isTransient) {
        break;
      }
    }
  }

  if (aiResult && aiResult.reply) {
    if (uid) {
      try {
        await appendConversationTurn(uid, {
          conversationKey,
          sender: 'user',
          content: parsed.data.prompt,
          model: aiResult.model,
          activatedNodes: activatedNodeKeys,
        });
        await appendConversationTurn(uid, {
          conversationKey,
          sender: 'barbi',
          content: aiResult.reply,
          model: aiResult.model,
          thinkingUsed: aiResult.thinkingLevel !== 'LOW',
          activatedNodes: activatedNodeKeys,
        });
      } catch (persistErr) {
        console.warn('Conversation turn persistence warning:', persistErr);
      }
    }

    const postDecision = selectBestAvailableProvider(userKey);
    return res.json({
      ...aiResult,
      activeProviderId,
      failoverTrail,
      quotaSnapshot: getProviderQuotaSnapshot(userKey),
      ...(postDecision.lowQuotaWarning && postDecision.recommendedNext
        ? {
            lowQuotaWarning: {
              activeProvider: postDecision.primary,
              recommendedNext: postDecision.recommendedNext,
              reason: postDecision.reason,
            },
          }
        : {}),
      conversationKey,
      activatedNodes: activatedNodeKeys,
      fallback: false,
    });
  }

  const postFailDecision = selectBestAvailableProvider(userKey);
  const lastFailureReason =
    failoverTrail.find((f) => f.status === 'failed' && f.reason)?.reason ||
    'No configured AI provider returned a response.';
  return res.json({
    reply: '',
    error: lastFailureReason,
    model: 'gemini-4-hydrogen',
    thinkingLevel: 'HIGH',
    provider: 'local-archivex-fallback',
    activeProviderId,
    failoverTrail,
    quotaSnapshot: getProviderQuotaSnapshot(userKey),
    toolInvocations: [],
    conversationKey,
    activatedNodes: activatedNodeKeys,
    fallback: true,
    ...(postFailDecision.needsSwitchPrompt && postFailDecision.recommendedNext
      ? {
          switchRecommendation: {
            currentProvider: postFailDecision.primary,
            recommendedProvider: postFailDecision.recommendedNext,
            cooldownRemainingSec: postFailDecision.primary?.cooldownRemainingSec || 60,
            reason: postFailDecision.reason,
          },
        }
      : {}),
  });
});

// 11B. Real-Time Streaming LLM Chat Endpoint (SSE)
apiRouter.post('/ai/chat/stream', optionalAuth, async (req: AuthRequest, res) => {
  const parsed = aiChatSchema.safeParse(req.body);
  if (!parsed.success) {
    return sendError(res, 400, 'Invalid AI chat stream request.', parsed.error.flatten());
  }

  res.setHeader('Content-Type', 'text/event-stream; charset=utf-8');
  res.setHeader('Cache-Control', 'no-cache, no-transform');
  res.setHeader('Connection', 'keep-alive');
  res.setHeader('X-Accel-Buffering', 'no');
  res.flushHeaders?.();

  let clientClosed = false;
  req.on('close', () => {
    clientClosed = true;
  });

  const emitSse = (event: string, data: unknown) => {
    if (clientClosed || res.writableEnded) return;
    res.write(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`);
  };

  const uid = req.user?.uid;
  const userKey = uid || 'guest';
  const conversationKey = parsed.data.conversationKey || `conv-session-${Date.now()}`;
  const startTotalMs = Date.now();

  let memoryContext = '';
  let conversationContext = '';
  const activatedNodeKeys: string[] = [];

  if (uid) {
    try {
      const [semNodes, pastTurns] = await Promise.all([
        semanticSearchKnowledgeNodes(uid, parsed.data.prompt, 6),
        retrieveRelevantPastConversations(uid, parsed.data.prompt, 4),
      ]);
      if (semNodes.results.length > 0) {
        memoryContext = semNodes.results
          .map((n) => {
            activatedNodeKeys.push(n.nodeKey);
            return `- ${n.label} [${n.verificationStatus}, sim=${n.similarity.toFixed(2)}]: ${n.content}`;
          })
          .join('\n');
      }
      if (pastTurns.length > 0) {
        conversationContext = pastTurns
          .map((t) => `- [${t.sender}] ${t.content.slice(0, 240)}`)
          .join('\n');
      }
    } catch (err) {
      console.warn('Semantic retrieval skipped:', (err as Error)?.message || err);
    }
  }

  const estimatedTokens = estimateTokenCount(parsed.data.prompt + memoryContext + conversationContext) + 500;
  const prefsSnapshot = getProviderQuotaSnapshot(userKey);
  const routingDecision = selectBestAvailableProvider(userKey, [], Date.now(), estimatedTokens);

  const enableGoogleSearch = parsed.data.enableGoogleSearch !== false;
  const geminiReady = prefsSnapshot.providers.some(
    (p) => p.id === 'gemini' && p.enabled && p.configured && (p.status === 'READY' || p.status === 'LOW_QUOTA')
  );
  const allowFailover = parsed.data.allowAutoFailover !== false;
  const orderedCandidates = parsed.data.providerId
    ? [
        parsed.data.providerId,
        ...(allowFailover
          ? prefsSnapshot.providers
              .filter((p) => p.id !== parsed.data.providerId && p.enabled && p.configured && (p.status === 'READY' || p.status === 'LOW_QUOTA'))
              .map((p) => p.id)
          : []),
      ]
    : [
        ...(enableGoogleSearch && geminiReady ? ['gemini'] : []),
        ...(routingDecision.primary ? [routingDecision.primary.id] : []),
        ...prefsSnapshot.providers
          .filter((p) => p.enabled && p.configured && (p.status === 'READY' || p.status === 'LOW_QUOTA'))
          .map((p) => p.id),
      ].filter((id, idx, arr) => arr.indexOf(id) === idx);

  const failoverTrail: Array<{ providerId: string; status: string; reason?: string }> = [];
  let succeededResult: {
    reply: string;
    model: string;
    thinkingLevel: string;
    activeProviderId: string;
    toolInvocations: Array<{ name: string; args: Record<string, unknown>; result: Record<string, unknown> }>;
    grounding?: { webSearchQueries: string[]; sources: Array<{ title: string; uri: string; domain: string }> };
  } | null = null;

  for (const candidateId of orderedCandidates) {
    if (clientClosed) break;
    let emittedAnyDelta = false;

    try {
      if (candidateId === 'gemini') {
        const gRes = await generateBarbiChatStream({
          prompt: parsed.data.prompt,
          honorific: parsed.data.honorific,
          history: parsed.data.history,
          memoryContext,
          conversationContext,
          graphContext: parsed.data.localNodesContext,
          uiSnapshot: parsed.data.uiSnapshot,
          attachments: parsed.data.attachments,
          deepThink: parsed.data.deepThink,
          quickMode: parsed.data.quickMode,
          enableGoogleSearch,
          preferredModel: parsed.data.preferredGeminiModel,
          onModelSelected: (model, thinkingLevel) => {
            emitSse('meta', {
              conversationKey,
              providerId: 'gemini',
              model,
              thinkingLevel,
              activatedNodes: activatedNodeKeys,
            });
          },
          onGrounding: (grounding) => {
            emitSse('grounding', grounding);
          },
          onChunk: (deltaText) => {
            emittedAnyDelta = true;
            emitSse('delta', { text: deltaText });
          },
          onToolCall: uid
            ? async (fnName, args) => {
                if (fnName === 'save_archivex_memory') {
                  const saved = await createOrUpdateKnowledgeNode(uid, {
                    label: String(args.label || 'Captured Insight'),
                    content: String(args.content || parsed.data.prompt),
                    category: typeof args.category === 'string' ? args.category : 'KNOWLEDGE',
                    domain: typeof args.domain === 'string' ? args.domain : undefined,
                    source: 'BARBI_TOOL_CALL',
                    verificationStatus: 'USER_REPORTED',
                  });
                  return {
                    saved: true,
                    nodeKey: saved.node.nodeKey,
                    contradiction: saved.detectedContradiction,
                  };
                }
                if (fnName === 'create_productivity_habit') {
                  const habit = await upsertHabit(uid, {
                    title: String(args.title || 'Follow-up Engineering Action'),
                    category: typeof args.category === 'string' ? args.category : 'professional',
                    completed: false,
                    streak: 0,
                  });
                  return { created: true, habitKey: habit.habitKey, title: habit.title };
                }
                return { ok: false, reason: 'Unknown tool' };
              }
            : undefined,
        });

        succeededResult = {
          reply: gRes.reply,
          model: gRes.model,
          thinkingLevel: gRes.thinkingLevel,
          activeProviderId: 'gemini',
          toolInvocations: gRes.toolInvocations,
          ...(gRes.grounding ? { grounding: gRes.grounding } : {}),
        };
        failoverTrail.push({ providerId: 'gemini', status: 'succeeded' });
        break;
      } else {
        const providerSpec = prefsSnapshot.providers.find((p) => p.id === candidateId);
        emitSse('meta', {
          conversationKey,
          providerId: candidateId,
          model: providerSpec?.modelId || candidateId,
          thinkingLevel: 'MEDIUM',
          activatedNodes: activatedNodeKeys,
        });

        const systemInstruction = [
          `You are B.A.R.B.I. (Brilliant Adaptive Reasoning Brain Interface), a general-purpose AI assistant and personal cognitive operating system of Treasure Trinity Zulu.`,
          `Always refer to yourself simply in the first person as "I" (never say "Zulutro and I"). Respond clearly, helpfully, and naturally using clean Markdown formatting when appropriate.`,
          parsed.data.uiSnapshot ? `[Live B.A.R.B.I. Screen State]\n${parsed.data.uiSnapshot}` : '',
          memoryContext ? `[ARCHIVEX Persistent Memories]\n${memoryContext}` : '',
          conversationContext ? `[Retrieved Prior Conversations]\n${conversationContext}` : '',
          parsed.data.localNodesContext ? `[Active Knowledge Graph]\n${parsed.data.localNodesContext}` : '',
        ]
          .filter(Boolean)
          .join('\n');

        const extRes = await streamOpenAiCompatibleProvider({
          providerId: candidateId,
          systemInstruction,
          prompt: parsed.data.prompt,
          history: parsed.data.history,
          onChunk: (deltaText) => {
            emittedAnyDelta = true;
            emitSse('delta', { text: deltaText });
          },
        });

        succeededResult = {
          reply: extRes.reply,
          model: extRes.model,
          thinkingLevel: 'MEDIUM',
          activeProviderId: candidateId,
          toolInvocations: [],
        };
        failoverTrail.push({ providerId: candidateId, status: 'succeeded' });
        break;
      }
    } catch (err) {
      const reason = (err as Error)?.message || 'Streaming error';
      failoverTrail.push({ providerId: candidateId, status: 'failed', reason });
      if (emittedAnyDelta || !allowFailover) {
        break;
      }
    }
  }

  if (succeededResult && !clientClosed) {
    if (uid) {
      try {
        await appendConversationTurn(uid, {
          conversationKey,
          sender: 'user',
          content: parsed.data.prompt,
          model: succeededResult.model,
          activatedNodes: activatedNodeKeys,
        });
        await appendConversationTurn(uid, {
          conversationKey,
          sender: 'barbi',
          content: succeededResult.reply,
          model: succeededResult.model,
          thinkingUsed: succeededResult.thinkingLevel !== 'LOW',
          activatedNodes: activatedNodeKeys,
        });
      } catch (persistErr) {
        console.warn('Stream conversation turn persistence warning:', persistErr);
      }
    }

    emitSse('done', {
      ...succeededResult,
      latencyMs: Date.now() - startTotalMs,
      conversationKey,
      activatedNodes: activatedNodeKeys,
      failoverTrail,
      quotaSnapshot: getProviderQuotaSnapshot(userKey),
    });
  } else if (!clientClosed) {
    const lastFailure =
      failoverTrail.find((f) => f.status === 'failed' && f.reason)?.reason ||
      'No AI provider could fulfill the request.';
    emitSse('error', {
      error: lastFailure,
      failoverTrail,
      quotaSnapshot: getProviderQuotaSnapshot(userKey),
    });
  }

  if (!res.writableEnded) {
    res.end();
  }
});

const transcribeSchema = z.object({
  audioBase64: z.string().min(16).max(12_000_000),
  mimeType: z.string().max(100).default('audio/webm'),
});

apiRouter.post('/ai/transcribe', optionalAuth, async (req, res) => {
  const parsed = transcribeSchema.safeParse(req.body);
  if (!parsed.success) {
    return sendError(res, 400, 'Invalid audio payload.');
  }
  if (!hasConfiguredGeminiKey()) {
    return res.status(503).json({
      error: 'Server audio transcription unavailable without configured GEMINI_API_KEY.',
    });
  }
  try {
    const transcript = await transcribeAudioBuffer(parsed.data.audioBase64, parsed.data.mimeType);
    return res.json({ transcript });
  } catch (err) {
    return sendError(res, 502, (err as Error)?.message || 'Audio transcription failed.');
  }
});

// 12. R.E.A. Platform / Website Study, Agent Forge & System Builder + Hosting
apiRouter.post('/rea/study-url', optionalAuth, async (req: AuthRequest, res) => {
  const schema = z.object({
    target: z.string().min(2).max(1000),
    notes: z.string().max(4000).optional(),
    allowAutoFailover: z.boolean().optional(),
  });
  const parsed = schema.safeParse(req.body);
  if (!parsed.success) return sendError(res, 400, 'Invalid platform/URL study target.');
  try {
    const userKey = req.user?.uid || 'guest';
    const out = await studyExternalPlatform({ userKey, ...parsed.data });
    return res.json(out);
  } catch (err) {
    return sendError(res, 400, (err as Error)?.message || 'Platform study failed.');
  }
});

apiRouter.get('/rea/github-repo', async (req, res) => {
  const repoParam = typeof req.query.repo === 'string' ? req.query.repo.trim() : undefined;
  try {
    const reaRepo = await syncReaGithubRepo(repoParam);
    return res.json({ reaRepo });
  } catch (err) {
    return sendError(res, 400, (err as Error)?.message || 'Invalid REA GitHub repository URL.');
  }
});

apiRouter.post('/rea/build-agent', optionalAuth, async (req: AuthRequest, res) => {
  const schema = z.object({
    prompt: z.string().min(4).max(4000),
    reaRepoUrl: z.string().max(400).optional(),
    platforms: z.array(z.enum(['web', 'windows', 'macos', 'ios', 'android'])).optional(),
    allowAutoFailover: z.boolean().optional(),
  });
  const parsed = schema.safeParse(req.body);
  if (!parsed.success) return sendError(res, 400, 'Invalid agent prompt.');
  try {
    const userKey = req.user?.uid || 'guest';
    const out = await buildCustomAgentBlueprint({ userKey, ...parsed.data });
    return res.json(out);
  } catch (err) {
    return sendError(res, 500, (err as Error)?.message || 'Agent forge failed.');
  }
});

apiRouter.post('/rea/build-system', optionalAuth, async (req: AuthRequest, res) => {
  const schema = z.object({
    systemName: z.string().min(2).max(120),
    prompt: z.string().min(5).max(8000),
    platforms: z.array(z.enum(['web', 'windows', 'macos', 'ios', 'android'])).optional(),
    reaRepoUrl: z.string().max(400).optional(),
    allowAutoFailover: z.boolean().optional(),
  });
  const parsed = schema.safeParse(req.body);
  if (!parsed.success) return sendError(res, 400, 'Invalid system forge specification.');
  try {
    const userKey = req.user?.uid || 'guest';
    const out = await buildAndHostSystemBundle({ userKey, ...parsed.data });
    return res.json(out);
  } catch (err) {
    return sendError(res, 500, (err as Error)?.message || 'System forge failed.');
  }
});

apiRouter.get('/rea/hosted', (_req, res) => {
  return res.json({ hostedApps: listHostedSystems() });
});

apiRouter.get('/rea/hosted/:slug/bundle', (req, res) => {
  const slug = String(req.params.slug || '').trim();
  const bundle = getHostedSystemBundle(slug);
  if (!bundle) return sendError(res, 404, 'Forged system bundle not found.');
  return res.json(bundle);
});

// 13. NotebookLM-Style Study Guide & Animated Explainer Video Storyboard Studio
apiRouter.post('/studio/generate-study-pack', optionalAuth, async (req: AuthRequest, res) => {
  const schema = z.object({
    topicTitle: z.string().min(2).max(200),
    materialText: z.string().min(20).max(20000),
    allowAutoFailover: z.boolean().optional(),
  });
  const parsed = schema.safeParse(req.body);
  if (!parsed.success) return sendError(res, 400, 'Provide a topic title and at least 20 characters of study material.');
  try {
    const userKey = req.user?.uid || 'guest';
    const out = await generateNotebookStudyPack({ userKey, ...parsed.data });
    return res.json(out);
  } catch (err) {
    return sendError(res, 500, (err as Error)?.message || 'Study Studio generation failed.');
  }
});

// 13b. NotebookLM-Parity Studio: Notebooks, Sources, Chat, Artifacts, Deep Research
import {
  createNotebook,
  listNotebooks,
  getNotebook,
  deleteNotebook,
  addSource,
  removeSource,
  discoverSources,
  chatWithNotebook,
  chatWithNotebookMode,
  getChatHistory,
  clearChatHistory,
  generateArtifact,
  generateArtifactCustom,
  listArtifacts,
  getArtifact,
  deleteArtifact,
  createNote,
  listNotes,
  updateNote,
  deleteNote,
  noteToSource,
  deepResearch,
  summarizeNotebook,
  exportNotebookMarkdown,
  ARTIFACT_TYPES,
  type ArtifactType,
} from '../studio/notebookLmService.ts';

apiRouter.post('/studio/notebooks', optionalAuth, (req: AuthRequest, res) => {
  const schema = z.object({ title: z.string().min(1).max(200).optional() });
  const parsed = schema.safeParse(req.body || {});
  if (!parsed.success) return sendError(res, 400, 'Invalid notebook payload.');
  const userKey = req.user?.uid || 'guest';
  const nb = createNotebook(userKey, parsed.data.title || 'Untitled Notebook');
  return res.json({ notebook: nb });
});

apiRouter.get('/studio/notebooks', optionalAuth, (req: AuthRequest, res) => {
  const userKey = req.user?.uid || 'guest';
  return res.json({ notebooks: listNotebooks(userKey) });
});

apiRouter.get('/studio/notebooks/:id', optionalAuth, (req: AuthRequest, res) => {
  const userKey = req.user?.uid || 'guest';
  const nb = getNotebook(userKey, req.params.id);
  if (!nb) return sendError(res, 404, 'Notebook not found.');
  return res.json({ notebook: nb, artifacts: listArtifacts(userKey, req.params.id), notes: listNotes(userKey, req.params.id) });
});

apiRouter.delete('/studio/notebooks/:id', optionalAuth, (req: AuthRequest, res) => {
  const userKey = req.user?.uid || 'guest';
  const ok = deleteNotebook(userKey, req.params.id);
  if (!ok) return sendError(res, 404, 'Notebook not found.');
  return res.json({ deleted: true });
});

apiRouter.post('/studio/notebooks/:id/sources', optionalAuth, async (req: AuthRequest, res) => {
  const userKey = req.user?.uid || 'guest';
  const schema = z.object({
    title: z.string().max(200).optional(),
    type: z.enum(['text', 'url', 'youtube', 'pdf', 'audio', 'doc']).optional(),
    content: z.string().max(50000).optional(),
    uri: z.string().max(2000).optional(),
  });
  const parsed = schema.safeParse(req.body || {});
  if (!parsed.success) return sendError(res, 400, 'Invalid source payload.');
  try {
    const src = await addSource(userKey, req.params.id, parsed.data);
    return res.json({ source: src });
  } catch (err) {
    return sendError(res, 400, (err as Error)?.message || 'Failed to add source.');
  }
});

apiRouter.delete('/studio/notebooks/:id/sources/:sourceId', optionalAuth, (req: AuthRequest, res) => {
  const userKey = req.user?.uid || 'guest';
  const ok = removeSource(userKey, req.params.id, req.params.sourceId);
  if (!ok) return sendError(res, 404, 'Source not found.');
  return res.json({ removed: true });
});

apiRouter.post('/studio/discover-sources', optionalAuth, async (req: AuthRequest, res) => {
  const schema = z.object({ topic: z.string().min(2).max(300), maxResults: z.number().int().min(1).max(12).optional() });
  const parsed = schema.safeParse(req.body || {});
  if (!parsed.success) return sendError(res, 400, 'Invalid discovery payload.');
  try {
    const hits = await discoverSources(parsed.data.topic, parsed.data.maxResults);
    return res.json({ sources: hits });
  } catch (err) {
    return sendError(res, 500, (err as Error)?.message || 'Source discovery failed.');
  }
});

apiRouter.post('/studio/notebooks/:id/chat', optionalAuth, async (req: AuthRequest, res) => {
  const userKey = req.user?.uid || 'guest';
  const schema = z.object({
    question: z.string().min(1).max(4000),
    mode: z.enum(['default', 'learning_guide', 'brief', 'detailed']).optional(),
    allowAutoFailover: z.boolean().optional(),
  });
  const parsed = schema.safeParse(req.body || {});
  if (!parsed.success) return sendError(res, 400, 'Provide a question.');
  try {
    const out = await chatWithNotebookMode({
      userKey,
      notebookId: req.params.id,
      question: parsed.data.question,
      mode: parsed.data.mode,
      allowAutoFailover: parsed.data.allowAutoFailover,
    });
    return res.json(out);
  } catch (err) {
    return sendError(res, 400, (err as Error)?.message || 'Chat failed.');
  }
});

apiRouter.get('/studio/notebooks/:id/chat-history', optionalAuth, (req: AuthRequest, res) => {
  const userKey = req.user?.uid || 'guest';
  return res.json({ history: getChatHistory(userKey, req.params.id) });
});

apiRouter.delete('/studio/notebooks/:id/chat-history', optionalAuth, (req: AuthRequest, res) => {
  const userKey = req.user?.uid || 'guest';
  clearChatHistory(userKey, req.params.id);
  return res.json({ cleared: true });
});

apiRouter.post('/studio/notebooks/:id/generate', optionalAuth, async (req: AuthRequest, res) => {
  const userKey = req.user?.uid || 'guest';
  const schema = z.object({
    type: z.enum(ARTIFACT_TYPES as [ArtifactType, ...ArtifactType[]]),
    instructions: z.string().max(2000).optional(),
    allowAutoFailover: z.boolean().optional(),
  });
  const parsed = schema.safeParse(req.body || {});
  if (!parsed.success) return sendError(res, 400, 'Invalid artifact type.');
  try {
    const art = await generateArtifactCustom({
      userKey,
      notebookId: req.params.id,
      type: parsed.data.type,
      instructions: parsed.data.instructions,
      allowAutoFailover: parsed.data.allowAutoFailover,
    });
    return res.json({ artifact: art });
  } catch (err) {
    return sendError(res, 400, (err as Error)?.message || 'Generation failed.');
  }
});

apiRouter.get('/studio/notebooks/:id/artifacts', optionalAuth, (req: AuthRequest, res) => {
  const userKey = req.user?.uid || 'guest';
  return res.json({ artifacts: listArtifacts(userKey, req.params.id) });
});

apiRouter.get('/studio/notebooks/:id/artifacts/:artifactId', optionalAuth, (req: AuthRequest, res) => {
  const userKey = req.user?.uid || 'guest';
  const art = getArtifact(userKey, req.params.id, req.params.artifactId);
  if (!art) return sendError(res, 404, 'Artifact not found.');
  return res.json({ artifact: art });
});

apiRouter.delete('/studio/notebooks/:id/artifacts/:artifactId', optionalAuth, (req: AuthRequest, res) => {
  const userKey = req.user?.uid || 'guest';
  const ok = deleteArtifact(userKey, req.params.id, req.params.artifactId);
  if (!ok) return sendError(res, 404, 'Artifact not found.');
  return res.json({ deleted: true });
});

apiRouter.post('/studio/notebooks/:id/notes', optionalAuth, (req: AuthRequest, res) => {
  const userKey = req.user?.uid || 'guest';
  const schema = z.object({
    title: z.string().max(200).optional(),
    content: z.string().min(1).max(50000),
    source: z.enum(['user', 'chat', 'artifact']).optional(),
  });
  const parsed = schema.safeParse(req.body || {});
  if (!parsed.success) return sendError(res, 400, 'Invalid note payload.');
  try {
    const note = createNote(userKey, req.params.id, parsed.data);
    return res.json({ note });
  } catch (err) {
    return sendError(res, 400, (err as Error)?.message || 'Failed to create note.');
  }
});

apiRouter.get('/studio/notebooks/:id/notes', optionalAuth, (req: AuthRequest, res) => {
  const userKey = req.user?.uid || 'guest';
  return res.json({ notes: listNotes(userKey, req.params.id) });
});

apiRouter.patch('/studio/notebooks/:id/notes/:noteId', optionalAuth, (req: AuthRequest, res) => {
  const userKey = req.user?.uid || 'guest';
  const schema = z.object({ title: z.string().max(200).optional(), content: z.string().max(50000).optional() });
  const parsed = schema.safeParse(req.body || {});
  if (!parsed.success) return sendError(res, 400, 'Invalid note payload.');
  const note = updateNote(userKey, req.params.id, req.params.noteId, parsed.data);
  if (!note) return sendError(res, 404, 'Note not found.');
  return res.json({ note });
});

apiRouter.delete('/studio/notebooks/:id/notes/:noteId', optionalAuth, (req: AuthRequest, res) => {
  const userKey = req.user?.uid || 'guest';
  const ok = deleteNote(userKey, req.params.id, req.params.noteId);
  if (!ok) return sendError(res, 404, 'Note not found.');
  return res.json({ deleted: true });
});

apiRouter.post('/studio/notebooks/:id/notes/:noteId/to-source', optionalAuth, async (req: AuthRequest, res) => {
  const userKey = req.user?.uid || 'guest';
  try {
    const src = await noteToSource(userKey, req.params.id, req.params.noteId);
    if (!src) return sendError(res, 404, 'Note not found.');
    return res.json({ source: src });
  } catch (err) {
    return sendError(res, 400, (err as Error)?.message || 'Failed to convert note.');
  }
});

apiRouter.post('/studio/notebooks/:id/deep-research', optionalAuth, async (req: AuthRequest, res) => {
  const userKey = req.user?.uid || 'guest';
  const schema = z.object({
    topic: z.string().min(2).max(300),
    maxSources: z.number().int().min(3).max(12).optional(),
    importToNotebook: z.boolean().optional(),
    allowAutoFailover: z.boolean().optional(),
  });
  const parsed = schema.safeParse(req.body || {});
  if (!parsed.success) return sendError(res, 400, 'Invalid deep research payload.');
  try {
    const out = await deepResearch({
      userKey,
      notebookId: parsed.data.importToNotebook ? req.params.id : undefined,
      topic: parsed.data.topic,
      maxSources: parsed.data.maxSources,
      allowAutoFailover: parsed.data.allowAutoFailover,
    });
    return res.json(out);
  } catch (err) {
    return sendError(res, 500, (err as Error)?.message || 'Deep research failed.');
  }
});

apiRouter.post('/studio/notebooks/:id/summarize', optionalAuth, async (req: AuthRequest, res) => {
  const userKey = req.user?.uid || 'guest';
  const schema = z.object({ allowAutoFailover: z.boolean().optional() });
  const parsed = schema.safeParse(req.body || {});
  if (!parsed.success) return sendError(res, 400, 'Invalid payload.');
  try {
    const out = await summarizeNotebook({ userKey, notebookId: req.params.id, allowAutoFailover: parsed.data.allowAutoFailover });
    return res.json(out);
  } catch (err) {
    return sendError(res, 400, (err as Error)?.message || 'Summarization failed.');
  }
});

apiRouter.get('/studio/notebooks/:id/export', optionalAuth, (req: AuthRequest, res) => {
  const userKey = req.user?.uid || 'guest';
  const md = exportNotebookMarkdown(userKey, req.params.id);
  if (!md) return sendError(res, 404, 'Notebook not found.');
  res.setHeader('Content-Type', 'text/markdown; charset=utf-8');
  return res.send(md);
});

apiRouter.get('/studio/artifact-types', optionalAuth, (_req, res) => {
  return res.json({ types: ARTIFACT_TYPES });
});

// 14. B.A.R.B.I. OS v4.0 — 55-Module Sovereign Stack & Live GitHub Integration Bus
apiRouter.get('/v4/modules', optionalAuth, (_req, res) => {
  try {
    return res.json(getV4CatalogSnapshot());
  } catch (err) {
    return sendError(res, 500, (err as Error)?.message || 'Failed to load v4.0 module catalog.');
  }
});

apiRouter.post('/v4/modules/:id/sync-github', optionalAuth, async (req, res) => {
  const moduleId = Number(req.params.id);
  if (!Number.isInteger(moduleId) || moduleId < 1 || moduleId > 55) {
    return sendError(res, 400, 'Invalid v4.0 module ID (expected 1-55).');
  }
  try {
    const force = req.body?.force !== false;
    const out = await syncModuleFromGitHub(moduleId, force);
    return res.json(out);
  } catch (err) {
    return sendError(res, 502, (err as Error)?.message || 'Live GitHub sync failed.');
  }
});

apiRouter.post('/v4/modules/sync-pack', optionalAuth, async (req, res) => {
  const schema = z.object({
    packId: z
      .enum([
        'pack-1-core',
        'pack-2-fintech',
        'pack-3-spatial',
        'pack-4-factory',
        'pack-5-embodiment',
        'pack-6-intel',
      ])
      .optional(),
    tier: z.enum(['A', 'B', 'C', 'D', 'E', 'F']).optional(),
    maxModules: z.number().int().min(1).max(20).optional(),
  });
  const parsed = schema.safeParse(req.body || {});
  if (!parsed.success) return sendError(res, 400, 'Invalid batch GitHub sync parameters.');
  try {
    const out = await syncPackOrTierFromGitHub(parsed.data);
    return res.json(out);
  } catch (err) {
    return sendError(res, 502, (err as Error)?.message || 'Batch GitHub sync failed.');
  }
});

apiRouter.post('/v4/modules/:id/mount', optionalAuth, (req, res) => {
  const moduleId = Number(req.params.id);
  if (!Number.isInteger(moduleId) || moduleId < 1 || moduleId > 55) {
    return sendError(res, 400, 'Invalid v4.0 module ID.');
  }
  const schema = z.object({
    requestedMode: z.enum(['PAPER_SANDBOX', 'LIVE_APPROVED', 'NATIVE_RUNTIME']).optional(),
    approvalConfirmed: z.boolean().optional(),
    approvedBy: z.string().max(120).optional(),
  });
  const parsed = schema.safeParse(req.body || {});
  if (!parsed.success) return sendError(res, 400, 'Invalid mount payload.');
  try {
    const out = mountV4Module({ moduleId, ...parsed.data });
    return res.json(out);
  } catch (err) {
    return sendError(res, 500, (err as Error)?.message || 'Failed to mount module.');
  }
});

apiRouter.post('/v4/modules/:id/unmount', optionalAuth, (req, res) => {
  const moduleId = Number(req.params.id);
  if (!Number.isInteger(moduleId) || moduleId < 1 || moduleId > 55) {
    return sendError(res, 400, 'Invalid v4.0 module ID.');
  }
  try {
    return res.json(unmountV4Module(moduleId));
  } catch (err) {
    return sendError(res, 500, (err as Error)?.message || 'Failed to unmount module.');
  }
});

apiRouter.post('/v4/packs/:packId/mount', optionalAuth, (req, res) => {
  const packSchema = z.enum([
    'pack-1-core',
    'pack-2-fintech',
    'pack-3-spatial',
    'pack-4-factory',
    'pack-5-embodiment',
    'pack-6-intel',
  ]);
  const packParsed = packSchema.safeParse(req.params.packId);
  if (!packParsed.success) return sendError(res, 400, 'Invalid starter pack ID.');
  try {
    const approvalConfirmed = Boolean(req.body?.approvalConfirmed);
    return res.json(mountStarterPack(packParsed.data, approvalConfirmed));
  } catch (err) {
    return sendError(res, 500, (err as Error)?.message || 'Failed to mount starter pack.');
  }
});

apiRouter.post('/v4/github/search', optionalAuth, async (req, res) => {
  const schema = z.object({ query: z.string().min(2).max(120) });
  const parsed = schema.safeParse(req.body || {});
  if (!parsed.success) return sendError(res, 400, 'Provide a search query of at least 2 characters.');
  try {
    const out = await searchGitHubForAssimilation(parsed.data.query);
    return res.json(out);
  } catch (err) {
    return sendError(res, 502, (err as Error)?.message || 'Live GitHub search failed.');
  }
});

apiRouter.post('/v4/github/assimilate', optionalAuth, (req, res) => {
  const schema = z.object({
    fullName: z.string().min(3).max(160),
    htmlUrl: z.string().max(300).optional(),
    description: z.string().max(600).default(''),
    stars: z.number().min(0).default(0),
    language: z.string().max(64).default('Unknown'),
    license: z.string().max(64).default('Unknown'),
    tier: z.enum(['A', 'B', 'C', 'D', 'E', 'F']).default('A'),
    governanceTier: z.enum(['PRE_AUTHORIZED', 'CAPITAL_GATE']).default('PRE_AUTHORIZED'),
    securityStatus: z.enum(['VERIFIED', 'CAUTION', 'UNVERIFIED']).default('VERIFIED'),
  });
  const parsed = schema.safeParse(req.body || {});
  if (!parsed.success) return sendError(res, 400, 'Invalid GitHub assimilation payload.');
  try {
    const out = assimilateCustomGitHubRepo({
      ...parsed.data,
      htmlUrl: parsed.data.htmlUrl || `https://github.com/${parsed.data.fullName}`,
    });
    return res.status(201).json(out);
  } catch (err) {
    return sendError(res, 400, (err as Error)?.message || 'Failed to assimilate repository.');
  }
});

apiRouter.delete('/v4/github/assimilate/:id', optionalAuth, (req, res) => {
  try {
    return res.json(removeAssimilatedRepo(String(req.params.id || '')));
  } catch (err) {
    return sendError(res, 500, (err as Error)?.message || 'Failed to remove assimilated repo.');
  }
});

apiRouter.post('/v4/fintech/execution-mode', optionalAuth, (req, res) => {
  const schema = z.object({
    railId: z.string().min(2).max(64),
    targetMode: z.enum(['PAPER_SANDBOX', 'LIVE_APPROVED']),
    approvalConfirmed: z.boolean().default(false),
    riskCapNote: z.string().max(200).optional(),
  });
  const parsed = schema.safeParse(req.body || {});
  if (!parsed.success) return sendError(res, 400, 'Invalid FinTech execution-mode payload.');
  try {
    return res.json(setFinTechRailMode(parsed.data));
  } catch (err) {
    return sendError(res, 400, (err as Error)?.message || 'Failed to update FinTech rail mode.');
  }
});

apiRouter.post('/v4/export-stack', optionalAuth, (req, res) => {
  const schema = z.object({
    pack: z
      .enum([
        'pack-1-core',
        'pack-2-fintech',
        'pack-3-spatial',
        'pack-4-factory',
        'pack-5-embodiment',
        'pack-6-intel',
        'mounted',
        'all',
      ])
      .default('pack-1-core'),
    companyName: z.string().min(2).max(120).optional(),
  });
  const parsed = schema.safeParse(req.body || {});
  if (!parsed.success) return sendError(res, 400, 'Invalid stack export specification.');
  try {
    return res.json(exportDeploymentStack(parsed.data));
  } catch (err) {
    return sendError(res, 500, (err as Error)?.message || 'Failed to export deployment stack.');
  }
});

// 18. God's Eye Live Spatial OSINT Aggregator (Module M11)
apiRouter.get('/gods-eye/feeds', optionalAuth, async (req, res) => {
  try {
    const forceRefresh = req.query.refresh === '1' || req.query.refresh === 'true';
    const snapshot = await fetchGodsEyeFeedsSnapshot(forceRefresh);
    return res.json(snapshot);
  } catch (err) {
    return sendError(res, 502, (err as Error)?.message || 'Failed to load God\'s Eye OSINT feeds.');
  }
});

// 19. File System Agent — Scoped Local File Analysis & Diff Proposal Endpoint
apiRouter.post('/fs-agent/analyze', optionalAuth, async (req, res) => {
  const schema = z.object({
    rootName: z.string().min(1).max(160),
    mode: z.enum(['analyze', 'modify']).default('analyze'),
    instruction: z.string().min(1).max(2000),
    projectTree: z.string().max(24000).default(''),
    selectedFiles: z
      .array(
        z.object({
          path: z.string().min(1).max(320),
          content: z.string().max(120000),
          language: z.string().max(40).optional(),
        })
      )
      .min(1)
      .max(15),
  });

  const parsed = schema.safeParse(req.body || {});
  if (!parsed.success) {
    return sendError(res, 400, 'Invalid File System Agent payload.', parsed.error.flatten());
  }

  for (const file of parsed.data.selectedFiles) {
    if (file.path.includes('..') || file.path.startsWith('/')) {
      return sendError(res, 400, `Unsafe relative path rejected: ${file.path}`);
    }
  }

  try {
    const result = await runFsAgentAnalysis(parsed.data);
    return res.json(result);
  } catch (err) {
    return sendError(res, 502, (err as Error)?.message || 'File System Agent analysis failed.');
  }
});



