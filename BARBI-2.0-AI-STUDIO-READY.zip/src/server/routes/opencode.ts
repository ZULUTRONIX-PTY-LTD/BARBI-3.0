import { Router, type Response } from 'express';
import { z } from 'zod';
import path from 'node:path';
import fs from 'node:fs/promises';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { optionalAuth, type AuthRequest } from '../../middleware/auth.ts';
import {
  closeOpenCodeEngine,
  createOpenCodeSession,
  getOpenCodeMessages,
  getOpenCodeStatus,
  listOpenCodeSessions,
  promptOpenCodeSession,
  subscribeOpenCodeEvents,
} from '../opencode/opencodeService.ts';
import { fetchGodsEyeFeedsSnapshot } from '../v4/godsEyeService.ts';
import { createNotebook, listNotebooks, chatWithNotebookMode, summarizeNotebook } from '../studio/notebookLmService.ts';
import { generateNotebookStudyPack } from '../studio/studyStudioService.ts';
import { testDbConnection } from '../../db/index.ts';
import { hasConfiguredGeminiKey } from '../ai/geminiService.ts';
import {
  getSocialAgentSummary,
  listSocialMessages,
  sendSocialMessage,
  pollTelegramInbox,
  resolveApproval,
  listApprovals,
  upsertAutomationRule,
  deleteAutomationRule,
} from '../social/socialAgentService.ts';

export const opencodeRouter = Router();

const WORKSPACE_ROOT = path.resolve(process.cwd());
const execFileAsync = promisify(execFile);
const CONSOLE_COMMANDS: Record<string, string[]> = {
  lint: ['run', 'lint'],
  build: ['run', 'build'],
  test: ['test'],
};

function safeResolve(relative: string): string | null {
  const abs = path.resolve(WORKSPACE_ROOT, relative || '.');
  return abs === WORKSPACE_ROOT || abs.startsWith(WORKSPACE_ROOT + path.sep) ? abs : null;
}

function sendError(res: Response, status: number, message: string, details?: unknown) {
  return res.status(status).json({ error: message, ...(details ? { details } : {}) });
}

function assertSafeDirectory(input?: string): string {
  const dir = input ? path.resolve(WORKSPACE_ROOT, input) : WORKSPACE_ROOT;
  if (dir !== WORKSPACE_ROOT && !dir.startsWith(WORKSPACE_ROOT + path.sep)) {
    throw new Error('Directory must be inside the B.A.R.B.I workspace');
  }
  return dir;
}

const SessionCreateSchema = z.object({
  title: z.string().max(160).optional(),
  directory: z.string().max(400).optional(),
});
const PromptSchema = z.object({
  text: z.string().min(1).max(60_000),
  sessionID: z.string().optional(),
});

opencodeRouter.use(optionalAuth);

// Status / diagnostics
opencodeRouter.get('/status', async (_req, res) => {
  return res.json(await getOpenCodeStatus());
});

// Sessions
opencodeRouter.get('/sessions', async (_req, res) => {
  try {
    return res.json({ sessions: await listOpenCodeSessions() });
  } catch (err) {
    return sendError(res, 500, 'Unable to list OpenCode sessions', err instanceof Error ? err.message : String(err));
  }
});

opencodeRouter.post('/sessions', async (req, res) => {
  const parsed = SessionCreateSchema.safeParse(req.body);
  if (!parsed.success) return sendError(res, 400, 'Invalid session request', parsed.error.flatten());
  try {
    const directory = assertSafeDirectory(parsed.data.directory);
    const session = await createOpenCodeSession({ title: parsed.data.title, directory });
    return res.status(201).json({ session });
  } catch (err) {
    return sendError(res, 500, 'Unable to create OpenCode session', err instanceof Error ? err.message : String(err));
  }
});

opencodeRouter.post('/sessions/:id/prompt', async (req, res) => {
  const parsed = PromptSchema.safeParse(req.body);
  if (!parsed.success) return sendError(res, 400, 'Invalid prompt', parsed.error.flatten());
  try {
    const result = await promptOpenCodeSession({
      sessionID: parsed.data.sessionID || String(req.params.id),
      text: parsed.data.text,
    });
    return res.json({ result });
  } catch (err) {
    return sendError(res, 500, 'OpenCode prompt failed', err instanceof Error ? err.message : String(err));
  }
});

opencodeRouter.get('/sessions/:id/messages', async (req, res) => {
  try {
    return res.json({ messages: await getOpenCodeMessages(String(req.params.id)) });
  } catch (err) {
    return sendError(res, 500, 'Unable to read OpenCode messages', err instanceof Error ? err.message : String(err));
  }
});

// Live event stream (SSE)
opencodeRouter.get('/events', async (_req: AuthRequest, res) => {
  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache, no-transform');
  res.setHeader('Connection', 'keep-alive');
  res.flushHeaders?.();

  const heartbeat = setInterval(() => res.write(': keep-alive\n\n'), 15_000);
  let unsubscribe: () => void = () => undefined;
  try {
    unsubscribe = await subscribeOpenCodeEvents((event) => {
      res.write(`data: ${JSON.stringify(event)}\n\n`);
    });
  } catch {
    res.write(`data: ${JSON.stringify({ type: 'opencode.unavailable' })}\n\n`);
  }

  const cleanup = () => {
    clearInterval(heartbeat);
    unsubscribe();
  };
  req.on('close', cleanup);
  res.on('close', cleanup);
});

// ---------------------------------------------------------------- MCP catalog
const MCP_TOOLS = [
  'barbi_health',
  'barbi_provider_status',
  'barbi_system_telemetry',
  'barbi_workspace_tree',
  'barbi_read_file',
  'barbi_write_file',
  'barbi_run_command',
  'barbi_list_conversations',
  'barbi_get_conversation',
  'barbi_notebook_list',
  'barbi_notebook_create',
  'barbi_notebook_get',
  'barbi_notebook_delete',
  'barbi_notebook_add_source',
  'barbi_notebook_chat',
  'barbi_notebook_summarize',
  'barbi_notebook_chat_history',
  'barbi_notebook_discover_sources',
  'barbi_notebook_deep_research',
  'barbi_notebook_artifact_types',
  'barbi_notebook_generate_artifact',
  'barbi_notebook_list_artifacts',
  'barbi_notebook_get_artifact',
  'barbi_notebook_export',
  'barbi_notes',
  'barbi_note_create',
  'barbi_note_to_source',
  'barbi_generate_study_pack',
  'barbi_gods_eye_feeds',
  'barbi_social_summary',
  'barbi_social_messages',
  'barbi_social_send',
  'barbi_social_poll',
  'barbi_social_approvals',
  'barbi_social_resolve_approval',
  'barbi_social_save_rule',
  'barbi_social_delete_rule',
] as const;

opencodeRouter.get('/mcp/tools', (_req, res) => {
  return res.json({ server: 'barbi', transport: 'stdio', tools: MCP_TOOLS });
});

const McpCallSchema = z.object({
  tool: z.string().min(1),
  input: z.record(z.unknown()).default({}),
});

opencodeRouter.post('/mcp/call', async (req, res) => {
  const parsed = McpCallSchema.safeParse(req.body);
  if (!parsed.success) return sendError(res, 400, 'Invalid MCP call', parsed.error.flatten());
  const { tool, input } = parsed.data;
  try {
    switch (tool) {
      case 'barbi_health':
        return res.json({ result: { ok: await testDbConnection(), service: 'B.A.R.B.I 2.0 PIOS Engine', geminiConfigured: hasConfiguredGeminiKey(), timestamp: new Date().toISOString() } });
      case 'barbi_provider_status': {
        const { getProviderQuotaSnapshot } = await import('../ai/providerRegistry.ts');
        return res.json({ result: getProviderQuotaSnapshot('mcp-console') });
      }
      case 'barbi_system_telemetry': {
        const os = await import('node:os');
        const total = os.totalmem();
        const free = os.freemem();
        return res.json({ result: {
          platform: os.platform(),
          arch: os.arch(),
          cpus: os.cpus().length,
          memoryUsedPct: Math.round(((total - free) / Math.max(1, total)) * 100),
          uptimeSeconds: os.uptime(),
          loadAvg: os.loadavg(),
        } });
      }
      case 'barbi_workspace_tree': {
        const dir = safeResolve(String(input.subPath || input.path || '.'));
        if (!dir) return sendError(res, 403, 'Directory must be inside the B.A.R.B.I workspace');
        const entries = await fs.readdir(dir, { withFileTypes: true });
        return res.json({ result: entries
          .filter((entry) => !['node_modules', 'target', '.git', 'dist'].includes(entry.name))
          .map((entry) => ({ name: entry.name, type: entry.isDirectory() ? 'directory' : 'file' })) });
      }
      case 'barbi_read_file': {
        const file = safeResolve(String(input.path || ''));
        if (!file) return sendError(res, 403, 'Path must be inside the B.A.R.B.I workspace');
        const content = await fs.readFile(file, 'utf8');
        return res.json({ result: { path: String(input.path), content: content.slice(0, 200_000) } });
      }
      case 'barbi_write_file': {
        if (!req.user) return sendError(res, 401, 'Sign in to use direct file writes');
        const file = safeResolve(String(input.path || ''));
        if (!file) return sendError(res, 403, 'Path must be inside the B.A.R.B.I workspace');
        const content = String(input.content || '');
        if (Buffer.byteLength(content) > 1_000_000) return sendError(res, 413, 'File content exceeds 1 MB console limit');
        await fs.mkdir(path.dirname(file), { recursive: true });
        await fs.writeFile(file, content, 'utf8');
        return res.json({ result: { written: String(input.path), bytes: Buffer.byteLength(content) } });
      }
      case 'barbi_run_command': {
        const command = String(input.command || '');
        const args = CONSOLE_COMMANDS[command];
        if (!args) return sendError(res, 400, 'Allowed console commands: lint, build, test');
        try {
          const { stdout, stderr } = await execFileAsync('npm', args, {
            cwd: WORKSPACE_ROOT,
            timeout: 300_000,
            maxBuffer: 24 * 1024 * 1024,
            env: { ...process.env, ...(process.platform === 'win32' ? { PATH: `C:\\Program Files\\nodejs;${process.env.PATH || ''}` } : {}) },
          });
          return res.json({ result: { command, exitCode: 0, stdout: stdout.slice(-20_000), stderr: stderr.slice(-20_000) } });
        } catch (err) {
          const e = err as { stdout?: string; stderr?: string; message?: string };
          return res.json({ result: { command, exitCode: 1, stdout: (e.stdout || '').slice(-20_000), stderr: (e.stderr || e.message || '').slice(-20_000) } });
        }
      }
      case 'barbi_notebook_list':
        return res.json({ result: { notebooks: listNotebooks((req as AuthRequest).user?.uid || 'web') } });
      case 'barbi_notebook_create':
        return res.json({ result: { notebook: createNotebook((req as AuthRequest).user?.uid || 'web', String(input.title || 'Untitled notebook')) } });
      case 'barbi_notebook_chat':
        return res.json({ result: await chatWithNotebookMode({
          userKey: (req as AuthRequest).user?.uid || 'web',
          notebookId: String(input.notebookId || ''),
          question: String(input.question || ''),
          mode: (input.mode as 'default' | 'learning_guide' | 'brief' | 'detailed') || 'default',
        }) });
      case 'barbi_notebook_summarize':
        return res.json({ result: await summarizeNotebook((req as AuthRequest).user?.uid || 'web', String(input.notebookId || '')) });
      case 'barbi_generate_study_pack':
        return res.json({ result: await generateNotebookStudyPack({
          topicTitle: String(input.topicTitle || ''),
          sourceMaterial: String(input.sourceMaterial || ''),
        }) });
      case 'barbi_gods_eye_feeds':
        return res.json({ result: await fetchGodsEyeFeedsSnapshot(Boolean(input.forceRefresh)) });
      case 'barbi_social_summary':
        return res.json({ result: await getSocialAgentSummary() });
      case 'barbi_social_messages':
        return res.json({ result: await listSocialMessages({
          platform: input.platform as any,
          limit: typeof input.limit === 'number' ? input.limit : 50,
        }) });
      case 'barbi_social_send':
        return res.json({ result: await sendSocialMessage({
          platform: input.platform as any,
          threadId: String(input.threadId || ''),
          text: String(input.text || ''),
        }) });
      case 'barbi_social_poll':
        return res.json({ result: await pollTelegramInbox() });
      case 'barbi_social_approvals':
        return res.json({ result: await listApprovals() });
      case 'barbi_social_resolve_approval':
        return res.json({ result: await resolveApproval({
          id: String(input.id || ''),
          approve: Boolean(input.approve),
          editedText: input.editedText ? String(input.editedText) : undefined,
        }) });
      case 'barbi_social_save_rule':
        return res.json({ result: { rule: await upsertAutomationRule(input as any) } });
      case 'barbi_social_delete_rule':
        return res.json({ result: { ok: await deleteAutomationRule(String(input.id || '')) } });
      default:
        return sendError(res, 404, `MCP tool '${tool}' is registered but must be called through the OpenCode agent`);
    }
  } catch (err) {
    return sendError(res, 500, 'MCP call failed', err instanceof Error ? err.message : String(err));
  }
});

opencodeRouter.post('/engine/close', async (_req, res) => {
  await closeOpenCodeEngine();
  return res.json({ closed: true });
});
