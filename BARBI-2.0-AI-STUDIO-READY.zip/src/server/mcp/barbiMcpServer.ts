/**
 * B.A.R.B.I MCP Server
 * --------------------
 * Exposes B.A.R.B.I capabilities as Model Context Protocol tools so OpenCode
 * (TUI, desktop, or the embedded agent) can drive the whole operating system.
 *
 * Runs over stdio and is registered in `opencode.jsonc` as `mcp.servers.barbi`.
 */
import 'dotenv/config';
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { z } from 'zod';
import { McpServer } from '@modelcontextprotocol/sdk/server/mcp.js';
import { StdioServerTransport } from '@modelcontextprotocol/sdk/server/stdio.js';
import { testDbConnection } from '../../db/index.ts';
import { hasConfiguredGeminiKey } from '../ai/geminiService.ts';
import { getProviderQuotaSnapshot } from '../ai/providerRegistry.ts';
import { fetchGodsEyeFeedsSnapshot } from '../v4/godsEyeService.ts';
import {
  createNotebook,
  listNotebooks,
  getNotebook,
  deleteNotebook,
  addSource,
  removeSource,
  discoverSources,
  chatWithNotebook,
  getChatHistory,
  generateArtifact,
  listArtifacts,
  getArtifact,
  deleteArtifact,
  createNote,
  listNotes,
  updateNote,
  deleteNote,
  noteToSource,
  deepResearch,
  chatWithNotebookMode,
  summarizeNotebook,
  exportNotebookMarkdown,
  generateArtifactCustom,
  ARTIFACT_TYPES,
} from '../studio/notebookLmService.ts';
import { generateNotebookStudyPack } from '../studio/studyStudioService.ts';
import { listConversations, getConversationMessages } from '../archivex/repository.ts';
import {
  getSocialAgentSummary,
  listSocialMessages,
  sendSocialMessage,
  pollTelegramInbox,
  resolveApproval,
  listApprovals,
  upsertAutomationRule,
  deleteAutomationRule,
} from '../social/socialAgentService.ts';

const execFileAsync = promisify(execFile);
const __filename = fileURLToPath(import.meta.url);
const WORKSPACE_ROOT = path.resolve(path.dirname(__filename), '..', '..', '..');

function ok(payload: unknown) {
  return { content: [{ type: 'text' as const, text: JSON.stringify(payload, null, 2) }] };
}
function fail(message: string) {
  return { content: [{ type: 'text' as const, text: `ERROR: ${message}` }], isError: true };
}
function safeResolve(relative: string): string | null {
  const abs = path.resolve(WORKSPACE_ROOT, relative || '.');
  return abs === WORKSPACE_ROOT || abs.startsWith(WORKSPACE_ROOT + path.sep) ? abs : null;
}

const server = new McpServer({
  name: 'barbi',
  version: '2.0.0',
});

// ---------------------------------------------------------------- System
server.registerTool(
  'barbi_health',
  { description: 'Check B.A.R.B.I engine, database and AI provider health.' },
  async () => {
    const dbOk = await testDbConnection();
    return ok({
      ok: dbOk,
      service: 'B.A.R.B.I 2.0 PIOS Engine',
      database: dbOk ? 'postgresql+pgvector' : 'disconnected',
      geminiConfigured: hasConfiguredGeminiKey(),
      timestamp: new Date().toISOString(),
    });
  }
);

server.registerTool(
  'barbi_provider_status',
  { description: 'List configured AI providers, quotas and routing state.' },
  async () => ok(getProviderQuotaSnapshot('mcp'))
);

server.registerTool(
  'barbi_system_telemetry',
  { description: 'Read live host CPU, memory and process telemetry.' },
  async () => {
    const os = await import('node:os');
    const total = os.totalmem();
    const free = os.freemem();
    return ok({
      platform: os.platform(),
      arch: os.arch(),
      cpus: os.cpus().length,
      memoryUsedPct: Math.round(((total - free) / Math.max(1, total)) * 100),
      uptimeSeconds: os.uptime(),
      loadAvg: os.loadavg(),
    });
  }
);

// ---------------------------------------------------------------- Workspace
server.registerTool(
  'barbi_workspace_tree',
  {
    description: 'List files in the B.A.R.B.I workspace (relative paths only, node_modules/target excluded).',
    inputSchema: { subPath: z.string().optional().describe('Relative directory, defaults to root') },
  },
  async ({ subPath }) => {
    const root = safeResolve(subPath || '.');
    if (!root) return fail('Path escapes workspace root');
    try {
      const entries = await fs.readdir(root, { withFileTypes: true });
      return ok(
        entries
          .filter((e) => !['node_modules', 'target', '.git', 'dist'].includes(e.name))
          .map((e) => ({ name: e.name, type: e.isDirectory() ? 'directory' : 'file' }))
      );
    } catch (err) {
      return fail(err instanceof Error ? err.message : String(err));
    }
  }
);

server.registerTool(
  'barbi_read_file',
  {
    description: 'Read a text file inside the B.A.R.B.I workspace.',
    inputSchema: { path: z.string().describe('Workspace-relative file path') },
  },
  async ({ path: filePath }) => {
    const abs = safeResolve(filePath);
    if (!abs) return fail('Path escapes workspace root');
    try {
      return ok({ path: filePath, content: await fs.readFile(abs, 'utf8') });
    } catch (err) {
      return fail(err instanceof Error ? err.message : String(err));
    }
  }
);

server.registerTool(
  'barbi_write_file',
  {
    description: 'Write a text file inside the B.A.R.B.I workspace (full workspace access).',
    inputSchema: {
      path: z.string().describe('Workspace-relative file path'),
      content: z.string().describe('Full file contents'),
    },
  },
  async ({ path: filePath, content }) => {
    const abs = safeResolve(filePath);
    if (!abs) return fail('Path escapes workspace root');
    try {
      await fs.mkdir(path.dirname(abs), { recursive: true });
      await fs.writeFile(abs, content, 'utf8');
      return ok({ written: filePath, bytes: Buffer.byteLength(content) });
    } catch (err) {
      return fail(err instanceof Error ? err.message : String(err));
    }
  }
);

const ALLOWED_COMMANDS: Record<string, string[]> = {
  lint: ['npm', ['run', 'lint']],
  build: ['npm', ['run', 'build']],
  test: ['npm', ['test']],
};

server.registerTool(
  'barbi_run_command',
  {
    description: 'Run an allowlisted B.A.R.B.I verification command (lint, build, test).',
    inputSchema: { command: z.enum(['lint', 'build', 'test']) },
  },
  async ({ command }) => {
    const entry = ALLOWED_COMMANDS[command];
    if (!entry) return fail('Unknown command');
    try {
      const { stdout, stderr } = await execFileAsync(entry[0], entry[1], {
        cwd: WORKSPACE_ROOT,
        timeout: 300_000,
        env: { ...process.env, ...(process.platform === 'win32' ? { PATH: `C:\\Program Files\\nodejs;${process.env.PATH || ''}` } : {}) },
      });
      return ok({ command, exitCode: 0, stdout: stdout.slice(-20000), stderr: stderr.slice(-20000) });
    } catch (err) {
      const e = err as { stdout?: string; stderr?: string; message?: string };
      return ok({ command, exitCode: 1, stdout: (e.stdout || '').slice(-20000), stderr: (e.stderr || e.message || '').slice(-20000) });
    }
  }
);

// ---------------------------------------------------------------- Chat history
server.registerTool(
  'barbi_list_conversations',
  {
    description: 'List archived conversations for a user.',
    inputSchema: { userId: z.string().describe('Firebase user UID') },
  },
  async ({ userId }) => ok(await listConversations(userId))
);

server.registerTool(
  'barbi_get_conversation',
  {
    description: 'Read messages from one archived conversation.',
    inputSchema: { userId: z.string(), conversationId: z.string() },
  },
  async ({ userId, conversationId }) => ok(await getConversationMessages(userId, conversationId))
);

// ---------------------------------------------------------------- NotebookLM
server.registerTool(
  'barbi_notebook_list',
  { description: 'List all study notebooks for a user.' },
  async () => ok(listNotebooks('mcp'))
);

server.registerTool(
  'barbi_notebook_create',
  {
    description: 'Create a new study notebook.',
    inputSchema: { title: z.string() },
  },
  async ({ title }) => ok(createNotebook('mcp', title))
);

server.registerTool(
  'barbi_notebook_get',
  {
    description: 'Get a notebook with its sources and metadata.',
    inputSchema: { notebookId: z.string() },
  },
  async ({ notebookId }) => ok(getNotebook('mcp', notebookId) ?? fail('Notebook not found'))
);

server.registerTool(
  'barbi_notebook_delete',
  {
    description: 'Delete a notebook.',
    inputSchema: { notebookId: z.string() },
  },
  async ({ notebookId }) => ok({ deleted: deleteNotebook('mcp', notebookId) })
);

server.registerTool(
  'barbi_notebook_add_source',
  {
    description: 'Add a text/URL/YouTube source to a notebook.',
    inputSchema: {
      notebookId: z.string(),
      title: z.string(),
      content: z.string().describe('Raw text, URL, or YouTube link'),
      sourceType: z.enum(['text', 'url', 'youtube', 'pdf', 'audio', 'doc']).default('text'),
    },
  },
  async ({ notebookId, title, content, sourceType }) => {
    try {
      return ok(await addSource('mcp', notebookId, { title, content, type: sourceType }));
    } catch (err) {
      return fail(err instanceof Error ? err.message : String(err));
    }
  }
);

server.registerTool(
  'barbi_notebook_chat',
  {
    description: 'Ask a grounded question about the checked sources in a notebook.',
    inputSchema: { notebookId: z.string(), question: z.string(), mode: z.enum(['default', 'learning_guide', 'brief', 'detailed']).default('default') },
  },
  async ({ notebookId, question, mode }) => {
    try {
      return ok(await chatWithNotebookMode({ userKey: 'mcp', notebookId, question, mode }));
    } catch (err) {
      return fail(err instanceof Error ? err.message : String(err));
    }
  }
);

server.registerTool(
  'barbi_notebook_summarize',
  {
    description: 'Summarize all sources in a notebook.',
    inputSchema: { notebookId: z.string() },
  },
  async ({ notebookId }) => ok(await summarizeNotebook('mcp', notebookId))
);

server.registerTool(
  'barbi_notebook_chat_history',
  {
    description: 'Read the chat history of a notebook.',
    inputSchema: { notebookId: z.string() },
  },
  async ({ notebookId }) => ok(getChatHistory('mcp', notebookId))
);

server.registerTool(
  'barbi_notebook_discover_sources',
  {
    description: 'Search the web for candidate sources on a topic.',
    inputSchema: { topic: z.string(), maxResults: z.number().int().min(1).max(12).default(6) },
  },
  async ({ topic, maxResults }) => ok(await discoverSources(topic, maxResults))
);

server.registerTool(
  'barbi_notebook_deep_research',
  {
    description: 'Run multi-step deep research and add findings to a notebook.',
    inputSchema: { notebookId: z.string(), topic: z.string() },
  },
  async ({ notebookId, topic }) => {
    try {
      return ok(await deepResearch({ userKey: 'mcp', notebookId, topic }));
    } catch (err) {
      return fail(err instanceof Error ? err.message : String(err));
    }
  }
);

server.registerTool(
  'barbi_notebook_artifact_types',
  { description: 'List all available Studio artifact types.' },
  async () => ok(ARTIFACT_TYPES)
);

server.registerTool(
  'barbi_notebook_generate_artifact',
  {
    description: 'Generate a Studio artifact (report, flashcards, quiz, mind map, audio, video, slide deck, infographic, data table).',
    inputSchema: { notebookId: z.string(), artifactType: z.string(), customPrompt: z.string().optional() },
  },
  async ({ notebookId, artifactType, customPrompt }) => {
    try {
      return ok(
        customPrompt
          ? await generateArtifactCustom({ userKey: 'mcp', notebookId, type: artifactType as never, prompt: customPrompt })
          : await generateArtifact({ userKey: 'mcp', notebookId, type: artifactType as never })
      );
    } catch (err) {
      return fail(err instanceof Error ? err.message : String(err));
    }
  }
);

server.registerTool(
  'barbi_notebook_list_artifacts',
  {
    description: 'List generated Studio artifacts for a notebook.',
    inputSchema: { notebookId: z.string() },
  },
  async ({ notebookId }) => ok(listArtifacts('mcp', notebookId))
);

server.registerTool(
  'barbi_notebook_get_artifact',
  {
    description: 'Read one generated artifact.',
    inputSchema: { notebookId: z.string(), artifactId: z.string() },
  },
  async ({ notebookId, artifactId }) => ok(getArtifact('mcp', notebookId, artifactId) ?? fail('Artifact not found'))
);

server.registerTool(
  'barbi_notebook_export',
  {
    description: 'Export a notebook as Markdown.',
    inputSchema: { notebookId: z.string() },
  },
  async ({ notebookId }) => ok({ markdown: exportNotebookMarkdown('mcp', notebookId) })
);

server.registerTool(
  'barbi_notes',
  {
    description: 'List notes in a notebook.',
    inputSchema: { notebookId: z.string() },
  },
  async ({ notebookId }) => ok(listNotes('mcp', notebookId))
);

server.registerTool(
  'barbi_note_create',
  {
    description: 'Create a note in a notebook.',
    inputSchema: { notebookId: z.string(), title: z.string().optional(), content: z.string() },
  },
  async ({ notebookId, title, content }) => ok(createNote('mcp', notebookId, { title, content }))
);

server.registerTool(
  'barbi_note_to_source',
  {
    description: 'Convert a saved note into a citable source.',
    inputSchema: { notebookId: z.string(), noteId: z.string() },
  },
  async ({ notebookId, noteId }) => ok(await noteToSource('mcp', notebookId, noteId))
);

// ---------------------------------------------------------------- Study studio
server.registerTool(
  'barbi_generate_study_pack',
  {
    description: 'Generate a structured study pack from source material.',
    inputSchema: { topicTitle: z.string(), sourceMaterial: z.string() },
  },
  async ({ topicTitle, sourceMaterial }) => ok(await generateNotebookStudyPack({ topicTitle, sourceMaterial }))
);

// ---------------------------------------------------------------- God's Eye
server.registerTool(
  'barbi_gods_eye_feeds',
  {
    description: 'Fetch the live God\'s Eye spatial-intelligence snapshot (satellites, flights, ships, earthquakes, cameras).',
    inputSchema: { forceRefresh: z.boolean().default(false) },
  },
  async ({ forceRefresh }) => ok(await fetchGodsEyeFeedsSnapshot(forceRefresh))
);

// ---------------------------------------------------------------- Social agent
const SOCIAL_PLATFORM_ENUM = z.enum(['whatsapp', 'telegram', 'instagram', 'tiktok']);

server.registerTool(
  'barbi_social_summary',
  {
    description: 'Read the B.A.R.B.I Social Agent dashboard: connection status for WhatsApp/Telegram/Instagram/TikTok, recent messages, automation rules, and pending approvals.',
  },
  async () => ok(await getSocialAgentSummary())
);

server.registerTool(
  'barbi_social_messages',
  {
    description: 'Read the normalized social inbox. Optionally filter by platform.',
    inputSchema: { platform: SOCIAL_PLATFORM_ENUM.optional(), limit: z.number().min(1).max(500).default(50) },
  },
  async ({ platform, limit }) => ok(await listSocialMessages({ platform, limit }))
);

server.registerTool(
  'barbi_social_send',
  {
    description: 'Send a reply through the Social Agent to a WhatsApp/Telegram/Instagram thread. TikTok is webhook-only (outbound send disabled by default).',
    inputSchema: { platform: SOCIAL_PLATFORM_ENUM, threadId: z.string().min(1), text: z.string().min(1).max(4000) },
  },
  async ({ platform, threadId, text }) => ok(await sendSocialMessage({ platform, threadId, text }))
);

server.registerTool(
  'barbi_social_poll',
  {
    description: 'Poll the Telegram bot inbox for new messages and run them through the automation rules engine (auto-reply or queue for approval).',
  },
  async () => ok(await pollTelegramInbox())
);

server.registerTool(
  'barbi_social_approvals',
  {
    description: 'List messages waiting for human approval before B.A.R.B.I. replies.',
  },
  async () => ok(await listApprovals())
);

server.registerTool(
  'barbi_social_resolve_approval',
  {
    description: 'Approve and send, or reject, a queued social reply.',
    inputSchema: { id: z.string().min(1), approve: z.boolean(), editedText: z.string().max(4000).optional() },
  },
  async ({ id, approve, editedText }) => ok(await resolveApproval({ id, approve, editedText }))
);

server.registerTool(
  'barbi_social_save_rule',
  {
    description: 'Create or update an automation rule that reads incoming social messages and replies automatically (with an optional approval gate). Templates support {{name}}, {{text}}, {{platform}}.',
    inputSchema: {
      id: z.string().optional(),
      name: z.string().min(1),
      platform: z.enum(['whatsapp', 'telegram', 'instagram', 'tiktok', 'all']).default('all'),
      enabled: z.boolean().default(true),
      matchType: z.enum(['contains', 'regex', 'all']).default('contains'),
      matchValue: z.string().default(''),
      replyTemplate: z.string().min(1),
      requireApproval: z.boolean().default(false),
    },
  },
  async (args) => ok(await upsertAutomationRule(args))
);

server.registerTool(
  'barbi_social_delete_rule',
  {
    description: 'Delete an automation rule by ID.',
    inputSchema: { id: z.string().min(1) },
  },
  async ({ id }) => ok({ ok: await deleteAutomationRule(id) })
);

// ---------------------------------------------------------------- Resources
server.registerResource(
  'barbi-progress',
  'barbi://progress',
  { description: 'The B.A.R.B.I development progress log', mimeType: 'text/markdown' },
  async () => {
    const content = await fs.readFile(path.join(WORKSPACE_ROOT, 'PROGRESS.md'), 'utf8').catch(() => '# No progress log');
    return { contents: [{ uri: 'barbi://progress', mimeType: 'text/markdown', text: content }] };
  }
);

const transport = new StdioServerTransport();
await server.connect(transport);
