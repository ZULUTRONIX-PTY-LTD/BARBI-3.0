/**
 * B.A.R.B.I. Computer Vision Engine — YOLOv8n via ONNX Runtime Web.
 *
 * - Model: `public/model/yolov8n.onnx` (Ultralytics YOLOv8n, COCO 80 classes, ~12.8 MB).
 * - Runtime: onnxruntime-web ESM from CDN (WebAssembly backend, fully client-side — no API key).
 * - Pipeline: letterbox 640x640 -> NCHW float tensor -> run -> decode [1,84,8400] -> conf -> NMS -> unpad.
 * - Output: pixel-space bounding boxes in source image coordinates.
 */

export interface DetectedObject {
  classId: number;
  className: string;
  confidence: number;
  x: number;
  y: number;
  width: number;
  height: number;
}

export interface TrackedObject extends DetectedObject {
  trackId: number;
  /** running centroid for the visible trail */
  centerX: number;
  centerY: number;
}

export const YOLO_INPUT_SIZE = 640;
export const YOLO_CONF_THRESHOLD = 0.35;
export const YOLO_IOU_THRESHOLD = 0.45;
export const YOLO_MAX_DETECTIONS = 20;

export const COCO_CLASS_NAMES: string[] = [
  'person', 'bicycle', 'car', 'motorcycle', 'airplane', 'bus', 'train', 'truck', 'boat', 'traffic light',
  'fire hydrant', 'stop sign', 'parking meter', 'bench', 'bird', 'cat', 'dog', 'horse', 'sheep', 'cow',
  'elephant', 'bear', 'zebra', 'giraffe', 'backpack', 'umbrella', 'handbag', 'tie', 'suitcase', 'frisbee',
  'skis', 'snowboard', 'sports ball', 'kite', 'baseball bat', 'baseball glove', 'skateboard', 'surfboard',
  'tennis racket', 'bottle', 'wine glass', 'cup', 'fork', 'knife', 'spoon', 'bowl', 'banana', 'apple',
  'sandwich', 'orange', 'broccoli', 'carrot', 'hot dog', 'pizza', 'donut', 'cake', 'chair', 'couch',
  'potted plant', 'bed', 'dining table', 'toilet', 'tv', 'laptop', 'mouse', 'remote', 'keyboard', 'cell phone',
  'microwave', 'oven', 'toaster', 'sink', 'refrigerator', 'book', 'clock', 'vase', 'scissors', 'teddy bear',
  'hair drier', 'toothbrush',
];

const ORT_VERSION = '1.21.0';
const ORT_CDN_URL = `https://cdn.jsdelivr.net/npm/onnxruntime-web@${ORT_VERSION}/+esm`;
const ORT_WASM_PATH = `https://cdn.jsdelivr.net/npm/onnxruntime-web@${ORT_VERSION}/dist/`;
const CLASS_COUNT = COCO_CLASS_NAMES.length;
const ANCHOR_FIELDS = 4 + CLASS_COUNT;

let ortModule: any | null = null;
let sessionPromise: Promise<any | null> | null = null;
let trackSeq = 1;
let activeTracks: TrackedObject[] = [];

async function getOrt(): Promise<any | null> {
  if (ortModule) return ortModule;
  const mod = await import(/* @vite-ignore */ ORT_CDN_URL);
  if (mod?.env?.wasm) mod.env.wasm.wasmPaths = ORT_WASM_PATH;
  ortModule = mod;
  return mod;
}

export function loadObjectDetector(): Promise<any | null> {
  if (!sessionPromise) {
    sessionPromise = (async () => {
      try {
        const ort = await getOrt();
        if (!ort?.InferenceSession) throw new Error('onnxruntime-web InferenceSession unavailable');
        const session = await ort.InferenceSession.create('/model/yolov8n.onnx', {
          graphOptimizationLevel: 'all',
        });
        return session;
      } catch (err) {
        sessionPromise = null;
        console.error('[BARBI ComputerVision] Failed to load YOLOv8n ONNX runtime/session:', err);
        return null;
      }
    })();
  }
  return sessionPromise;
}

function iou(ax: number, ay: number, aw: number, ah: number, bx: number, by: number, bw: number, bh: number): number {
  const ix = Math.max(0, Math.min(ax + aw, bx + bw) - Math.max(ax, bx));
  const iy = Math.max(0, Math.min(ay + ah, by + bh) - Math.max(ay, by));
  const inter = ix * iy;
  const union = aw * ah + bw * bh - inter;
  return union > 0 ? inter / union : 0;
}

export function applyNms(detections: DetectedObject[], iouThreshold: number): DetectedObject[] {
  const sorted = [...detections].sort((a, b) => b.confidence - a.confidence);
  const kept: DetectedObject[] = [];
  for (const det of sorted) {
    const overlap = kept.some(
      (k) => iou(k.x, k.y, k.width, k.height, det.x, det.y, det.width, det.height) > iouThreshold,
    );
    if (!overlap) kept.push(det);
  }
  return kept.slice(0, YOLO_MAX_DETECTIONS);
}

export async function detectObjects(
  source: CanvasImageSource & { width?: number; height?: number },
  sourceWidth: number,
  sourceHeight: number,
): Promise<DetectedObject[]> {
  const session = await loadObjectDetector();
  if (!session) return [];

  const w = (source as HTMLVideoElement).videoWidth || sourceWidth || YOLO_INPUT_SIZE;
  const h = (source as HTMLVideoElement).videoHeight || sourceHeight || YOLO_INPUT_SIZE;
  const scale = Math.min(YOLO_INPUT_SIZE / w, YOLO_INPUT_SIZE / h);
  const nw = Math.max(1, Math.round(w * scale));
  const nh = Math.max(1, Math.round(h * scale));
  const padX = (YOLO_INPUT_SIZE - nw) / 2;
  const padY = (YOLO_INPUT_SIZE - nh) / 2;

  const off = document.createElement('canvas');
  off.width = YOLO_INPUT_SIZE;
  off.height = YOLO_INPUT_SIZE;
  const ctx = off.getContext('2d');
  if (!ctx) return [];
  ctx.fillStyle = '#727272';
  ctx.fillRect(0, 0, YOLO_INPUT_SIZE, YOLO_INPUT_SIZE);
  ctx.drawImage(source, padX, padY, nw, nh, 0, 0, YOLO_INPUT_SIZE, YOLO_INPUT_SIZE);
  const imgData = ctx.getImageData(0, 0, YOLO_INPUT_SIZE, YOLO_INPUT_SIZE).data;

  // NCHW float32: index = ((c * H + y) * W + x); no alpha channel.
  const data = new Float32Array(3 * YOLO_INPUT_SIZE * YOLO_INPUT_SIZE);
  for (let c = 0; c < 3; c++) {
    for (let y = 0; y < YOLO_INPUT_SIZE; y++) {
      for (let x = 0; x < YOLO_INPUT_SIZE; x++) {
        data[(c * YOLO_INPUT_SIZE + y) * YOLO_INPUT_SIZE + x] =
          imgData[(y * YOLO_INPUT_SIZE + x) * 4 + c] / 255;
      }
    }
  }

  const ort = await getOrt();
  const input = new ort.Tensor('float32', data, [1, 3, YOLO_INPUT_SIZE, YOLO_INPUT_SIZE]);
  const inputName = session.inputNames?.[0] || 'images';
  const out = await session.run({ [inputName]: input });
  const values = Array.isArray(out) ? out : Object.values(out);
  const tensor = values[0] as { data: Float32Array; dims: number[] } | undefined;
  if (!tensor) return [];
  const flat = tensor.data as Float32Array;
  const dims = tensor.dims || [];
  const anchors = dims[2] ?? 8400;
  // Ultralytics YOLOv8n exports [1, 84, 8400] in CHANNEL-MAJOR order:
  // flat[channel * anchors + anchor] (x, y, w, h, then 80 class scores).
  const raw: Array<DetectedObject & { _cx: number; _cy: number; _bw: number; _bh: number }> = [];
  for (let i = 0; i < anchors; i++) {
    const base = (c: number) => c * anchors + i;
    const cx = flat[base(0)];
    const cy = flat[base(1)];
    const bw = flat[base(2)];
    const bh = flat[base(3)];
    let maxScore = -1;
    let maxClass = 0;
    for (let c = 0; c < CLASS_COUNT; c++) {
      const s = flat[base(4 + c)];
      if (s > maxScore) { maxScore = s; maxClass = c; }
    }
    if (!Number.isFinite(maxScore) || maxScore < YOLO_CONF_THRESHOLD) continue;
    raw.push({
      classId: maxClass,
      className: COCO_CLASS_NAMES[maxClass] || 'unknown',
      confidence: maxScore,
      x: 0, y: 0, width: 0, height: 0,
      _cx: flat[base], _cy: flat[base + 1], _bw: flat[base + 2], _bh: flat[base + 3],
    });
  }

  const detections = raw.map((d) => {
    const cx = (d._cx - padX) / scale;
    const cy = (d._cy - padY) / scale;
    const bw = d._bw / scale;
    const bh = d._bh / scale;
    const { _cx, _cy, _bw, _bh, ...rest } = d;
    return { ...rest, x: cx - bw / 2, y: cy - bh / 2, width: bw, height: bh };
  });

  return applyNms(detections, YOLO_IOU_THRESHOLD);
}

/**
 * Greedy IoU tracker with stable IDs and centroid trails.
 */
export function updateTracks(detections: DetectedObject[]): TrackedObject[] {
  const next: TrackedObject[] = [];
  const sorted = [...detections].sort((a, b) => b.confidence - a.confidence);
  const claimed = new Set<number>();
  for (const det of sorted) {
    let target: TrackedObject | null = null;
    let bestIoU = YOLO_IOU_THRESHOLD;
    for (const t of activeTracks) {
      if (claimed.has(t.trackId) || t.classId !== det.classId) continue;
      const o = iou(t.x, t.y, t.width, t.height, det.x, det.y, det.width, det.height);
      if (o > bestIoU) { bestIoU = o; target = t; }
    }
    const centerX = det.x + det.width / 2;
    const centerY = det.y + det.height / 2;
    if (target) {
      claimed.add(target.trackId);
      next.push({ ...det, trackId: target.trackId, centerX, centerY });
    } else {
      next.push({ ...det, trackId: trackSeq++, centerX, centerY });
    }
  }
  activeTracks = next;
  return next;
}

export function resetTracks(): void {
  activeTracks = [];
  trackSeq = 1;
}
