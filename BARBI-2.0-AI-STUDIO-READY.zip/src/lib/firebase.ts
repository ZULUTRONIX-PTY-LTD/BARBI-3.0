import { initializeApp } from 'firebase/app';
import {
  getAuth,
  GoogleAuthProvider,
  onAuthStateChanged,
  signInWithPopup,
  signOut,
  type User,
} from 'firebase/auth';
import firebaseConfig from '../../firebase-applet-config.json';

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const WORKSPACE_GMAIL_SCOPES: readonly string[] = [
  'https://mail.google.com/',
  'https://www.googleapis.com/auth/gmail.addons.current.action.compose',
  'https://www.googleapis.com/auth/gmail.addons.current.message.action',
  'https://www.googleapis.com/auth/gmail.addons.current.message.metadata',
  'https://www.googleapis.com/auth/gmail.addons.current.message.readonly',
  'https://www.googleapis.com/auth/gmail.compose',
  'https://www.googleapis.com/auth/gmail.insert',
  'https://www.googleapis.com/auth/gmail.labels',
  'https://www.googleapis.com/auth/gmail.metadata',
  'https://www.googleapis.com/auth/gmail.modify',
  'https://www.googleapis.com/auth/gmail.readonly',
  'https://www.googleapis.com/auth/gmail.send',
  'https://www.googleapis.com/auth/gmail.settings.basic',
  'https://www.googleapis.com/auth/gmail.settings.sharing',
] as const;

export const googleProvider = new GoogleAuthProvider();
googleProvider.setCustomParameters({ prompt: 'select_account' });

export const gmailWorkspaceProvider = new GoogleAuthProvider();
gmailWorkspaceProvider.setCustomParameters({ prompt: 'select_account' });
for (const scope of WORKSPACE_GMAIL_SCOPES) {
  gmailWorkspaceProvider.addScope(scope);
}

let currentUserSnapshot: User | null = null;
// Strictly in-memory OAuth access token cache (never persisted to localStorage/sessionStorage)
let cachedWorkspaceAccessToken: string | null = null;
let isWorkspaceSigningIn = false;

onAuthStateChanged(auth, (user) => {
  currentUserSnapshot = user;
  if (!user) {
    cachedWorkspaceAccessToken = null;
  }
});

export function getCurrentFirebaseUser(): User | null {
  return currentUserSnapshot || auth.currentUser;
}

export async function getFirebaseIdToken(forceRefresh = false): Promise<string | null> {
  const user = auth.currentUser;
  if (!user) return null;
  try {
    return await user.getIdToken(forceRefresh);
  } catch {
    return null;
  }
}

export function initWorkspaceAuth(
  onAuthSuccess?: (user: User, accessToken: string) => void,
  onAuthFailure?: () => void
): () => void {
  return onAuthStateChanged(auth, (user) => {
    currentUserSnapshot = user;
    if (user) {
      if (cachedWorkspaceAccessToken) {
        onAuthSuccess?.(user, cachedWorkspaceAccessToken);
      } else if (!isWorkspaceSigningIn) {
        cachedWorkspaceAccessToken = null;
        onAuthFailure?.();
      }
    } else {
      cachedWorkspaceAccessToken = null;
      onAuthFailure?.();
    }
  });
}

export async function signInWithGoogleWorkspace(): Promise<{ user: User; accessToken: string }> {
  try {
    isWorkspaceSigningIn = true;
    const result = await signInWithPopup(auth, gmailWorkspaceProvider);
    const credential = GoogleAuthProvider.credentialFromResult(result);
    if (!credential?.accessToken) {
      throw new Error('Google sign-in completed, but no Gmail access token was returned.');
    }
    currentUserSnapshot = result.user;
    cachedWorkspaceAccessToken = credential.accessToken;
    return { user: result.user, accessToken: credential.accessToken };
  } finally {
    isWorkspaceSigningIn = false;
  }
}

export function getWorkspaceAccessToken(): string | null {
  return cachedWorkspaceAccessToken;
}

export function clearWorkspaceAccessToken(): void {
  cachedWorkspaceAccessToken = null;
}

export async function signInWithGoogle(): Promise<User | null> {
  const result = await signInWithPopup(auth, googleProvider);
  currentUserSnapshot = result.user;
  return result.user;
}

export async function signOutBarbi(): Promise<void> {
  cachedWorkspaceAccessToken = null;
  await signOut(auth);
  currentUserSnapshot = null;
}

export function subscribeAuthState(callback: (user: User | null) => void): () => void {
  return onAuthStateChanged(auth, callback);
}
