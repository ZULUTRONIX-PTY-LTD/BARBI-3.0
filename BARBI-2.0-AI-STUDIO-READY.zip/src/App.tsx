import { Suspense, lazy, useEffect } from 'react';
import { BarbiWorkspace } from './barbi/BarbiWorkspace';
import { installUiPerceptionGlobal } from './voice/barbiUiPerception';

const BarbiChatPanel = lazy(() => import('./components/BarbiChatPanel').then((m) => ({ default: m.BarbiChatPanel })));
const BarbiV4Hub = lazy(() => import('./components/BarbiV4Hub').then((m) => ({ default: m.BarbiV4Hub })));
const GodsEyeViewport = lazy(() => import('./components/GodsEyeViewport').then((m) => ({ default: m.GodsEyeViewport })));
const FileSystemAgentPanel = lazy(() => import('./components/FileSystemAgentPanel').then((m) => ({ default: m.FileSystemAgentPanel })));
const GestureNavHud = lazy(() => import('./components/GestureNavHud').then((m) => ({ default: m.GestureNavHud })));
const GmailWorkspacePanel = lazy(() => import('./components/GmailWorkspacePanel').then((m) => ({ default: m.GmailWorkspacePanel })));
const SphereConfigPanel = lazy(() => import('./components/SphereConfigPanel').then((m) => ({ default: m.SphereConfigPanel })));
const PWAInstallAndSyncBadge = lazy(() =>
  import('./pwa/PWAInstallUI').then((m) => ({ default: m.PWAInstallAndSyncBadge })),
);
const OpenCodeAgentPanel = lazy(() =>
  import('./components/OpenCodeAgentPanel').then((m) => ({ default: m.OpenCodeAgentPanel })),
);
const SocialAgentPanel = lazy(() =>
  import('./components/SocialAgentPanel').then((m) => ({ default: m.SocialAgentPanel })),
);
const ObjectVisionPanel = lazy(() =>
  import('./components/ObjectVisionPanel').then((m) => ({ default: m.default })),
);
const SpotifyPanel = lazy(() =>
  import('./components/SpotifyPanel').then((m) => ({ default: m.default })),
);
const EngineeringAppPanel = lazy(() =>
  import('./components/EngineeringAppPanel').then((m) => ({ default: m.default })),
);
const InternetSpeedPanel = lazy(() =>
  import('./components/InternetSpeedPanel').then((m) => ({ default: m.default })),
);

function PanelFallback() {
  return null;
}

export default function App() {
  useEffect(() => {
    installUiPerceptionGlobal();
  }, []);

  return (
    <>
      <BarbiWorkspace />
      <Suspense fallback={<PanelFallback />}>
        <BarbiChatPanel />
        <BarbiV4Hub />
        <GodsEyeViewport />
        <FileSystemAgentPanel />
        <GmailWorkspacePanel />
        <GestureNavHud />
        <SphereConfigPanel />
        <PWAInstallAndSyncBadge />
        <OpenCodeAgentPanel />
        <SocialAgentPanel />
        <ObjectVisionPanel />
        <SpotifyPanel />
        <EngineeringAppPanel />
        <InternetSpeedPanel />
      </Suspense>
    </>
  );
}
