export interface GmailHeader {
  name?: string;
  value?: string;
}

export interface GmailPayloadPart {
  mimeType?: string;
  filename?: string;
  headers?: GmailHeader[];
  body?: {
    size?: number;
    data?: string;
    attachmentId?: string;
  };
  parts?: GmailPayloadPart[];
}

export interface RawGmailMessage {
  id: string;
  threadId: string;
  labelIds?: string[];
  snippet?: string;
  internalDate?: string;
  payload?: GmailPayloadPart;
}

export interface GmailAttachmentMeta {
  filename: string;
  mimeType: string;
  size: number;
  attachmentId?: string;
}

export interface GmailMessageDetail {
  id: string;
  threadId: string;
  labelIds: string[];
  snippet: string;
  from: string;
  fromName: string;
  fromEmail: string;
  to: string;
  cc: string;
  subject: string;
  date: string;
  internalDateMs: number;
  messageIdHeader: string;
  bodyText: string;
  isUnread: boolean;
  isStarred: boolean;
  isInTrash: boolean;
  isInInbox: boolean;
  attachments: GmailAttachmentMeta[];
}

export interface GmailLabel {
  id: string;
  name: string;
  type?: 'system' | 'user' | string;
  messagesUnread?: number;
  messagesTotal?: number;
}

export interface GmailProfile {
  emailAddress: string;
  messagesTotal: number;
  threadsTotal: number;
}

export interface GmailDraftInput {
  to: string;
  cc?: string;
  subject: string;
  body: string;
  threadId?: string;
  inReplyTo?: string;
}

export function decodeBase64Url(input: string): string {
  const clean = String(input || '').trim();
  if (!clean) return '';
  const base64 = clean.replace(/-/g, '+').replace(/_/g, '/');
  const padded = base64 + '='.repeat((4 - (base64.length % 4)) % 4);
  try {
    const binary = atob(padded);
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i += 1) {
      bytes[i] = binary.charCodeAt(i);
    }
    return new TextDecoder('utf-8', { fatal: false }).decode(bytes);
  } catch {
    return '';
  }
}

export function encodeBase64Url(input: string): string {
  const bytes = new TextEncoder().encode(String(input || ''));
  let binary = '';
  for (let i = 0; i < bytes.length; i += 1) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/g, '');
}

export function stripHtmlToSafeText(html: string): string {
  return String(html || '')
    .replace(/<style[\s\S]*?<\/style>/gi, ' ')
    .replace(/<script[\s\S]*?<\/script>/gi, ' ')
    .replace(/<(?:br|\/p|\/div|\/li|\/tr|\/h[1-6])\b[^>]*>/gi, '\n')
    .replace(/<[^>]+>/g, ' ')
    .replace(/&nbsp;/gi, ' ')
    .replace(/&amp;/gi, '&')
    .replace(/&lt;/gi, '<')
    .replace(/&gt;/gi, '>')
    .replace(/&quot;/gi, '"')
    .replace(/&#39;|&apos;/gi, "'")
    .replace(/[ \t]+\n/g, '\n')
    .replace(/\n{3,}/g, '\n\n')
    .replace(/[ \t]{2,}/g, ' ')
    .trim();
}

export function extractHeaderValue(headers: GmailHeader[] | undefined, targetName: string): string {
  if (!Array.isArray(headers)) return '';
  const target = targetName.toLowerCase();
  const found = headers.find((h) => String(h.name || '').toLowerCase() === target);
  return String(found?.value || '').trim();
}

export function formatSenderDisplay(fromHeader: string): { name: string; email: string } {
  const clean = String(fromHeader || '').trim();
  if (!clean) return { name: 'Unknown sender', email: '' };
  const angleMatch = clean.match(/^(.*?)\s*<([^>]+)>$/);
  if (angleMatch) {
    const rawName = angleMatch[1].replace(/^["']|["']$/g, '').trim();
    const email = angleMatch[2].trim();
    return { name: rawName || email, email };
  }
  return { name: clean, email: clean };
}

function collectAttachments(part: GmailPayloadPart | undefined, out: GmailAttachmentMeta[]): void {
  if (!part) return;
  if (part.filename && part.filename.trim().length > 0) {
    out.push({
      filename: part.filename.trim(),
      mimeType: part.mimeType || 'application/octet-stream',
      size: Number(part.body?.size || 0),
      attachmentId: part.body?.attachmentId,
    });
  }
  if (Array.isArray(part.parts)) {
    for (const child of part.parts) {
      collectAttachments(child, out);
    }
  }
}

export function extractMessageBody(payload: GmailPayloadPart | undefined): string {
  if (!payload) return '';

  const plainChunks: string[] = [];
  const htmlChunks: string[] = [];

  const walk = (part: GmailPayloadPart) => {
    const mime = String(part.mimeType || '').toLowerCase();
    if (part.body?.data) {
      if (mime === 'text/plain' || (!mime && !part.parts)) {
        const decoded = decodeBase64Url(part.body.data).trim();
        if (decoded) plainChunks.push(decoded);
      } else if (mime === 'text/html') {
        const decoded = decodeBase64Url(part.body.data).trim();
        if (decoded) htmlChunks.push(decoded);
      }
    }
    if (Array.isArray(part.parts)) {
      for (const child of part.parts) {
        walk(child);
      }
    }
  };

  walk(payload);

  if (plainChunks.length > 0) {
    return plainChunks.join('\n\n').trim();
  }
  if (htmlChunks.length > 0) {
    return stripHtmlToSafeText(htmlChunks.join('\n'));
  }
  return '';
}

export function parseGmailMessage(raw: RawGmailMessage): GmailMessageDetail {
  const headers = raw.payload?.headers || [];
  const labelIds = Array.isArray(raw.labelIds) ? raw.labelIds : [];
  const from = extractHeaderValue(headers, 'From');
  const { name: fromName, email: fromEmail } = formatSenderDisplay(from);
  const to = extractHeaderValue(headers, 'To');
  const cc = extractHeaderValue(headers, 'Cc');
  const subject = extractHeaderValue(headers, 'Subject') || '(No subject)';
  const date = extractHeaderValue(headers, 'Date');
  const messageIdHeader = extractHeaderValue(headers, 'Message-ID');
  const internalDateMs = Number(raw.internalDate || 0) || (date ? Date.parse(date) || 0 : 0);
  const snippet = stripHtmlToSafeText(raw.snippet || '');
  const bodyText = extractMessageBody(raw.payload) || snippet;
  const attachments: GmailAttachmentMeta[] = [];
  collectAttachments(raw.payload, attachments);

  return {
    id: raw.id,
    threadId: raw.threadId,
    labelIds,
    snippet,
    from,
    fromName,
    fromEmail,
    to,
    cc,
    subject,
    date,
    internalDateMs,
    messageIdHeader,
    bodyText,
    isUnread: labelIds.includes('UNREAD'),
    isStarred: labelIds.includes('STARRED'),
    isInTrash: labelIds.includes('TRASH'),
    isInInbox: labelIds.includes('INBOX'),
    attachments,
  };
}

function sanitizeHeaderField(value: string): string {
  return String(value || '').replace(/[\r\n]+/g, ' ').trim();
}

export function validateEmailDraft(draft: GmailDraftInput): { ok: true } | { ok: false; error: string } {
  const to = sanitizeHeaderField(draft.to);
  const subject = sanitizeHeaderField(draft.subject);
  const body = String(draft.body || '').trim();

  if (!to) {
    return { ok: false, error: 'Recipient (To) email address is required.' };
  }
  const recipients = to
    .split(',')
    .map((s) => s.trim())
    .filter(Boolean);
  const emailRe = /^[^\s@<>]+@[^\s@<>]+\.[^\s@<>]+$/;
  for (const recipient of recipients) {
    const extracted = formatSenderDisplay(recipient).email;
    if (!emailRe.test(extracted)) {
      return { ok: false, error: `Invalid recipient email address: "${recipient}"` };
    }
  }
  if (!subject) {
    return { ok: false, error: 'Subject is required.' };
  }
  if (!body) {
    return { ok: false, error: 'Message body cannot be empty.' };
  }
  return { ok: true };
}

export function buildRfc2822RawEmail(draft: GmailDraftInput): { raw: string; threadId?: string } {
  const to = sanitizeHeaderField(draft.to);
  const cc = sanitizeHeaderField(draft.cc || '');
  const subject = sanitizeHeaderField(draft.subject);
  const inReplyTo = sanitizeHeaderField(draft.inReplyTo || '');
  const body = String(draft.body || '').replace(/\r?\n/g, '\r\n');

  const lines: string[] = [
    `To: ${to}`,
    ...(cc ? [`Cc: ${cc}`] : []),
    `Subject: ${subject}`,
    ...(inReplyTo ? [`In-Reply-To: ${inReplyTo}`, `References: ${inReplyTo}`] : []),
    'MIME-Version: 1.0',
    'Content-Type: text/plain; charset="UTF-8"',
    '',
    body,
  ];

  return {
    raw: encodeBase64Url(lines.join('\r\n')),
    ...(draft.threadId ? { threadId: draft.threadId } : {}),
  };
}

export function formatGmailShortDate(internalDateMs: number, fallbackDate?: string): string {
  const ts = internalDateMs || (fallbackDate ? Date.parse(fallbackDate) : 0);
  if (!ts || !Number.isFinite(ts)) return '';
  const d = new Date(ts);
  const now = new Date();
  const sameDay =
    d.getFullYear() === now.getFullYear() &&
    d.getMonth() === now.getMonth() &&
    d.getDate() === now.getDate();
  if (sameDay) {
    return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  }
  if (d.getFullYear() === now.getFullYear()) {
    return d.toLocaleDateString([], { month: 'short', day: 'numeric' });
  }
  return d.toLocaleDateString([], { year: 'numeric', month: 'short', day: 'numeric' });
}
