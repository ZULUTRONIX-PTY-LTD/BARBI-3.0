import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import {
  buildRfc2822RawEmail,
  decodeBase64Url,
  encodeBase64Url,
  formatSenderDisplay,
  parseGmailMessage,
  stripHtmlToSafeText,
  validateEmailDraft,
} from './gmailLogic.ts';

describe('Gmail pure MIME & message logic', () => {
  it('round-trips UTF-8 text via base64url encode/decode', () => {
    const sample = 'Hello Treasure — ZULUTRONIX ⚡ Mechatronics & B.A.R.B.I.';
    const encoded = encodeBase64Url(sample);
    assert.ok(!encoded.includes('+'));
    assert.ok(!encoded.includes('/'));
    assert.ok(!encoded.includes('='));
    assert.equal(decodeBase64Url(encoded), sample);
  });

  it('strips scripts, styles, and tags from HTML bodies safely', () => {
    const html =
      '<div><style>.x{color:red}</style><p>Hello &amp; welcome!</p><script>alert(1)</script><p>Line 2</p></div>';
    const text = stripHtmlToSafeText(html);
    assert.ok(text.includes('Hello & welcome!'));
    assert.ok(text.includes('Line 2'));
    assert.ok(!text.includes('alert(1)'));
    assert.ok(!text.includes('<script'));
  });

  it('parses multipart Gmail messages with attachments and flags', () => {
    const raw = {
      id: 'msg-101',
      threadId: 'thr-55',
      labelIds: ['INBOX', 'UNREAD', 'STARRED'],
      snippet: 'Telemetry report attached',
      internalDate: String(Date.UTC(2026, 10, 21, 10, 0, 0)),
      payload: {
        mimeType: 'multipart/mixed',
        headers: [
          { name: 'From', value: '"ECSA Secretariat" <office@ecsa.co.za>' },
          { name: 'To', value: 'zulutreasuretrinity@gmail.com' },
          { name: 'Subject', value: 'Candidate Engineer Registration Update' },
          { name: 'Message-ID', value: '<abc123@ecsa.co.za>' },
        ],
        parts: [
          {
            mimeType: 'text/plain',
            body: { data: encodeBase64Url('Dear Treasure,\nYour application status is updated.') },
          },
          {
            mimeType: 'application/pdf',
            filename: 'registration-summary.pdf',
            body: { size: 48200, attachmentId: 'att-1' },
          },
        ],
      },
    };

    const parsed = parseGmailMessage(raw);
    assert.equal(parsed.fromName, 'ECSA Secretariat');
    assert.equal(parsed.fromEmail, 'office@ecsa.co.za');
    assert.equal(parsed.subject, 'Candidate Engineer Registration Update');
    assert.equal(parsed.isUnread, true);
    assert.equal(parsed.isStarred, true);
    assert.equal(parsed.isInInbox, true);
    assert.equal(parsed.isInTrash, false);
    assert.ok(parsed.bodyText.includes('Your application status is updated.'));
    assert.equal(parsed.attachments.length, 1);
    assert.equal(parsed.attachments[0].filename, 'registration-summary.pdf');
  });

  it('prevents CRLF header injection and validates drafts accurately', () => {
    assert.equal(validateEmailDraft({ to: 'bad-email', subject: 'Hi', body: 'Test' }).ok, false);
    assert.equal(validateEmailDraft({ to: 'user@example.com', subject: '', body: 'Test' }).ok, false);
    assert.equal(validateEmailDraft({ to: 'user@example.com', subject: 'Hi', body: 'Hello' }).ok, true);

    const built = buildRfc2822RawEmail({
      to: 'alice@example.com\r\nBcc: attacker@evil.com',
      subject: 'Status\r\nX-Injected: 1',
      body: 'Safe body line 1\nLine 2',
      threadId: 'thr-9',
    });
    const decoded = decodeBase64Url(built.raw);
    assert.ok(!decoded.includes('\r\nBcc:'));
    assert.ok(!decoded.includes('\r\nX-Injected:'));
    assert.equal(built.threadId, 'thr-9');
    assert.deepEqual(formatSenderDisplay('Alice <alice@example.com>'), {
      name: 'Alice',
      email: 'alice@example.com',
    });
  });
});
