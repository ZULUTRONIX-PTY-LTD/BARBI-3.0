import {
  buildRfc2822RawEmail,
  parseGmailMessage,
  type GmailDraftInput,
  type GmailLabel,
  type GmailMessageDetail,
  type GmailProfile,
  type RawGmailMessage,
} from './gmailLogic';

const GMAIL_API_BASE = 'https://gmail.googleapis.com/gmail/v1/users/me';

export class GmailAuthExpiredError extends Error {
  constructor(message = 'Your Gmail session expired. Please sign in with Google again.') {
    super(message);
    this.name = 'GmailAuthExpiredError';
  }
}

async function gmailFetch<T>(
  accessToken: string,
  path: string,
  options?: { method?: string; body?: unknown }
): Promise<T> {
  if (!accessToken) {
    throw new GmailAuthExpiredError();
  }

  const res = await fetch(`${GMAIL_API_BASE}${path}`, {
    method: options?.method || 'GET',
    headers: {
      Authorization: `Bearer ${accessToken}`,
      ...(options?.body !== undefined ? { 'Content-Type': 'application/json' } : {}),
    },
    ...(options?.body !== undefined ? { body: JSON.stringify(options.body) } : {}),
  });

  if (res.status === 401) {
    throw new GmailAuthExpiredError();
  }

  if (res.status === 204) {
    return undefined as T;
  }

  const text = await res.text();
  let json: unknown = null;
  if (text) {
    try {
      json = JSON.parse(text);
    } catch {
      json = null;
    }
  }

  if (!res.ok) {
    const apiErr = (json as { error?: { message?: string; status?: string } } | null)?.error;
    const msg = apiErr?.message || `Gmail API request failed (HTTP ${res.status})`;
    if (res.status === 403 && /insufficient|scope|permission|auth/i.test(msg)) {
      throw new GmailAuthExpiredError(
        'Gmail permissions are missing or expired. Please sign in with Google again and allow Gmail access.'
      );
    }
    throw new Error(msg);
  }

  return json as T;
}

export async function fetchGmailProfile(accessToken: string): Promise<GmailProfile> {
  const data = await gmailFetch<{
    emailAddress?: string;
    messagesTotal?: number;
    threadsTotal?: number;
  }>(accessToken, '/profile');
  return {
    emailAddress: String(data.emailAddress || ''),
    messagesTotal: Number(data.messagesTotal || 0),
    threadsTotal: Number(data.threadsTotal || 0),
  };
}

export async function fetchGmailLabels(accessToken: string): Promise<GmailLabel[]> {
  const data = await gmailFetch<{ labels?: GmailLabel[] }>(accessToken, '/labels');
  return Array.isArray(data.labels) ? data.labels : [];
}

export async function listGmailMessages(
  accessToken: string,
  params?: {
    labelId?: string;
    q?: string;
    maxResults?: number;
    pageToken?: string;
    includeSpamTrash?: boolean;
  }
): Promise<{ messages: GmailMessageDetail[]; nextPageToken?: string }> {
  const sp = new URLSearchParams();
  sp.set('maxResults', String(params?.maxResults ?? 20));
  if (params?.labelId && params.labelId !== 'ALL') {
    sp.set('labelIds', params.labelId);
  }
  if (params?.q && params.q.trim()) {
    sp.set('q', params.q.trim());
  }
  if (params?.pageToken) {
    sp.set('pageToken', params.pageToken);
  }
  if (params?.includeSpamTrash || params?.labelId === 'TRASH') {
    sp.set('includeSpamTrash', 'true');
  }

  const list = await gmailFetch<{
    messages?: Array<{ id: string; threadId: string }>;
    nextPageToken?: string;
  }>(accessToken, `/messages?${sp.toString()}`);

  const ids = (list.messages || []).map((m) => m.id);
  if (ids.length === 0) {
    return { messages: [], nextPageToken: list.nextPageToken };
  }

  const fetched = await Promise.all(
    ids.map((id) =>
      gmailFetch<RawGmailMessage>(
        accessToken,
        `/messages/${encodeURIComponent(id)}?format=metadata&metadataHeaders=From&metadataHeaders=To&metadataHeaders=Cc&metadataHeaders=Subject&metadataHeaders=Date&metadataHeaders=Message-ID`
      ).catch(() => null)
    )
  );

  const messages = fetched
    .filter((m): m is RawGmailMessage => Boolean(m))
    .map((raw) => parseGmailMessage(raw));

  return {
    messages,
    nextPageToken: list.nextPageToken,
  };
}

export async function getGmailMessage(
  accessToken: string,
  messageId: string
): Promise<GmailMessageDetail> {
  const raw = await gmailFetch<RawGmailMessage>(
    accessToken,
    `/messages/${encodeURIComponent(messageId)}?format=full`
  );
  return parseGmailMessage(raw);
}

export async function sendGmailMessage(
  accessToken: string,
  draft: GmailDraftInput
): Promise<{ id: string; threadId: string }> {
  const payload = buildRfc2822RawEmail(draft);
  return gmailFetch<{ id: string; threadId: string }>(accessToken, '/messages/send', {
    method: 'POST',
    body: payload,
  });
}

export async function createGmailDraft(
  accessToken: string,
  draft: GmailDraftInput
): Promise<{ id: string }> {
  const payload = buildRfc2822RawEmail(draft);
  return gmailFetch<{ id: string }>(accessToken, '/drafts', {
    method: 'POST',
    body: { message: payload },
  });
}

export async function modifyGmailMessageLabels(
  accessToken: string,
  messageId: string,
  mods: { addLabelIds?: string[]; removeLabelIds?: string[] }
): Promise<RawGmailMessage> {
  return gmailFetch<RawGmailMessage>(
    accessToken,
    `/messages/${encodeURIComponent(messageId)}/modify`,
    {
      method: 'POST',
      body: {
        addLabelIds: mods.addLabelIds || [],
        removeLabelIds: mods.removeLabelIds || [],
      },
    }
  );
}

export async function trashGmailMessage(
  accessToken: string,
  messageId: string
): Promise<RawGmailMessage> {
  return gmailFetch<RawGmailMessage>(
    accessToken,
    `/messages/${encodeURIComponent(messageId)}/trash`,
    { method: 'POST' }
  );
}

export async function untrashGmailMessage(
  accessToken: string,
  messageId: string
): Promise<RawGmailMessage> {
  return gmailFetch<RawGmailMessage>(
    accessToken,
    `/messages/${encodeURIComponent(messageId)}/untrash`,
    { method: 'POST' }
  );
}

export async function deleteGmailMessagePermanently(
  accessToken: string,
  messageId: string
): Promise<void> {
  await gmailFetch<void>(accessToken, `/messages/${encodeURIComponent(messageId)}`, {
    method: 'DELETE',
  });
}
